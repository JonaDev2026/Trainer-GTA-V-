﻿// ============================================================
//  UBER - autista privato
//  Mod esterna: il trainer la accende e la spegne scrivendo
//  scripts\Trainer\mods.ini  ->  lavori/uber=1
//
//  Tutto quello che questo mod crea viene segnato in spawn.txt
//  (nella sua cartella) appena nasce, cosi' anche dopo un crash,
//  alla ripartenza, sa cosa deve andare a cancellare.
// ============================================================

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text;
using GTA;
using GTA.Math;
using GTA.Native;
using GTA.UI;

public class Uber : Script
{
    const string GAME_DIR    = "C:\\Program Files\\Rockstar Games\\Grand Theft Auto V Enhanced";
    const string TRAINER_DIR = GAME_DIR + "\\scripts\\Trainer";
    const string MY_DIR      = GAME_DIR + "\\scripts\\Lavori\\Uber";

    const string MOD_ID = "lavori/uber";

    // ---------- stato ----------
    bool on = false;
    int checkNext = 0;          // prossima lettura di mods.ini
    int lang = 0;               // 0 inglese, 1 italiano

    int state = 0;              // 0 spento, 1 attesa chiamata, 2 vado a prendere, 3 corsa
    int next = 0;
    Vector3 from = Vector3.Zero;    // dove aspetta il cliente
    Vector3 to = Vector3.Zero;      // dove va
    Ped client = null;
    bool clientWasReal = false;     // preso dalla strada, non creato da noi
    int blip = 0;
    int fare = 0;
    int deadline = 0;
    int enterAt = 0;
    int walkAt = 0;          // ultima volta che gli ho detto di venire incontro
    bool walking = false;
    bool boarding = false;   // gli hai suonato: sta salendo
    int hintAt = 0;
    int dropAt = 0;          // quando gli ho detto di scendere
    int limCity = 80, limHwy = 140, limDirt = 65;   // letti dal config del trainer
    int limNext = 0;
    float mood = 100f;
    bool angry = false;
    float bodyWas = 1000f;
    int earned = 0;
    int rides = 0;
    Random rng = new Random();

    // ---------- nomi dei clienti ----------
    // Si leggono da nomi.txt (M| uomini, F| donne) e si pescano a giro:
    // la lista si rimescola solo quando e' finita, cosi' non esce due volte
    // di fila lo stesso nome. Il nome segue il sesso del cliente.
    List<string> nomiM = new List<string>();
    List<string> nomiF = new List<string>();
    List<string> restoM = new List<string>();
    List<string> restoF = new List<string>();
    string clientName = "";
    string addrFrom = "";      // dove lo prendi
    string addrTo = "";        // dove lo porti
    string zonaFrom = "";
    string zonaTo = "";
    string oraPickup = "";     // a che ora devi essere dal cliente
    string oraArrivo = "";     // a che ora deve essere a destinazione
    string distTxt = "";       // lunghezza del tragitto
    bool offerta = false;      // corsa proposta, non ancora accettata
    int pickupLimit = 0;       // entro quando devi essere dal cliente
    int lateNext = 0;          // prossimo scatto di penalita' per il ritardo

    // il telefono non sparisce mai: scorre fra due posizioni. In basso si
    // vede solo il logo, in alto si legge tutto.
    float phSlide = 0f;        // 0 = giu', 1 = su
    int phUpUntil = 0;         // resta su ancora per un po' a fine corsa
    int offerScade = 0;        // entro quando devi accettare l'offerta

    // orologio: la mod tiene il tempo come il trainer a x2.5 (1 minuto di
    // gioco ogni 16 secondi reali). Se al tempo ci pensa gia' il trainer
    // (config.ini 412=3) qui non si tocca niente.
    const int MS_PER_MIN = 16000;
    bool clockMine = false;
    int nextGameMin = 0;
    bool clientUomo = true;    // sesso deciso alla prenotazione

    void CaricaNomi()
    {
        try
        {
            string f = Path.Combine(MY_DIR, "nomi.txt");
            if (!File.Exists(f)) return;

            string[] rows = File.ReadAllLines(f);
            int i;
            for (i = 0; i < rows.Length; i++)
            {
                string r = rows[i].Trim();
                if (r.Length < 3) continue;

                if (r.StartsWith("M|")) nomiM.Add(r.Substring(2).Trim());
                else if (r.StartsWith("F|")) nomiF.Add(r.Substring(2).Trim());
            }
        }
        catch { }
    }

    // solo la zona di un punto
    string ZonaDi(Vector3 pos)
    {
        // niente traduzione: si usa il nome come sta sulla mappa, in inglese
        string cod = Function.Call<string>(Hash.GET_NAME_OF_ZONE, pos.X, pos.Y, pos.Z);
        if (cod == null || cod.Length == 0) return "";
        return ZonaNome(cod);
    }

    // codice della zona -> nome che si legge sulla mappa
    string ZonaNome(string c)
    {
        string k = c.ToUpper();
        if (k == "AIRP") return "Los Santos International";
        if (k == "ALAMO") return "Alamo Sea";
        if (k == "ALTA") return "Alta";
        if (k == "ARMYB") return "Fort Zancudo";
        if (k == "BANHAMC") return "Banham Canyon";
        if (k == "BANNING") return "Banning";
        if (k == "BEACH") return "Vespucci Beach";
        if (k == "BHAMCA") return "Banham Canyon";
        if (k == "BRADP") return "Braddock Pass";
        if (k == "BRADT") return "Braddock Tunnel";
        if (k == "BURTON") return "Burton";
        if (k == "CALAFB") return "Calafia Bridge";
        if (k == "CANNY") return "Raton Canyon";
        if (k == "CCREAK") return "Cassidy Creek";
        if (k == "CHAMH") return "Chamberlain Hills";
        if (k == "CHIL") return "Vinewood Hills";
        if (k == "CHU") return "Chumash";
        if (k == "CMSW") return "Chiliad Mountain State Wilderness";
        if (k == "CYPRE") return "Cypress Flats";
        if (k == "DAVIS") return "Davis";
        if (k == "DELBE") return "Del Perro Beach";
        if (k == "DELPE") return "Del Perro";
        if (k == "DELSOL") return "La Puerta";
        if (k == "DESRT") return "Grand Senora Desert";
        if (k == "DOWNT") return "Downtown";
        if (k == "DTVINE") return "Downtown Vinewood";
        if (k == "EAST_V") return "East Vinewood";
        if (k == "EBURO") return "El Burro Heights";
        if (k == "ELGORL") return "El Gordo Lighthouse";
        if (k == "ELYSIAN") return "Elysian Island";
        if (k == "GALFISH") return "Galilee";
        if (k == "GOLF") return "GWC and Golfing Society";
        if (k == "GRAPES") return "Grapeseed";
        if (k == "GREATC") return "Great Chaparral";
        if (k == "HARMO") return "Harmony";
        if (k == "HAWICK") return "Hawick";
        if (k == "HORS") return "Vinewood Racetrack";
        if (k == "HUMLAB") return "Humane Labs and Research";
        if (k == "JAIL") return "Bolingbroke Penitentiary";
        if (k == "KOREAT") return "Little Seoul";
        if (k == "LACT") return "Land Act Reservoir";
        if (k == "LAGO") return "Lago Zancudo";
        if (k == "LDAM") return "Land Act Dam";
        if (k == "LEGSQU") return "Legion Square";
        if (k == "LMESA") return "La Mesa";
        if (k == "LOSPUER") return "La Puerta";
        if (k == "MIRR") return "Mirror Park";
        if (k == "MORN") return "Morningwood";
        if (k == "MOVIE") return "Richards Majestic";
        if (k == "MTCHIL") return "Mount Chiliad";
        if (k == "MTGORDO") return "Mount Gordo";
        if (k == "MTJOSE") return "Mount Josiah";
        if (k == "MURRI") return "Murrieta Heights";
        if (k == "NCHU") return "North Chumash";
        if (k == "NOOSE") return "N.O.O.S.E.";
        if (k == "OCEANA") return "Pacific Ocean";
        if (k == "PALCOV") return "Paleto Cove";
        if (k == "PALETO") return "Paleto Bay";
        if (k == "PALFOR") return "Paleto Forest";
        if (k == "PALHIGH") return "Palomino Highlands";
        if (k == "PALMPOW") return "Palmer-Taylor Power Station";
        if (k == "PBLUFF") return "Pacific Bluffs";
        if (k == "PBOX") return "Pillbox Hill";
        if (k == "PROCOB") return "Procopio Beach";
        if (k == "RANCHO") return "Rancho";
        if (k == "RGLEN") return "Richman Glen";
        if (k == "RICHM") return "Richman";
        if (k == "ROCKF") return "Rockford Hills";
        if (k == "RTRAK") return "Redwood Lights Track";
        if (k == "SANAND") return "San Andreas";
        if (k == "SANCHIA") return "San Chianski Mountain Range";
        if (k == "SANDY") return "Sandy Shores";
        if (k == "SKID") return "Mission Row";
        if (k == "SLAB") return "Stab City";
        if (k == "STAD") return "Maze Bank Arena";
        if (k == "STRAW") return "Strawberry";
        if (k == "TATAMO") return "Tataviam Mountains";
        if (k == "TERMINA") return "Terminal";
        if (k == "TEXTI") return "Textile City";
        if (k == "TONGVAH") return "Tongva Hills";
        if (k == "TONGVAV") return "Tongva Valley";
        if (k == "VCANA") return "Vespucci Canals";
        if (k == "VESP") return "Vespucci";
        if (k == "VINE") return "Vinewood";
        if (k == "WINDF") return "Ron Alternates Wind Farm";
        if (k == "WVINE") return "West Vinewood";
        if (k == "ZANCUDO") return "Zancudo River";
        if (k == "ZP_ORT") return "Port of South Los Santos";
        if (k == "ZQ_UAR") return "Davis Quartz";
        return c;
    }

    // solo la via di un punto
    string ViaDi(Vector3 pos)
    {
        OutputArgument sh = new OutputArgument();
        OutputArgument ch = new OutputArgument();
        Function.Call(Hash.GET_STREET_NAME_AT_COORD, pos.X, pos.Y, pos.Z, sh, ch);
        string via = Function.Call<string>(Hash.GET_STREET_NAME_FROM_HASH_KEY, sh.GetResult<int>());
        if (via == null) return "";
        return via;
    }

    // indirizzo leggibile di un punto: via, zona
    string Indirizzo(Vector3 pos)
    {
        OutputArgument sh = new OutputArgument();
        OutputArgument ch = new OutputArgument();
        Function.Call(Hash.GET_STREET_NAME_AT_COORD, pos.X, pos.Y, pos.Z, sh, ch);
        string via = Function.Call<string>(Hash.GET_STREET_NAME_FROM_HASH_KEY, sh.GetResult<int>());
        if (via == null) via = "";

        string zona = Function.Call<string>(Hash.GET_NAME_OF_ZONE, pos.X, pos.Y, pos.Z);
        if (zona != null && zona.Length > 0)
        {
            string zl = Game.GetLocalizedString(zona);
            if (zl != null && zl.Length > 0 && zl != "NULL") zona = zl;
        }
        else zona = "";

        if (via.Length == 0) return zona;
        if (zona.Length == 0) return via;
        return via + ", " + zona;
    }

    // orario di gioco fra 'min' minuti, come testo hh:mm
    string OraPiu(int min)
    {
        int h = Function.Call<int>(Hash.GET_CLOCK_HOURS);
        int m = Function.Call<int>(Hash.GET_CLOCK_MINUTES);

        int tot = h * 60 + m + min;
        tot = ((tot % 1440) + 1440) % 1440;

        return (tot / 60).ToString("00") + ":" + (tot % 60).ToString("00");
    }

    // il trainer gia' rallenta l'orologio? si legge dal suo config.ini
    bool TrainerTieneOrologio()
    {
        try
        {
            string f = Path.Combine(TRAINER_DIR, "config.ini");
            if (!File.Exists(f)) return false;
            string[] rows = File.ReadAllLines(f);
            int i;
            for (i = 0; i < rows.Length; i++)
            {
                string r = rows[i].Trim();
                if (r.StartsWith("412=")) return (r.Substring(4).Trim() == "3");
            }
        }
        catch { }
        return false;
    }

    void TieniOrologio()
    {
        if (TrainerTieneOrologio())
        {
            if (clockMine)
            {
                Function.Call(Hash.PAUSE_CLOCK, false);
                clockMine = false;
            }
            return;
        }

        if (!clockMine)
        {
            Function.Call(Hash.PAUSE_CLOCK, true);
            clockMine = true;
            nextGameMin = Game.GameTime + MS_PER_MIN;
            return;
        }

        if (Game.GameTime - nextGameMin > 10000)
        {
            nextGameMin = Game.GameTime + MS_PER_MIN;
            return;
        }

        while (Game.GameTime >= nextGameMin)
        {
            Function.Call(Hash.ADD_TO_CLOCK_TIME, 0, 1, 0);
            nextGameMin = nextGameMin + MS_PER_MIN;
        }
    }

    string PescaNome(bool uomo)
    {
        if (nomiM.Count == 0 && nomiF.Count == 0) CaricaNomi();

        List<string> tutti = uomo ? nomiM : nomiF;
        List<string> resto = uomo ? restoM : restoF;
        if (tutti.Count == 0) return "";

        if (resto.Count == 0)
        {
            int i;
            for (i = 0; i < tutti.Count; i++) resto.Add(tutti[i]);
        }

        int k = rng.Next(resto.Count);
        string n = resto[k];
        resto.RemoveAt(k);
        return n;
    }

    static readonly string[] PEDS_M = new string[] {
        "a_m_y_business_01", "a_m_m_eastsa_01", "a_m_y_hipster_02",
        "a_m_y_skater_01", "a_m_m_tourist_01"
    };

    static readonly string[] PEDS_F = new string[] {
        "a_f_y_business_02", "a_f_y_hipster_01", "a_f_m_business_02",
        "a_f_y_tourist_01", "a_f_m_soucent_01"
    };

    public Uber()
    {
        Tick += OnTick;
        Aborted += OnAborted;

        ReadLang();
        CleanLeftovers();       // roba rimasta da una sessione precedente
    }

    // ============================================================
    //  ACCESO / SPENTO: lo decide il trainer via mods.ini
    // ============================================================
    bool ReadSwitch()
    {
        try
        {
            string f = Path.Combine(TRAINER_DIR, "mods.ini");
            if (!File.Exists(f)) return false;

            string[] rows = File.ReadAllLines(f);
            int i;
            for (i = 0; i < rows.Length; i++)
            {
                string r = rows[i].Trim();
                if (r.Length == 0 || r[0] == '#') continue;
                int eq = r.IndexOf('=');
                if (eq < 1) continue;
                if (r.Substring(0, eq).Trim().ToLower() != MOD_ID) continue;
                return r.Substring(eq + 1).Trim() == "1";
            }
        }
        catch { }
        return false;
    }

    void ReadLang()
    {
        try
        {
            string f = Path.Combine(TRAINER_DIR, "config.ini");
            if (!File.Exists(f)) return;
            string[] rows = File.ReadAllLines(f);
            int i;
            for (i = 0; i < rows.Length; i++)
            {
                string r = rows[i].Trim();
                if (r.StartsWith("900="))
                {
                    int v;
                    if (int.TryParse(r.Substring(4).Trim(), out v)) lang = v;
                    return;
                }
            }
        }
        catch { }
    }

    string L(string en, string it)
    {
        return lang == 1 ? it : en;
    }

    // ============================================================
    //  REGISTRO: cosa abbiamo creato, per poterlo cancellare dopo
    // ============================================================
    string SpawnFile()
    {
        return Path.Combine(MY_DIR, "spawn.txt");
    }

    void MarkSpawn(Vector3 pos)
    {
        try
        {
            Directory.CreateDirectory(MY_DIR);
            File.AppendAllText(SpawnFile(),
                pos.X.ToString("0.0", CultureInfo.InvariantCulture) + "|" +
                pos.Y.ToString("0.0", CultureInfo.InvariantCulture) + "|" +
                pos.Z.ToString("0.0", CultureInfo.InvariantCulture) + "\r\n");
        }
        catch { }
    }

    void ClearSpawnFile()
    {
        try
        {
            if (File.Exists(SpawnFile())) File.Delete(SpawnFile());
        }
        catch { }
    }

    // all'avvio: cancella i clienti e spegne i blip lasciati da prima
    void CleanLeftovers()
    {
        List<Vector3> spots = new List<Vector3>();
        try
        {
            if (File.Exists(SpawnFile()))
            {
                string[] rows = File.ReadAllLines(SpawnFile());
                int i;
                for (i = 0; i < rows.Length; i++)
                {
                    string[] q = rows[i].Split('|');
                    if (q.Length < 3) continue;
                    float x, y, z;
                    if (!float.TryParse(q[0], NumberStyles.Float, CultureInfo.InvariantCulture, out x)) continue;
                    if (!float.TryParse(q[1], NumberStyles.Float, CultureInfo.InvariantCulture, out y)) continue;
                    if (!float.TryParse(q[2], NumberStyles.Float, CultureInfo.InvariantCulture, out z)) continue;
                    spots.Add(new Vector3(x, y, z));
                }
            }
        }
        catch { }

        ClearSpawnFile();
        if (spots.Count == 0) return;

        // blip nostri (sprite 280 cliente, 1 destinazione) vicino a quei punti
        int[] sprites = new int[] { 280, 1 };
        int si;
        for (si = 0; si < sprites.Length; si++)
        {
            int b = Function.Call<int>(Hash.GET_FIRST_BLIP_INFO_ID, sprites[si]);
            int guard = 0;
            while (Function.Call<bool>(Hash.DOES_BLIP_EXIST, b) && guard < 60)
            {
                int nx = Function.Call<int>(Hash.GET_NEXT_BLIP_INFO_ID, sprites[si]);
                guard++;

                Vector3 c = Function.Call<Vector3>(Hash.GET_BLIP_INFO_ID_COORD, b);
                int k;
                for (k = 0; k < spots.Count; k++)
                {
                    Vector3 d = spots[k] - c;
                    d.Z = 0f;
                    if (d.Length() < 30f)
                    {
                        Function.Call(Hash.SET_BLIP_ROUTE, b, false);
                        Blip bl = new Blip(b);
                        if (bl.Exists()) bl.Delete();
                        break;
                    }
                }
                b = nx;
            }
        }

        // clienti abbandonati: sono ped persistenti fermi su quei punti
        Ped me = Game.Player.Character;
        if (me == null || !me.Exists()) return;

        int j;
        for (j = 0; j < spots.Count; j++)
        {
            if ((spots[j] - me.Position).Length() > 300f) continue;

            Ped[] near = World.GetNearbyPeds(me, 300f);
            int i;
            for (i = 0; i < near.Length; i++)
            {
                Ped q = near[i];
                if (q == null || !q.Exists()) continue;
                if (q.Handle == me.Handle) continue;
                if ((q.Position - spots[j]).Length() > 15f) continue;
                if (!Function.Call<bool>(Hash.IS_ENTITY_A_MISSION_ENTITY, q)) continue;

                Function.Call(Hash.SET_ENTITY_AS_MISSION_ENTITY, q, true, true);
                q.Delete();
            }
        }
    }

    // ============================================================
    //  PUNTI: dove aspetta il cliente e dove scende
    // ============================================================
    bool IsFreewayAt(Vector3 pos)
    {
        OutputArgument sh = new OutputArgument();
        OutputArgument ch = new OutputArgument();
        Function.Call(Hash.GET_STREET_NAME_AT_COORD, pos.X, pos.Y, pos.Z, sh, ch);
        string st = Function.Call<string>(Hash.GET_STREET_NAME_FROM_HASH_KEY, sh.GetResult<int>());
        if (st == null) return false;
        string low = st.ToLower();
        return low.Contains("freeway") || low.Contains("highway");
    }

    // un punto stradale con un nome di via vero, entro la distanza chiesta
    Vector3 RoadPoint(Vector3 origin, float minD, float maxD)
    {
        int t;
        for (t = 0; t < 30; t++)
        {
            double ang = rng.NextDouble() * Math.PI * 2.0;
            double rad = minD + rng.NextDouble() * (maxD - minD);
            float px = origin.X + (float)(Math.Cos(ang) * rad);
            float py = origin.Y + (float)(Math.Sin(ang) * rad);

            OutputArgument nodeOut = new OutputArgument();
            OutputArgument headOut = new OutputArgument();
            if (!Function.Call<bool>(Hash.GET_CLOSEST_VEHICLE_NODE_WITH_HEADING,
                                     px, py, origin.Z, nodeOut, headOut, 1, 3.0f, 0)) continue;

            Vector3 node = nodeOut.GetResult<Vector3>();
            float dist = (node - origin).Length();
            if (dist < minD || dist > maxD) continue;

            // niente autostrada: nessuno aspetta un passaggio in tangenziale
            if (IsFreewayAt(node)) continue;

            // deve avere un nome di via
            OutputArgument sh = new OutputArgument();
            OutputArgument ch = new OutputArgument();
            Function.Call(Hash.GET_STREET_NAME_AT_COORD, node.X, node.Y, node.Z, sh, ch);
            string via = Function.Call<string>(Hash.GET_STREET_NAME_FROM_HASH_KEY, sh.GetResult<int>());
            if (via == null || via.Trim().Length == 0) continue;

            // il nome della via non basta: anche i vialetti del golf ce l'hanno.
            // Questa e' la prova vera: il navigatore del gioco ci puo' passare?
            // Sui percorsi privati (golf, aeroporto, base militare) risponde no.
            int nodeId = Function.Call<int>(Hash.GET_NTH_CLOSEST_VEHICLE_NODE_ID,
                                            node.X, node.Y, node.Z, 1, 1, 3.0f, 0f);
            if (!Function.Call<bool>(Hash.IS_VEHICLE_NODE_ID_VALID, nodeId)) continue;
            if (!Function.Call<bool>(Hash.GET_VEHICLE_NODE_IS_GPS_ALLOWED, nodeId)) continue;

            // e comunque le zone dove un cliente non ti chiama mai
            if (ZonaVietata(node)) continue;

            // niente acqua sotto i piedi
            OutputArgument wo = new OutputArgument();
            if (Function.Call<bool>(Hash.GET_WATER_HEIGHT, node.X, node.Y, node.Z, wo))
            {
                if (node.Z < wo.GetResult<float>() + 1.5f) continue;
            }

            return node;
        }
        return Vector3.Zero;
    }

    // zone dove non si prende e non si lascia nessuno
    bool ZonaVietata(Vector3 pos)
    {
        string z = Function.Call<string>(Hash.GET_NAME_OF_ZONE, pos.X, pos.Y, pos.Z);
        if (z == null) return false;
        z = z.ToUpper();

        // GOLF campo da golf, AIRP e ARMYB aeroporto e base militare,
        // PRISON carcere, CANNY e altre zone selvatiche senza case
        if (z == "GOLF") return true;
        if (z == "AIRP") return true;
        if (z == "ARMYB") return true;
        if (z == "PRISON") return true;
        if (z == "OCEANA") return true;
        return false;
    }

    // Il punto d'incontro: la strada carrozzabile piu' vicina al cliente,
    // sul ciglio, non in mezzo alla carreggiata. Serve perche' il cliente
    // puo' trovarsi ovunque - dentro un giardino, su un green da golf -
    // e a te serve un posto dove ci si possa accostare.
    Vector3 MeetingPoint(Vector3 near)
    {
        // NB: qui si usa solo GET_CLOSEST_VEHICLE_NODE_WITH_HEADING.
        // La versione "nth" vuole piu' argomenti di quelli che sembrano e
        // sbagliarne il numero significa scrivere in memoria a caso: e' quello
        // che ha fatto crashare il gioco. Per cercare piu' in la' si sposta
        // il punto di partenza, non si cambia native.
        float[] offX = new float[] { 0f, 20f, -20f, 0f, 0f, 45f, -45f, 0f, 0f };
        float[] offY = new float[] { 0f, 0f, 0f, 20f, -20f, 0f, 0f, 45f, -45f };

        int i;
        for (i = 0; i < offX.Length; i++)
        {
            OutputArgument nodeOut = new OutputArgument();
            OutputArgument headOut = new OutputArgument();

            if (!Function.Call<bool>(Hash.GET_CLOSEST_VEHICLE_NODE_WITH_HEADING,
                                     near.X + offX[i], near.Y + offY[i], near.Z,
                                     nodeOut, headOut, 1, 3.0f, 0)) continue;

            Vector3 node = nodeOut.GetResult<Vector3>();
            if (node.X == 0f && node.Y == 0f) continue;
            if ((node - near).Length() > 120f) continue;

            int id = Function.Call<int>(Hash.GET_NTH_CLOSEST_VEHICLE_NODE_ID,
                                        node.X, node.Y, node.Z, 1, 1, 3.0f, 0f);
            if (!Function.Call<bool>(Hash.IS_VEHICLE_NODE_ID_VALID, id)) continue;
            if (!Function.Call<bool>(Hash.GET_VEHICLE_NODE_IS_GPS_ALLOWED, id)) continue;

            return SidewalkAt(node);
        }

        return SidewalkAt(near);
    }

    // il posto dove un pedone puo' davvero stare: e' la stessa mappa che il
    // gioco usa per mettere i passanti sui marciapiedi. Lontano dal giocatore
    // non e' caricata, quindi prima la si chiede e si aspetta.
    Vector3 SidewalkAt(Vector3 pos)
    {
        Function.Call(Hash.ADD_NAVMESH_REQUIRED_REGION, pos.X, pos.Y, 60f);

        int waited = 0;
        while (!Function.Call<bool>(Hash.IS_NAVMESH_LOADED_IN_AREA,
                                    pos.X - 40f, pos.Y - 40f, pos.Z - 30f,
                                    pos.X + 40f, pos.Y + 40f, pos.Z + 30f)
               && waited < 1500)
        {
            Script.Wait(50);
            waited += 50;
        }

        OutputArgument sp = new OutputArgument();
        if (Function.Call<bool>(Hash.GET_SAFE_COORD_FOR_PED, pos.X, pos.Y, pos.Z, true, sp, 16))
        {
            Vector3 r = sp.GetResult<Vector3>();
            if (r.X != 0f || r.Y != 0f) return r;
        }

        // ripiego: il bordo della carreggiata
        OutputArgument bx = new OutputArgument();
        OutputArgument by = new OutputArgument();
        if (Function.Call<bool>(Hash.GET_ROAD_BOUNDARY_USING_HEADING, pos.X, pos.Y, pos.Z, 0f, bx, by))
        {
            float gx = bx.GetResult<float>();
            float gy = by.GetResult<float>();
            OutputArgument gz = new OutputArgument();
            if (Function.Call<bool>(Hash.GET_GROUND_Z_FOR_3D_COORD, gx, gy, pos.Z + 5f, gz, false))
            {
                return new Vector3(gx, gy, gz.GetResult<float>());
            }
        }

        return pos;
    }

    // ============================================================
    //  LIMITE DI VELOCITA'
    //  I numeri sono quelli che hai impostato nel trainer: si leggono
    //  dal suo config.ini, cosi' non ci sono due verita' diverse.
    // ============================================================
    void ReadLimits()
    {
        try
        {
            string f = Path.Combine(TRAINER_DIR, "config.ini");
            if (!File.Exists(f)) return;
            string[] rows = File.ReadAllLines(f);
            int i;
            for (i = 0; i < rows.Length; i++)
            {
                string r = rows[i].Trim();
                int eq = r.IndexOf('=');
                if (eq < 1) continue;
                string id = r.Substring(0, eq).Trim();
                int val;
                if (!int.TryParse(r.Substring(eq + 1).Trim(), out val)) continue;
                if (id == "263") limCity = val;
                else if (id == "264") limHwy = val;
                else if (id == "265") limDirt = val;
            }
        }
        catch { }
    }

    int LimitHere(Vehicle v)
    {
        Vector3 pp = v.Position;

        OutputArgument sh = new OutputArgument();
        OutputArgument ch = new OutputArgument();
        Function.Call(Hash.GET_STREET_NAME_AT_COORD, pp.X, pp.Y, pp.Z, sh, ch);
        string street = Function.Call<string>(Hash.GET_STREET_NAME_FROM_HASH_KEY, sh.GetResult<int>());
        if (street == null) street = "";
        string low = street.ToLower();

        bool named = street.Length > 0 && low != "unknown";
        bool onRoad = Function.Call<bool>(Hash.IS_POINT_ON_ROAD, pp.X, pp.Y, pp.Z, v);

        if (low.Contains("freeway") || low.Contains("highway")) return limHwy;
        if (!named && !onRoad) return limDirt;
        return limCity;
    }

    // ============================================================
    //  BLIP E NAVIGATORE
    // ============================================================
    void BlipTo(Vector3 pos, int sprite, int colour)
    {
        if (blip == 0 || !Function.Call<bool>(Hash.DOES_BLIP_EXIST, blip))
        {
            blip = Function.Call<int>(Hash.ADD_BLIP_FOR_COORD, pos.X, pos.Y, pos.Z);
        }
        else
        {
            Function.Call(Hash.SET_BLIP_COORDS, blip, pos.X, pos.Y, pos.Z);
        }

        Function.Call(Hash.SET_BLIP_SPRITE, blip, sprite);
        Function.Call(Hash.SET_BLIP_COLOUR, blip, colour);
        Function.Call(Hash.SET_BLIP_SCALE, blip, 0.9f);
        Function.Call(Hash.SET_BLIP_ALPHA, blip, 255);
        Function.Call(Hash.SET_BLIP_DISPLAY, blip, 2);
        Function.Call(Hash.SET_BLIP_ROUTE, blip, false);

        // il waypoint vero: e' l'unica rotta che il navigatore sa leggere
        Function.Call(Hash.SET_NEW_WAYPOINT, pos.X, pos.Y);

        MarkSpawn(pos);
    }

    void KillBlip()
    {
        if (blip != 0 && Function.Call<bool>(Hash.DOES_BLIP_EXIST, blip))
        {
            Function.Call(Hash.SET_BLIP_ROUTE, blip, false);
            Blip b = new Blip(blip);
            if (b.Exists()) b.Delete();
        }
        blip = 0;
        // solo SET_WAYPOINT_OFF: CLEAR_GPS_PLAYER_WAYPOINT lasciava il gioco
        // senza piu' la rotta viola quando poi mettevi tu un waypoint
        Function.Call(Hash.SET_WAYPOINT_OFF);
    }

    // ============================================================
    //  PULIZIA
    // ============================================================
    void Reset(bool keepJob)
    {
        pickupLimit = 0;
        mood = 100f;
        offerta = false;
        if (client != null && client.Exists())
        {
            Function.Call(Hash.SET_PED_KEEP_TASK, client, false);
            if (clientWasReal)
            {
                // era un passante vero: gli si ridà la sua vita
                client.MarkAsNoLongerNeeded();
                Function.Call(Hash.TASK_WANDER_STANDARD, client, 10f, 10);
            }
            else
            {
                client.Delete();
            }
        }
        client = null;
        clientWasReal = false;
        walking = false;
        walkAt = 0;
        boarding = false;
        hintAt = 0;

        KillBlip();
        ClearSpawnFile();

        state = keepJob ? 1 : 0;
        next = Game.GameTime + 5000;
        mood = 100f;
        angry = false;
    }

    void ResetIn(bool keepJob, int delay)
    {
        Reset(keepJob);
        next = Game.GameTime + delay;
    }

    void OnAborted(object sender, EventArgs e)
    {
        Reset(false);
    }

    // ============================================================
    //  IL LAVORO
    // ============================================================
    void OnTick(object sender, EventArgs e)
    {
        int now = Game.GameTime;

        // ogni secondo si guarda l'interruttore del trainer
        if (now > checkNext)
        {
            checkNext = now + 1000;
            bool want = ReadSwitch();
            if (want != on)
            {
                on = want;
                ReadLang();
                if (!on)
                {
                    Reset(false);
                    Notification.PostTicker("~y~Uber~s~ " + L("off", "spento"), false);
                }
                else
                {
                    state = 1;
                    next = now + 3000;
                    Notification.PostTicker("~g~Uber~s~ " + L("on - get in a car",
                        "acceso - sali in macchina"), false);
                }
            }
        }

        if (!on) return;

        TieniOrologio();

        Ped p = Game.Player.Character;
        if (p == null || !p.Exists() || p.IsDead) return;

        Vehicle v = p.CurrentVehicle;

        // se scendi mentre il cliente sta scendendo, si libera lo stesso
        if ((v == null || !v.Exists()) && state == 4)
        {
            if (client != null && client.Exists())
            {
                Function.Call(Hash.SET_PED_KEEP_TASK, client, false);
                Function.Call(Hash.TASK_WANDER_STANDARD, client, 10f, 10);
                client.IsPersistent = false;
                client.MarkAsNoLongerNeeded();
            }
            client = null;
            clientWasReal = false;
            boarding = false;
            ClearSpawnFile();
            state = 1;
            next = now + 60000;
            return;
        }

        if (v == null || !v.Exists()) { DrawBox(); return; }

        // ---- 1. attesa della chiamata ----
        if (state <= 1)
        {
            if (now < next) { DrawBox(); return; }

            Vector3 f = RoadPoint(p.Position, 700f, 1600f);
            if (f.X == 0f && f.Y == 0f) { next = now + 4000; return; }

            Vector3 t = RoadPoint(f, 600f, 2500f);
            if (t.X == 0f && t.Y == 0f) { next = now + 4000; return; }

            from = f;
            to = t;
            state = 2;

            // la corsa si prepara tutta prima di avvisarti: i due indirizzi,
            // il sesso del cliente e il suo nome. Poi arriva l'ordine.
            // via con un numero civico inventato, deciso una volta per corsa
            addrFrom = ViaDi(f);
            addrTo = ViaDi(t);
            if (addrFrom.Length > 0) addrFrom = addrFrom + ", " + rng.Next(100, 9800);
            if (addrTo.Length > 0) addrTo = addrTo + ", " + rng.Next(100, 9800);
            zonaFrom = ZonaDi(f);
            zonaTo = ZonaDi(t);
            clientUomo = (rng.Next(2) == 0);
            clientName = PescaNome(clientUomo);

            // il prezzo si decide subito, come nell'app vera
            fare = 15 + (int)((t - f).Length() * 0.05f);

            float rl = (t - f).Length();
            distTxt = (rl / 1000f).ToString("0.0", CultureInfo.InvariantCulture) + " km";

            // gli orari si calcolano quando accetti: il tempo parte da li'
            oraPickup = "";
            oraArrivo = "";

            offerta = true;
            offerScade = now + 30000;   // trenta secondi per decidere

            // il telefono si apre con il suono del telefono del gioco
            Function.Call(Hash.PLAY_SOUND_FRONTEND, -1, "Text_Arrive_Tone",
                          "Phone_SoundSet_Default", true);

            Notification.PostTicker("~y~Uber~s~ " + L("new booking", "nuova prenotazione")
                + ": " + clientName + " - " + addrFrom, false);
            DrawBox();
            return;
        }

        // ---- 2. vado a prendere ----
        if (state == 2)
        {
            // finche' non accetti, il telefono mostra solo la proposta
            if (offerta)
            {
                // A / INVIO accetta, B / BACKSPACE rifiuta
                if (now > offerScade)
                {
                    // scaduta: come un rifiuto, tre minuti prima della prossima
                    offerta = false;
                    Notification.PostTicker("~y~Uber~s~ " + L("offer expired", "offerta scaduta"), false);
                    ResetIn(true, 180000);
                    return;
                }

                if (Function.Call<bool>(Hash.IS_CONTROL_JUST_PRESSED, 0, 201))
                {
                    offerta = false;
                    pickupLimit = Game.GameTime + 30 * MS_PER_MIN;
                    lateNext = pickupLimit + MS_PER_MIN;

                    // adesso che hai accettato si fissano gli orari
                    float rl2 = (to - from).Length();
                    int secCorsa = (int)(rl2 / 6f) + 60;
                    int minCorsa = (int)(secCorsa * 1000f / (float)MS_PER_MIN);
                    if (minCorsa < 1) minCorsa = 1;
                    oraPickup = OraPiu(30);
                    oraArrivo = OraPiu(30 + minCorsa);
                    Function.Call(Hash.PLAY_SOUND_FRONTEND, -1, "SELECT",
                                  "HUD_FRONTEND_DEFAULT_SOUNDSET", true);
                    BlipTo(from, 280, 5);
                    Notification.PostTicker("~g~Uber~s~ " + L("ride accepted", "corsa accettata")
                        + " - " + L("pick up the client", "vai a prendere il cliente"), false);
                }
                else if (Function.Call<bool>(Hash.IS_CONTROL_JUST_PRESSED, 0, 202))
                {
                    offerta = false;
                    Function.Call(Hash.PLAY_SOUND_FRONTEND, -1, "Text_Arrive_Tone",
                                  "Phone_SoundSet_Default", true);
                    Notification.PostTicker("~y~Uber~s~ " + L("ride refused", "corsa rifiutata"), false);
                    ResetIn(true, 180000);   // rifiutata: tre minuti di attesa
                    return;
                }

                DrawBox();
                return;
            }

            // 5% di gradimento ogni minuto di gioco di ritardo sul ritiro
            if (pickupLimit > 0 && now > lateNext)
            {
                lateNext = lateNext + MS_PER_MIN;
                mood = mood - 5f;
                if (mood < 0f) mood = 0f;
            }

            float dist = (from - p.Position).Length();

            if (dist < 140f && (client == null || !client.Exists()))
            {
                MakeClient();
                DrawBox();
                return;
            }

            // Il cliente non si muove di un metro finche' non sei arrivato
            // al waypoint. Solo allora, e solo col clacson, viene a salire:
            // cosi' e' lui a raggiungere te, nel punto dove ti sei fermato,
            // e non si mette a rincorrerti in mezzo alla strada.

            if (client != null && client.Exists() && dist < 25f
                && Function.Call<float>(Hash.GET_ENTITY_SPEED, v) < 2f)
            {
                if (!client.IsInVehicle(v))
                {
                    // sta gia' salendo: lo si lascia in pace
                    if (Function.Call<bool>(Hash.IS_PED_GETTING_INTO_A_VEHICLE, client))
                    {
                        DrawBox();
                        return;
                    }

                    // e' il clacson a chiamarlo, come nella vita
                    bool horn = Function.Call<bool>(Hash.IS_HORN_ACTIVE, v)
                             || Function.Call<bool>(Hash.IS_CONTROL_PRESSED, 0, 86);

                    if (!boarding)
                    {
                        if (!horn)
                        {
                            if (now - hintAt > 8000)
                            {
                                hintAt = now;
                                Notification.PostTicker("~y~" + L("Honk to call the client",
                                    "Suona il clacson per chiamarlo"), false);
                            }
                            DrawBox();
                            return;
                        }
                        boarding = true;
                    }

                    // il comando va dato una volta sola: ripeterlo ogni frame
                    // fa ricominciare l'animazione e non sale mai
                    if (now - enterAt < 10000) { DrawBox(); return; }
                    enterAt = now;

                    Function.Call(Hash.SET_VEHICLE_DOORS_LOCKED, v, 1);

                    int seat = -2;
                    int si;
                    for (si = 0; si < 4; si++)
                    {
                        if (Function.Call<bool>(Hash.IS_VEHICLE_SEAT_FREE, v, si)) { seat = si; break; }
                    }
                    if (seat == -2)
                    {
                        Notification.PostTicker("~r~" + L("No free seat", "Nessun posto libero"), false);
                        DrawBox();
                        return;
                    }

                    // si ripulisce prima: lo scenario "in piedi al telefono" e il
                    // blocco degli eventi gli impedivano di accettare il comando
                    Function.Call(Hash.TASK_SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, client, false);
                    Function.Call(Hash.CLEAR_PED_TASKS_IMMEDIATELY, client);
                    Function.Call(Hash.SET_PED_KEEP_TASK, client, true);
                    Function.Call(Hash.TASK_ENTER_VEHICLE, client, v, 20000, seat, 2.0f, 1, 0);

                    DrawBox();
                    return;
                }

                float rideLen = (to - from).Length();
                deadline = now + (int)(rideLen / 6f) * 1000 + 60000;

                state = 3;
                // il gradimento non si azzera: se sei arrivato in ritardo
                // il cliente sale gia' con qualche stella in meno
                pickupLimit = 0;
                angry = false;
                bodyWas = v.BodyHealth;

                BlipTo(to, 1, 2);
                Notification.PostTicker("~g~" + L("Destination set", "Destinazione impostata")
                    + "~s~  ~y~$" + fare, false);
            }

            DrawBox();
            return;
        }

        // ---- 3. corsa in corso ----
        if (state == 3)
        {
            if (client == null || !client.Exists() || !client.IsInVehicle(v))
            {
                Notification.PostTicker("~r~" + L("The client left", "Il cliente e' sceso"), false);
                Reset(true);
                return;
            }

            int pid = Function.Call<int>(Hash.PLAYER_ID);
            if (Function.Call<int>(Hash.GET_PLAYER_WANTED_LEVEL, pid) > 0)
            {
                Function.Call(Hash.TASK_LEAVE_VEHICLE, client, v, 4160);
                Notification.PostTicker("~r~" + L("Police! The client fled",
                    "Polizia! Il cliente e' scappato") + "~s~ - " + L("no fare", "niente paga"), false);
                ResetIn(true, 60000);
                return;
            }

            float body = v.BodyHealth;
            if (body < bodyWas - 1f)
            {
                float dmg = bodyWas - body;
                bodyWas = body;
                mood = mood - dmg * 0.6f;
                Function.Call(Hash.PLAY_SOUND_FRONTEND, -1, "Beep_Red",
                              "DLC_HEIST_HACKING_SNAKE_SOUNDS", true);
            }
            else if (body > bodyWas)
            {
                bodyWas = body;
            }

            // ---- velocita' oltre il limite ----
            // Il cliente e' seduto dietro e guarda il tachimetro: se sfori
            // il limite comincia a innervosirsi, e piu' vai forte piu' in
            // fretta si innervosisce.
            if (now > limNext)
            {
                limNext = now + 5000;
                ReadLimits();
            }

            int lim = LimitHere(v);
            int kmh = (int)(Function.Call<float>(Hash.GET_ENTITY_SPEED, v) * 3.6f);
            int over = kmh - lim;

            if (over > 40)
            {
                // fino a 40 km/h sopra il limite non dice niente: si
                // innervosisce solo oltre, e piu' vai forte piu' in fretta
                float rate = 0.8f + (float)(over - 40) * 0.10f;
                mood = mood - Game.LastFrameTime * rate;
            }
            else if (over < -5 && mood < 100f)
            {
                // se torni sotto il limite si ricalma, ma molto piano
                mood = mood + Game.LastFrameTime * 0.4f;
                if (mood > 100f) mood = 100f;
            }

            if (mood < 0f) mood = 0f;

            if (mood <= 0f && !angry)
            {
                angry = true;
                Notification.PostTicker("~r~" + L("The client had enough",
                    "Il cliente non ne puo' piu'") + "~s~ - "
                    + L("he gets off at the next stop", "scende alla prima sosta"), false);
            }

            if (angry && Function.Call<float>(Hash.GET_ENTITY_SPEED, v) < 3f)
            {
                Function.Call(Hash.TASK_LEAVE_VEHICLE, client, v, 0);
                Notification.PostTicker("~r~" + L("Ride cancelled, no fare",
                    "Corsa annullata, niente paga"), false);
                ResetIn(true, 60000);
                return;
            }

            if (now > deadline)
            {
                Function.Call(Hash.TASK_LEAVE_VEHICLE, client, v, 0);
                Notification.PostTicker("~r~" + L("Too slow, no fare", "Troppo lento, niente paga"), false);
                ResetIn(true, 30000);
                return;
            }

            if ((to - p.Position).Length() < 25f
                && Function.Call<float>(Hash.GET_ENTITY_SPEED, v) < 2f)
            {
                Game.Player.Money = Game.Player.Money + fare;
                earned += fare;
                rides++;

                // scende come chiunque: apre la porta, mette i piedi a terra
                // e se ne va per la sua strada. Non sparisce sul sedile.
                Function.Call(Hash.TASK_SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, client, false);
                Function.Call(Hash.SET_PED_KEEP_TASK, client, true);
                Function.Call(Hash.TASK_LEAVE_VEHICLE, client, v, 0);

                // 5% di gradimento per ogni minuto di gioco di anticipo
                int anticipo = (deadline - now) / MS_PER_MIN;
                if (anticipo > 0)
                {
                    mood = mood + anticipo * 5f;
                    if (mood > 100f) mood = 100f;
                }

                Notification.PostTicker("~g~" + L("Ride complete", "Corsa completata")
                    + "~s~  +$" + fare, false);
                SaveStats();

                state = 4;
                dropAt = now;
                phUpUntil = now + 12000;   // il telefono resta su per leggere
                KillBlip();
                return;
            }

            DrawBox();
            return;
        }

        // ---- 4. il cliente scende ----
        if (state == 4)
        {
            bool fuori = (client == null || !client.Exists() || !client.IsInVehicle(v));

            if (fuori || now - dropAt > 12000)
            {
                if (client != null && client.Exists())
                {
                    // da qui in poi e' un passante come tutti gli altri
                    Function.Call(Hash.SET_PED_KEEP_TASK, client, false);
                    Function.Call(Hash.TASK_WANDER_STANDARD, client, 10f, 10);
                    client.IsPersistent = false;
                    client.MarkAsNoLongerNeeded();
                }
                client = null;
                clientWasReal = false;
                walking = false;
                boarding = false;
                ClearSpawnFile();

                // il telefono si chiude e sparisce: la prossima prenotazione
                // arriva dopo mezzo minuto vero
                Function.Call(Hash.PLAY_SOUND_FRONTEND, -1, "Text_Arrive_Tone",
                              "Phone_SoundSet_Default", true);

                state = 1;
                next = now + 30000;
                return;
            }

            DrawBox();
        }
    }

    // ============================================================
    //  IL CLIENTE
    //  Prima si cerca un passante vero gia' in piedi da quelle parti:
    //  il gioco lo ha messo lui sul marciapiede, quindi sta nel posto
    //  giusto per definizione. Solo se non c'e' nessuno se ne crea uno,
    //  e allora si usa la navmesh per trovare dove puo' stare.
    // ============================================================
    void MakeClient()
    {
        Ped me = Game.Player.Character;

        Ped[] near = World.GetNearbyPeds(me, 200f);
        Ped best = null;
        float bestD = 999f;
        int i;
        for (i = 0; i < near.Length; i++)
        {
            Ped q = near[i];
            if (q == null || !q.Exists() || q.IsDead) continue;
            if (q.Handle == me.Handle) continue;
            if (q.IsInVehicle()) continue;
            if (!Function.Call<bool>(Hash.IS_PED_ON_FOOT, q)) continue;
            if (Function.Call<bool>(Hash.IS_PED_A_PLAYER, q)) continue;
            // deve essere del sesso deciso alla prenotazione
            if (Function.Call<bool>(Hash.IS_PED_MALE, q) != clientUomo) continue;
            if (q.IsInCombat || q.IsRagdoll) continue;
            if (Function.Call<bool>(Hash.IS_ENTITY_A_MISSION_ENTITY, q)) continue;  // roba di altri script

            float d = (q.Position - from).Length();
            if (d > 45f) continue;
            if (d < bestD) { bestD = d; best = q; }
        }

        if (best != null)
        {
            client = best;
            clientWasReal = true;
            client.IsPersistent = true;
            from = client.Position;
        }
        else
        {
            Vector3 spot = SidewalkAt(from);

            string[] lista = clientUomo ? PEDS_M : PEDS_F;
            string mdl = lista[rng.Next(0, lista.Length)];
            Model m = new Model(mdl);
            m.Request();
            int waited = 0;
            while (!m.IsLoaded && waited < 2000)
            {
                Script.Wait(50);
                waited += 50;
            }
            if (!m.IsLoaded) return;

            client = World.CreatePed(m, spot);
            m.MarkAsNoLongerNeeded();
            if (client == null || !client.Exists()) return;

            client.IsPersistent = true;
            clientWasReal = false;
            from = client.Position;
            MarkSpawn(from);
        }

        Function.Call(Hash.SET_PED_KEEP_TASK, client, true);
        Function.Call(Hash.TASK_SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, client, true);

        // il cliente si porta da solo sul ciglio della strada piu' vicina:
        // e' li' che ti aspetta, non dove il gioco lo ha messo
        Vector3 meet = MeetingPoint(client.Position);
        from = meet;

        if ((client.Position - meet).Length() > 4f)
        {
            Function.Call(Hash.TASK_GO_TO_COORD_ANY_MEANS, client,
                          meet.X, meet.Y, meet.Z, 1.5f, 0, false, 786603, 0f);
        }
        else
        {
            Function.Call(Hash.TASK_START_SCENARIO_IN_PLACE, client, "WORLD_HUMAN_STAND_MOBILE", 0, true);
        }

        BlipTo(meet, 280, 5);
    }

    // ============================================================
    //  STATISTICHE
    // ============================================================
    void SaveStats()
    {
        try
        {
            Directory.CreateDirectory(MY_DIR);
            File.WriteAllText(Path.Combine(MY_DIR, "stats.txt"),
                "corse=" + rides + "\r\nguadagno=" + earned + "\r\n");
        }
        catch { }
    }

    // ============================================================
    //  RIQUADRO A SCHERMO: tariffa, tempo, gradimento
    //  Sta accanto ai quadrati della velocita' del trainer.
    // ============================================================
    void DrawBox()
    {
        // telefono: texture uber_phone dentro cruscotto.ytd
        float phW = 200f;                       // larghezza a schermo
        float phH = phW * (763f / 552f);        // proporzioni originali
        float phX = 1150f;                      // centro X

        float phYup = 629f;                     // tutto in vista
        float phYdown = phYup + 135f;           // quasi chiuso: solo il logo

        // sale quando c'e' una corsa, scende quando non c'e' piu' niente
        bool su = (state >= 2) || (Game.GameTime < phUpUntil);
        float target = su ? 1f : 0f;
        float step = Game.LastFrameTime * 2.5f;
        if (phSlide < target) { phSlide = phSlide + step; if (phSlide > 1f) phSlide = 1f; }
        else if (phSlide > target) { phSlide = phSlide - step; if (phSlide < 0f) phSlide = 0f; }

        float phY = phYdown + (phYup - phYdown) * phSlide;

        Function.Call(Hash.REQUEST_STREAMED_TEXTURE_DICT, "cruscotto", false);
        if (Function.Call<bool>(Hash.HAS_STREAMED_TEXTURE_DICT_LOADED, "cruscotto"))
        {
            Function.Call(Hash.DRAW_SPRITE, "cruscotto", "uber_phone",
                          phX / 1280f, phY / 720f, phW / 1280f, phH / 720f,
                          0f, 255, 255, 255, 255, false);
        }

        // orario del gioco: c'e' sempre, si sposta col telefono
        int oH = Function.Call<int>(Hash.GET_CLOCK_HOURS);
        int oM = Function.Call<int>(Hash.GET_CLOCK_MINUTES);
        string ora = oH.ToString("00") + ":" + oM.ToString("00");

        DrawText(ora, phX - phW * 0.5f + 31f, phY - phH * 0.5f + 22f, 0.17f,
                 Color.FromArgb(255, 0, 0, 0));

        // senza corsa in corso il telefono mostra solo l'ora
        if (state < 2 && Game.GameTime >= phUpUntil) return;

        // i due indirizzi: dove prendi e dove porti
        Color addrCol = Color.FromArgb(255, 0, 0, 0);
        Color zonaCol = Color.FromArgb(255, 40, 40, 45);
        Color oraCol = Color.FromArgb(255, 30, 80, 200);   // blu degli orari
        float ax = phX - phW * 0.5f + 55f;

        // proposta non ancora accettata: un pannello bianco copre i dati
        if (offerta)
        {
            // dal nome (in alto a sinistra) alla riga della distanza (in basso),
            // largo quanto la colonna del nome e quella del prezzo
            float pxL = ax - 22f;
            float pxR = phX + phW * 0.5f - 33f;
            float pyT = phY + phH * 0.5f - 192f;
            float pyB = phY + phH * 0.5f - 70f;

            DrawRect(pxL, pyT, pxR - pxL, pyB - pyT, 255, 255, 255, 255);

            DrawText(L("new ride", "nuova corsa"), pxL + 6f, pyT + 14f, 0.28f,
                     Color.FromArgb(255, 0, 0, 0));
            int rest = (offerScade - Game.GameTime) / 1000;
            if (rest < 0) rest = 0;
            DrawTextRight(rest + "s", pxR - 6f, pyT + 14f, 0.28f,
                          rest < 10 ? Color.FromArgb(255, 200, 30, 30)
                                    : Color.FromArgb(255, 30, 80, 200));

            DrawText(L("A  accept", "A  accetta"), pxL + 6f, pyT + 52f, 0.24f,
                     Color.FromArgb(255, 0, 96, 57));
            DrawText(L("B  refuse", "B  rifiuta"), pxL + 6f, pyT + 74f, 0.24f,
                     Color.FromArgb(255, 170, 30, 30));
            return;
        }

        // nome e cognome del cliente
        DrawText(clientName, ax - 20f, phY + phH * 0.5f - 190f, 0.23f, zonaCol);

        // timer della corsa, sopra il prezzo: solo a cliente a bordo
        if (state >= 3)
        {
            int left = (deadline - Game.GameTime) / 1000;
            if (left < 0) left = 0;
            // sotto il minuto diventa rosso
            Color tCol = (left < 60)
                         ? Color.FromArgb(255, 200, 30, 30)
                         : Color.FromArgb(255, 30, 80, 200);

            DrawTextRight((left / 60) + ":" + (left % 60).ToString("00"),
                          phX + phW * 0.5f - 35f, phY + phH * 0.5f - 220f, 0.56f, tCol);
        }

        // quanto paga la corsa, dalla parte opposta
        DrawTextRight("$" + fare, phX + phW * 0.5f - 35f,
                      phY + phH * 0.5f - 190f, 0.23f,
                      Color.FromArgb(255, 0, 96, 57));

        // ritiro: zona sopra nel testo grande, via sotto nel piccolo
        // leggero bold: lo stesso testo ripassato con mezzo pixel di scarto
        DrawText(zonaFrom, ax, phY + phH * 0.5f - 158f, 0.23f, addrCol);
        DrawText(zonaFrom, ax + 0.5f, phY + phH * 0.5f - 158f, 0.23f, addrCol);
        DrawText(addrFrom, ax, phY + phH * 0.5f - 148f, 0.17f, zonaCol);
        DrawText(oraPickup, ax, phY + phH * 0.5f - 138f, 0.15f, oraCol);

        // destinazione
        DrawText(zonaTo, ax, phY + phH * 0.5f - 122f, 0.23f, addrCol);
        DrawText(zonaTo, ax + 0.5f, phY + phH * 0.5f - 122f, 0.23f, addrCol);
        DrawText(addrTo, ax, phY + phH * 0.5f - 112f, 0.17f, zonaCol);
        DrawText(oraArrivo, ax, phY + phH * 0.5f - 102f, 0.15f, oraCol);

        // distanza: la scritta a sinistra come il nome, i km a destra come il prezzo
        DrawText(L("distance", "distanza"), ax - 20f, phY + phH * 0.5f - 82f, 0.23f, addrCol);
        DrawTextRight(distTxt, phX + phW * 0.5f - 35f, phY + phH * 0.5f - 82f, 0.23f,
                      Color.FromArgb(255, 200, 150, 30));

        // valutazione a stelle: da quando il cliente e' a bordo e restano
        // finche' il telefono non torna giu'
        if (state >= 3 || Game.GameTime < phUpUntil)
        {
            float sY = phY + phH * 0.5f - 176f;

            int stelle = 1 + (int)(mood / 25f);
            if (mood >= 100f) stelle = 5;
            if (stelle > 5) stelle = 5;
            if (mood <= 0f) stelle = 0;

            float sSize = 9f;
            float sGap = 10f;
            float sX = ax - 16f;
            int si;
            for (si = 0; si < 5; si++)
            {
                Color sc = (si < stelle)
                           ? Color.FromArgb(255, 245, 190, 60)
                           : Color.FromArgb(70, 120, 120, 125);
                DrawIcon("star.png", sX + si * sGap, sY, sSize, sc);
            }
        }
    }

    void DrawRect(float px, float py, float pw, float ph, int r, int g, int b, int a)
    {
        float ccx = (px + pw * 0.5f) / 1280f;
        float ccy = (py + ph * 0.5f) / 720f;
        Function.Call(Hash.DRAW_RECT, ccx, ccy, pw / 1280f, ph / 720f, r, g, b, a);
    }

    // disegna un PNG della cartella icone del trainer, centrato sul punto
    bool iconsOk = true;
    void DrawIcon(string file, float cx, float cy, float size, Color col)
    {
        if (!iconsOk) return;
        try
        {
            string path = Path.Combine(TRAINER_DIR, "icone\\" + file);
            if (!File.Exists(path)) return;

            CustomSprite sp = new CustomSprite(path,
                new SizeF(size, size),
                new PointF(cx - size * 0.5f, cy - size * 0.5f),
                col);
            sp.Draw();
        }
        catch (Exception)
        {
            iconsOk = false;
        }
    }

    void DrawText(string txt, float x, float y, float scale, Color col)
    {
        TextElement el = new TextElement(txt, new PointF(x, y), scale);
        el.Color = col;
        el.Font = GTA.UI.Font.ChaletLondon;
        el.Outline = false;
        el.Draw();
    }

    void DrawTextRight(string txt, float x, float y, float scale, Color col)
    {
        TextElement el = new TextElement(txt, new PointF(x, y), scale);
        el.Color = col;
        el.Font = GTA.UI.Font.ChaletLondon;
        el.Alignment = Alignment.Right;
        el.Outline = false;
        el.Draw();
    }
}
