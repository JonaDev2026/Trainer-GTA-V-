﻿// PosProbe - segna un punto della mappa.
// Mettiti dove vuoi (davanti al bancone della pizzeria, sul marciapiede
// dove si parcheggia, ecc.) e premi CANC.
// Scrive posizione e direzione in scripts\JonaTrainer\punti.txt

using System;
using System.IO;
using System.Windows.Forms;
using GTA;
using GTA.Math;
using GTA.Native;
using GTA.UI;

public class PosProbe : Script
{
    const string DIR = "C:\\Program Files\\Rockstar Games\\Grand Theft Auto V Enhanced\\scripts\\Trainer";

    public PosProbe()
    {
        KeyDown += OnKeyDown;
    }

    void OnKeyDown(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.End) { DumpBlips(); return; }
        if (e.KeyCode == Keys.Next) { CleanHere(); return; }
        if (e.KeyCode == Keys.Delete) { SuonoProbe(); return; }
    }

    // CANC: prova un suono del telefono alla volta e ne scrive il nome
    int suonoIdx = 0;
    static readonly string[] SUONI = new string[] {
        "Menu_Accept|Phone_SoundSet_Default",
        "Menu_Back|Phone_SoundSet_Default",
        "Menu_Focus|Phone_SoundSet_Default",
        "Menu_Navigate|Phone_SoundSet_Default",
        "Menu_Select|Phone_SoundSet_Default",
        "Hang_Up|Phone_SoundSet_Default",
        "Text_Arrive_Tone|Phone_SoundSet_Default",
        "Menu_Accept|Phone_SoundSet_Michael",
        "Menu_Back|Phone_SoundSet_Michael",
        "Menu_Accept|Phone_SoundSet_Franklin",
        "Menu_Accept|Phone_SoundSet_Trevor",
        "SELECT|HUD_FRONTEND_DEFAULT_SOUNDSET",
        "BACK|HUD_FRONTEND_DEFAULT_SOUNDSET",
        "PHONE_UP|Phone_SoundSet_Default",
        "PHONE_DOWN|Phone_SoundSet_Default"
    };

    void SuonoProbe()
    {
        string row = SUONI[suonoIdx % SUONI.Length];
        suonoIdx++;

        string[] parts = row.Split('|');
        Function.Call(Hash.PLAY_SOUND_FRONTEND, -1, parts[0], parts[1], true);
        Notification.PostTicker("~g~" + suonoIdx + ") " + parts[0] + " / " + parts[1], false);
    }

    // scrive i tre valori di salute del veicolo su danni.txt
    void DanniProbe()
    {
        Vehicle v = Game.Player.Character.CurrentVehicle;
        if (v == null || !v.Exists())
        {
            Notification.PostTicker("~y~sali su un veicolo", false);
            return;
        }

        float body = Function.Call<float>(Hash.GET_VEHICLE_BODY_HEALTH, v);
        float eng = Function.Call<float>(Hash.GET_VEHICLE_ENGINE_HEALTH, v);
        float tank = Function.Call<float>(Hash.GET_VEHICLE_PETROL_TANK_HEALTH, v);

        string riga = "body=" + body + "  engine=" + eng + "  tank=" + tank;
        File.AppendAllText(Path.Combine(DIR, "danni.txt"), riga + "\r\n");
        Notification.PostTicker("~g~" + riga, false);
    }

    // CANC: prova a caricare i dizionari dei loghi radio e scrive quali
    // esistono davvero, su radio.txt
    void RadioProbe()
    {
        string f = Path.Combine(DIR, "radio.txt");
        string id = Function.Call<string>(Hash.GET_PLAYER_RADIO_STATION_NAME);
        if (id == null) id = "";

        string t = id.ToLower();
        string a = t;                                  // radio_01_class_rock
        string b = t.Replace("_", "");                 // radio01classrock
        string c = t;
        int p1 = c.IndexOf('_', 6);
        if (p1 > 0) c = c.Substring(0, p1) + c.Substring(p1 + 1);   // radio_01class_rock
        string d = c;
        int p2 = d.IndexOf('_', 6);
        if (p2 > 0) d = d.Substring(0, p2);            // radio_01class

        string[] cand = new string[] { a, b, c, d,
            "radio_01class", "radio_01classrock", "radio_01_class_rock",
            "radio_02pop", "radio_03hiphop", "radio_04punk",
            "radiologo", "radio_logos", "radio_stations", "radioicons" };

        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        sb.AppendLine("stazione = " + id);
        int i;
        for (i = 0; i < cand.Length; i++)
        {
            Function.Call(Hash.REQUEST_STREAMED_TEXTURE_DICT, cand[i], false);
            bool ok = Function.Call<bool>(Hash.HAS_STREAMED_TEXTURE_DICT_LOADED, cand[i]);
            sb.AppendLine(cand[i] + " -> " + (ok ? "OK" : "no"));
        }

        File.AppendAllText(f, sb.ToString() + "\r\n");
        Notification.PostTicker("~g~radio.txt scritto", false);
    }

    // FINE (End): scrive su blips.txt tutti i blip presenti, con sprite,
    // tipo, colore, alpha, display e distanza dal giocatore.
    void DumpBlips()
    {
        Vector3 me = Game.Player.Character.Position;
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        int found = 0;
        int sp;
        for (sp = 0; sp < 900; sp++)
        {
            int b = Function.Call<int>(Hash.GET_FIRST_BLIP_INFO_ID, sp);
            int guard = 0;
            while (Function.Call<bool>(Hash.DOES_BLIP_EXIST, b) && guard < 200)
            {
                guard++;
                Vector3 c = Function.Call<Vector3>(Hash.GET_BLIP_INFO_ID_COORD, b);
                float d = (c - me).Length();

                int type = Function.Call<int>(Hash.GET_BLIP_INFO_ID_TYPE, b);
                int col = Function.Call<int>(Hash.GET_BLIP_COLOUR, b);
                int alp = Function.Call<int>(Hash.GET_BLIP_ALPHA, b);
                bool mis = Function.Call<bool>(Hash.IS_MISSION_CREATOR_BLIP, b);
                bool onmm = Function.Call<bool>(Hash.IS_BLIP_ON_MINIMAP, b);
                bool shortr = Function.Call<bool>(Hash.IS_BLIP_SHORT_RANGE, b);

                sb.Append("handle=" + b.ToString());
                sb.Append(" sprite=" + sp.ToString());
                sb.Append(" type=" + type.ToString());
                sb.Append(" col=" + col.ToString());
                sb.Append(" alpha=" + alp.ToString());
                sb.Append(" mission=" + (mis ? "1" : "0"));
                sb.Append(" minimap=" + (onmm ? "1" : "0"));
                sb.Append(" short=" + (shortr ? "1" : "0"));
                sb.Append(" pos=" + c.X.ToString("0") + "," + c.Y.ToString("0") + "," + c.Z.ToString("0"));
                sb.Append(" dist=" + d.ToString("0"));
                sb.Append("\r\n");
                found++;

                b = Function.Call<int>(Hash.GET_NEXT_BLIP_INFO_ID, sp);
            }
        }

        try
        {
            Directory.CreateDirectory(DIR);
            File.WriteAllText(Path.Combine(DIR, "blips.txt"), sb.ToString());
            Notification.PostTicker("~g~Blip scritti:~s~ " + found.ToString(), false);
        }
        catch (Exception ex)
        {
            Notification.PostTicker("~r~Errore:~s~ " + ex.Message, false);
        }
    }

    // PAG GIU' (Page Down): cancella entita' bloccate nel raggio di 80 m
    // lasciate da script vecchi (auto e ped della gang, bodyguard).
    // Non tocca il giocatore ne' il veicolo su cui sei.
    void CleanHere()
    {
        Ped me = Game.Player.Character;
        Vehicle mine = me.CurrentVehicle;
        int gone = 0;

        Ped[] peds = World.GetNearbyPeds(me, 80f);
        int i;
        for (i = 0; i < peds.Length; i++)
        {
            Ped q = peds[i];
            if (q == null || !q.Exists()) continue;
            if (q.Handle == me.Handle) continue;
            // solo roba piazzata da uno script: i passanti normali non si toccano
            if (!Function.Call<bool>(Hash.IS_ENTITY_A_MISSION_ENTITY, q)) continue;

            int bl = Function.Call<int>(Hash.GET_BLIP_FROM_ENTITY, q);
            if (Function.Call<bool>(Hash.DOES_BLIP_EXIST, bl))
            {
                Blip b2 = new Blip(bl);
                if (b2.Exists()) b2.Delete();
            }

            Function.Call(Hash.SET_ENTITY_AS_MISSION_ENTITY, q, true, true);
            q.Delete();
            gone++;
        }

        Vehicle[] cars = World.GetNearbyVehicles(me, 80f);
        for (i = 0; i < cars.Length; i++)
        {
            Vehicle v = cars[i];
            if (v == null || !v.Exists()) continue;
            if (mine != null && mine.Exists() && v.Handle == mine.Handle) continue;
            if (!Function.Call<bool>(Hash.IS_ENTITY_A_MISSION_ENTITY, v)) continue;
            if (IsMyCar(v)) continue;          // i veicoli salvati non si toccano

            int bl = Function.Call<int>(Hash.GET_BLIP_FROM_ENTITY, v);
            if (Function.Call<bool>(Hash.DOES_BLIP_EXIST, bl))
            {
                Blip b2 = new Blip(bl);
                if (b2.Exists()) b2.Delete();
            }

            Function.Call(Hash.SET_ENTITY_AS_MISSION_ENTITY, v, true, true);
            v.Delete();
            gone++;
        }

        Notification.PostTicker("~g~Ripulito:~s~ " + gone.ToString(), false);
    }

    // targhe dei veicoli salvati nel trainer: quelli non vanno mai cancellati
    bool IsMyCar(Vehicle v)
    {
        try
        {
            string f = Path.Combine(DIR, "myvehicles.txt");
            if (!File.Exists(f)) return false;

            string plate = Function.Call<string>(Hash.GET_VEHICLE_NUMBER_PLATE_TEXT, v);
            if (plate == null) return false;
            plate = plate.Trim().ToUpper();
            if (plate.Length == 0) return false;

            string[] rows = File.ReadAllLines(f);
            int i;
            for (i = 0; i < rows.Length; i++)
            {
                string[] q = rows[i].Split('|');
                if (q.Length < 2) continue;
                if (q[1].Trim().ToUpper() == plate) return true;
            }
        }
        catch { }
        return false;
    }


    // HOME: prova a scrivere la massa della handling e rilegge il valore.
    // Scrive tutto in massa.txt PRIMA di ogni tentativo, cosi' se crasha
    // il file dice comunque a che punto era arrivato.
    void MassProbe()
    {
        string f = Path.Combine(DIR, "massa.txt");
        try
        {
            Directory.CreateDirectory(DIR);
            Ped me = Game.Player.Character;
            Vehicle v = me.CurrentVehicle;
            if (v == null || !v.Exists())
            {
                File.AppendAllText(f, "non sei su un veicolo\r\n");
                Notification.PostTicker("~y~Sali su un veicolo", false);
                return;
            }

            File.AppendAllText(f, "--- prova " + DateTime.Now.ToString("HH:mm:ss") + "\r\n");
            File.AppendAllText(f, "modello=" + v.DisplayName + " hash=" + v.Model.Hash.ToString() + "\r\n");

            File.AppendAllText(f, "1) leggo HandlingData\r\n");
            HandlingData h = v.HandlingData;
            File.AppendAllText(f, "   handling ok\r\n");

            float m0 = h.Mass;
            File.AppendAllText(f, "2) massa letta = " + m0.ToString("0.0") + "\r\n");

            File.AppendAllText(f, "3) scrivo massa x10\r\n");
            h.Mass = m0 * 10f;

            float m1 = h.Mass;
            File.AppendAllText(f, "4) rilettura dopo scrittura = " + m1.ToString("0.0") + "\r\n");

            File.AppendAllText(f, "5) rileggo dal modello\r\n");
            HandlingData h2 = HandlingData.GetByVehicleModel(v.Model);
            File.AppendAllText(f, "   dal modello = " + h2.Mass.ToString("0.0") + "\r\n");

            File.AppendAllText(f, "6) rimetto originale\r\n");
            h.Mass = m0;
            File.AppendAllText(f, "   rimessa = " + h.Mass.ToString("0.0") + "\r\n");

            Notification.PostTicker("~g~Massa:~s~ " + m0.ToString("0") + " -> " + m1.ToString("0"), false);
        }
        catch (Exception ex)
        {
            try { File.AppendAllText(f, "ERRORE: " + ex.Message + "\r\n"); }
            catch { }
            Notification.PostTicker("~r~Errore:~s~ " + ex.Message, false);
        }
    }

    // CANC: prova 40 punti sparsi attorno a te e per ognuno cerca il posto
    // dove il cliente dovrebbe aspettare. Scrive tutto in clienti.txt.
    // Serve a capire se le native del marciapiede funzionano anche lontano.
    void SpotProbe()
    {
        string f = Path.Combine(DIR, "clienti.txt");
        Random rng = new Random();
        Vector3 me = Game.Player.Character.Position;

        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        sb.Append("=== prova " + DateTime.Now.ToString("HH:mm:ss")
                  + "  giocatore " + me.X.ToString("0") + "," + me.Y.ToString("0") + "\r\n");
        sb.Append("dist = quanto e' lontano il punto da te\r\n");
        sb.Append("nodo = punto stradale trovato | safe = posto sicuro per il pedone\r\n");
        sb.Append("scarto = quanti metri c'e' tra nodo e safe (piu' e' alto, piu' e' fuori strada)\r\n\r\n");

        int n;
        for (n = 0; n < 40; n++)
        {
            // un punto a caso tra 100 e 1500 metri
            double ang = rng.NextDouble() * Math.PI * 2.0;
            double rad = 100.0 + rng.NextDouble() * 1400.0;
            float px = me.X + (float)(Math.Cos(ang) * rad);
            float py = me.Y + (float)(Math.Sin(ang) * rad);

            OutputArgument nodeOut = new OutputArgument();
            OutputArgument headOut = new OutputArgument();
            bool okNode = Function.Call<bool>(Hash.GET_CLOSEST_VEHICLE_NODE_WITH_HEADING,
                                              px, py, me.Z, nodeOut, headOut, 1, 3.0f, 0);
            if (!okNode)
            {
                sb.Append(n.ToString("00") + " nessun nodo stradale\r\n");
                continue;
            }

            Vector3 node = nodeOut.GetResult<Vector3>();
            float dist = (node - me).Length();

            OutputArgument sideOut = new OutputArgument();
            bool okSafe = Function.Call<bool>(Hash.GET_SAFE_COORD_FOR_PED,
                                              node.X, node.Y, node.Z, true, sideOut, 16);

            string via = "";
            OutputArgument sh = new OutputArgument();
            OutputArgument ch = new OutputArgument();
            Function.Call(Hash.GET_STREET_NAME_AT_COORD, node.X, node.Y, node.Z, sh, ch);
            via = Function.Call<string>(Hash.GET_STREET_NAME_FROM_HASH_KEY, sh.GetResult<int>());
            if (via == null) via = "";

            sb.Append(n.ToString("00"));
            sb.Append(" dist=" + dist.ToString("0"));
            sb.Append(" nodo=" + node.X.ToString("0") + "," + node.Y.ToString("0"));
            sb.Append(" via=" + via);

            if (!okSafe)
            {
                sb.Append(" safe=NO\r\n");
                continue;
            }

            Vector3 safe = sideOut.GetResult<Vector3>();
            float scarto = (safe - node).Length();
            bool suStrada = Function.Call<bool>(Hash.IS_POINT_ON_ROAD, safe.X, safe.Y, safe.Z, 0);

            sb.Append(" safe=" + safe.X.ToString("0") + "," + safe.Y.ToString("0"));
            sb.Append(" scarto=" + scarto.ToString("0.0"));
            sb.Append(" ancoraInStrada=" + (suStrada ? "SI" : "no"));
            sb.Append("\r\n");
        }

        try
        {
            Directory.CreateDirectory(DIR);
            File.AppendAllText(f, sb.ToString());
            Notification.PostTicker("~g~Punti provati:~s~ 40 - scritto clienti.txt", false);
        }
        catch (Exception ex)
        {
            Notification.PostTicker("~r~Errore:~s~ " + ex.Message, false);
        }
    }

    // CANC: dice se il gioco sa distinguere un veicolo elettrico.
    // Scrive PRIMA di ogni tentativo, cosi' se qualcosa fa crashare
    // il file dice comunque fin dove era arrivato.
    void ElettricaProbe()
    {
        string f = Path.Combine(DIR, "elettriche.txt");
        try
        {
            Directory.CreateDirectory(DIR);

            Ped me = Game.Player.Character;
            Vehicle v = me.CurrentVehicle;
            if (v == null || !v.Exists())
            {
                Notification.PostTicker("~y~Sali su un veicolo", false);
                return;
            }

            File.AppendAllText(f, "--- " + DateTime.Now.ToString("HH:mm:ss") + "\r\n");
            File.AppendAllText(f, "modello=" + v.DisplayName
                + " hash=" + v.Model.Hash.ToString() + "\r\n");

            File.AppendAllText(f, "1) chiedo IsElectricVehicle\r\n");
            bool el = v.Model.IsElectricVehicle;
            File.AppendAllText(f, "   elettrica=" + (el ? "SI" : "no") + "\r\n");

            File.AppendAllText(f, "2) chiedo il volume del serbatoio\r\n");
            float vol = v.HandlingData.PetrolTankVolume;
            File.AppendAllText(f, "   serbatoio=" + vol.ToString("0.00") + "\r\n");

            Notification.PostTicker("~g~" + v.DisplayName + "~s~  elettrica: "
                + (el ? "SI" : "no") + "  serbatoio: " + vol.ToString("0.0"), false);
        }
        catch (Exception ex)
        {
            try { File.AppendAllText(f, "ERRORE: " + ex.Message + "\r\n"); }
            catch { }
            Notification.PostTicker("~r~Errore:~s~ " + ex.Message, false);
        }
    }

    // CANC: segna qui una colonnina di ricarica.
    // Mettiti col muso della macchina dove vuoi che stia la colonnina
    // e premi. Scrive in Trainer\colonnine.txt, che il trainer legge
    // all'avvio per creare i blip.
    void SegnaColonnina()
    {
        try
        {
            Ped me = Game.Player.Character;
            Vector3 pos = me.Position;

            string zona = Function.Call<string>(Hash.GET_NAME_OF_ZONE, pos.X, pos.Y, pos.Z);
            if (zona == null) zona = "";

            OutputArgument sh = new OutputArgument();
            OutputArgument ch = new OutputArgument();
            Function.Call(Hash.GET_STREET_NAME_AT_COORD, pos.X, pos.Y, pos.Z, sh, ch);
            string via = Function.Call<string>(Hash.GET_STREET_NAME_FROM_HASH_KEY, sh.GetResult<int>());
            if (via == null) via = "";

            string riga = pos.X.ToString("0.00") + "|"
                        + pos.Y.ToString("0.00") + "|"
                        + pos.Z.ToString("0.00") + "|"
                        + zona + " - " + via;

            Directory.CreateDirectory(DIR);
            string f = Path.Combine(DIR, "colonnine.txt");
            File.AppendAllText(f, riga + "\r\n");

            int quante = File.ReadAllLines(f).Length;
            Notification.PostTicker("~g~Colonnina segnata~s~  (" + quante + ")  " + zona, false);
        }
        catch (Exception ex)
        {
            Notification.PostTicker("~r~Errore:~s~ " + ex.Message, false);
        }
    }

    // CANC: marcia, marce totali e giri. Sono valori letti dalla memoria del
    // gioco, la stessa che sulla massa ci ha mentito: prima di fidarsi si
    // misura. Premi mentre guidi, in marce diverse.
    void MarceProbe()
    {
        string f = Path.Combine(DIR, "marce.txt");
        try
        {
            Directory.CreateDirectory(DIR);
            Vehicle v = Game.Player.Character.CurrentVehicle;
            if (v == null || !v.Exists())
            {
                Notification.PostTicker("~y~Sali su un veicolo", false);
                return;
            }

            int kmh = (int)(Function.Call<float>(Hash.GET_ENTITY_SPEED, v) * 3.6f);

            File.AppendAllText(f, "--- " + DateTime.Now.ToString("HH:mm:ss")
                + "  " + v.DisplayName + "  " + kmh + " km/h\r\n");

            File.AppendAllText(f, "1) marcia attuale\r\n");
            int g = v.CurrentGear;
            File.AppendAllText(f, "   marcia=" + g + "\r\n");

            File.AppendAllText(f, "2) marce totali\r\n");
            int hg = v.HighGear;
            File.AppendAllText(f, "   totali=" + hg + "\r\n");

            File.AppendAllText(f, "3) giri motore\r\n");
            float rpm = v.CurrentRPM;
            File.AppendAllText(f, "   rpm=" + rpm.ToString("0.000") + "\r\n");

            Notification.PostTicker("~g~marcia " + g + "/" + hg
                + "~s~  rpm " + rpm.ToString("0.00") + "  " + kmh + " km/h", false);
        }
        catch (Exception ex)
        {
            try { File.AppendAllText(f, "ERRORE: " + ex.Message + "\r\n"); } catch { }
            Notification.PostTicker("~r~Errore:~s~ " + ex.Message, false);
        }
    }
}
