﻿// ============================================================
//  TRAINER - shell vuoto, pronto per aggiungere funzioni
//  SHVDN3 - stile vecchio C# (niente $"" ne ?. ne lambda)
//
//  APERTURA:  tastiera = F4     |    pad = RB + DPAD-GIU
//  NAVIGA:    frecce / DPAD  (anche NumPad 8/2/4/6)
//  CONFERMA:  INVIO / A      (anche NumPad 5)
//  INDIETRO:  BACKSPACE / B  (anche NumPad 0)
// ============================================================

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;
using GTA;
using GTA.Math;
using GTA.Native;
using GTA.UI;

// ---------- una voce di menu ----------
class TItem
{
    public const int ACTION = 0;   // esegue e basta
    public const int TOGGLE = 1;   // ON / OFF
    public const int LIST   = 2;   // scelta fra opzioni (sx/dx)
    public const int NUMBER = 3;   // valore numerico (sx/dx)
    public const int SUB    = 4;   // apre un sottomenu
    public const int HEADER = 5;   // etichetta di sezione, non selezionabile

    public int Kind;
    public string Text;
    public int Id;            // id azione -> switch in DoAction / OnChanged
    public int Sub;           // indice sottomenu (solo SUB)
    public bool On;           // TOGGLE
    public string[] Opts;     // LIST
    public int Sel;           // LIST: indice scelto
    public int Val;           // NUMBER
    public int Min;
    public int Max;
    public int Step;
    public string Hint;       // riga di aiuto in fondo
    public string Data;       // payload libero (es. nome modello veicolo)
    public string TextIt;     // etichetta italiana
    public int Cr, Cg, Cb;    // tinta (0,0,0 = default)
    public bool Tinted;
    public bool SignedValue;  // colora il valore: + verde, - rosso, 0 bianco

    public TItem(int kind, string text, int id)
    {
        Kind = kind;
        Text = text;
        Id = id;
        Sub = -1;
        On = false;
        Opts = null;
        Sel = 0;
        Val = 0;
        Min = 0;
        Max = 100;
        Step = 1;
        Hint = "";
        Data = "";
        TextIt = text;
        Cr = 0; Cg = 0; Cb = 0; Tinted = false;
        SignedValue = false;
    }
}

// ---------- una pagina di menu ----------
class TMenu
{
    public string Title;
    public string TitleIt;
    public int Parent;
    public List<TItem> Items;
    public int Sel;
    public int Top;

    public TMenu(string title, int parent)
    {
        Title = title;
        TitleIt = title;
        Parent = parent;
        Items = new List<TItem>();
        Sel = 0;
        Top = 0;
    }
}

public class Trainer : Script
{
    // ---------- controlli (gruppo 2 = frontend: vale sia tastiera che pad) ----------
    const int C_UP     = 172;
    const int C_DOWN   = 173;
    const int C_LEFT   = 174;
    const int C_RIGHT  = 175;
    const int C_ACCEPT = 176;
    const int C_CANCEL = 177;

    // pad: RB tenuto + DPAD-GIU apre/chiude
    const int C_PAD_RB = 183;

    // ---------- layout ----------
    const float MW = 230f;                  // larghezza (-1/3)
    const float MX = (1280f - MW) * 0.5f;   // x menu: centrato
    const float MY = 4f;                    // y menu: quasi a filo del bordo alto
    const float HEAD_H = 18f;               // header attaccato al menu
    const float FOOT_H = 14f;
    const float ITEM_H = 18f;  // altezza voce
    const int   MAX_VIS = 12;  // voci visibili

    static readonly string[] DAYS_EN = new string[] {
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    };
    static readonly string[] DAYS_IT = new string[] {
        "Domenica", "Lunedi", "Martedi", "Mercoledi", "Giovedi", "Venerdi", "Sabato"
    };

    // ---------- voci con effetto continuo ----------
    TItem tGod, tNeverWanted, tStamina, tJump, tBreath, tFastRun;
    TItem tSpawnInside, tDelPrev, tMaxMods, tLang, tVehGod, tOnWater, tTopBar;
    TItem tMass, tLimiter, tUnits;
    bool vehGodWas = false;
    int limiterVeh = 0;
    bool evCurrent = false;      // il mezzo su cui sei e' elettrico
    bool pumping = false;        // pompa o colonnina in funzione
    float pumpDebt = 0f;         // spiccioli non ancora scalati

    // ---------- radio ----------
    TItem tRadio, tRadioMobile;
    List<string> radioName = new List<string>();   // nomi interni delle stazioni
    int radioNext = 0;
    int radioLastVeh = 0;

    // ---------- mod esterne ----------
    // Ogni mod e' un file .cs dentro scripts\<categoria>\<nome>\.
    // Il trainer non sa cosa facciano: legge le cartelle, mette un
    // interruttore per ognuna e scrive mods.ini. Il mod legge quel file
    // e si accende o si spegne da solo.
    static readonly string SCRIPTS_DIR = "C:\\Program Files\\Rockstar Games\\Grand Theft Auto V Enhanced\\scripts";
    static readonly string[] MOD_CAT_DIR = new string[] { "Lavori", "Minigiochi", "Missioni" };
    static readonly string[] MOD_CAT_EN  = new string[] { "Jobs", "Minigames", "Missions" };
    static readonly string[] MOD_CAT_IT  = new string[] { "Lavori", "Minigiochi", "Missioni" };
    List<string> modId = new List<string>();      // "lavori/uber"
    List<TItem> modItem = new List<TItem>();
    int modFirstId = 700;
    static readonly float[] MASS_MULT = new float[] {
        1f, 1.5f, 2f, 2.5f, 3f, 3.5f, 4f, 4.5f, 5f, 5.5f, 6f, 6.5f, 7f, 7.5f, 8f, 8.5f,
        9f, 9.5f, 10f, 20f, 30f, 40f, 50f, 60f, 70f, 80f, 90f, 100f, 200f, 300f, 400f,
        500f, 600f, 700f, 800f, 900f, 1000f, 2000f, 3000f, 4000f, 5000f, 6000f, 7000f,
        8000f, 9000f, 10000f, 100000f };
    TItem tFreezeTime, tFreezeWeather, tBlackout, tHour, tMinute, tWeather;
    TItem tTimeSpeed;
    bool clockTaken = false;
    int nextGameMin = 0;
    TItem tAutoTp;
    int mPlaces = -1;
    List<string> placeRaw = new List<string>();
    TItem tInfAmmo, tNoReload;
    TItem tInvisible, tNoRagdoll, tExplosiveAmmo, tFireAmmo, tExplosiveMelee, tSeatbelt;
    TItem tTraffic, tPeds;

    Vector3 lastAutoTp = Vector3.Zero;
    int autoTpNext = 0;

    // 0 = English, 1 = Italiano
    int lang = 0;

    // ---------- veicoli ----------
    const string DATA_DIR = "C:\\Program Files\\Rockstar Games\\Grand Theft Auto V Enhanced\\scripts\\Trainer";
    int mVehicles = -1;
    int mSpawnOpts = -1;
    bool vehBuilt = false;
    Vehicle lastSpawned = null;

    // ---------- veicoli salvati ----------
    TItem tPersist;
    int mMyVeh = -1;
    int mModShop = -1;
    int mBody = -1, mMech = -1, mWheels = -1, mLights = -1, mExtras = -1;
    List<string> pvRaw = new List<string>();
    List<int> pvBlip = new List<int>();

    // ---------- benzina ----------
    TItem tFuel;

    // ---------- limiti di velocita' ----------
    TItem tSpeedLimit, tLimCity, tLimHwy, tLimDirt;
    int speedCheckNext = 0;
    int roadKind = 0;          // 0 = citta', 1 = autostrada, 2 = sterrato/montagna
    float overSince = -1f;
    int fineCooldown = 0;
    int beepNext = 0;
    const int SPEED_MARGIN = 10;      // tolleranza in km/h
    const int OVER_SECONDS = 10;      // quanto puoi restare nel margine prima della multa
    const float PCT_PER_METER = 0.0014286f;  // un pieno ~ 70 km
    const float COST_PER_PCT = 0.9f;

    // ---------- veicoli elettrici ----------
    // La proprieta' IsElectricVehicle di SHVDN in questa build risponde
    // sempre "no" (verificato sonda alla mano: la Voltic dava no), e il
    // volume del serbatoio non e' affidabile (la Neon dichiara 65 come una
    // benzina). Quindi la lista e' nostra: noiosa una volta, precisa sempre.
    // Solo full electric. Dilettante, Khamelion e Imorgon NON stanno qui:
    // sono ibride e vivono nella lista HYBRID.
    static readonly string[] ELECTRIC = new string[] {
        "voltic", "voltic2", "surge", "cyclone", "cyclone2", "tezeract",
        "neon", "raiden", "virtue", "powersurge", "omnisegt",
        "caddy", "caddy2", "caddy3", "airtug", "docktug", "forklift",
        "rcbandito", "minitank"
    };

    // ---------- veicoli ibridi ----------
    // Motore termico piu' spinta elettrica: benzina nel serbatoio, ma la
    // spia della terza posizione e' ECO invece della spia motore.
    static readonly string[] HYBRID = new string[] {
        "dilettante", "dilettante2", "khamelion", "imorgon", "t20",
        "turismor", "pfister811", "etr1", "viseris", "osiris"
    };

    // la batteria rende di piu' della benzina: ~100 km invece di 75
    const float PCT_PER_METER_EV = 0.0008333f;   // una carica ~ 120 km
    const float PCT_PER_METER_HY = 0.0010526f;   // un pieno ibrido ~ 95 km
    // e ricaricare costa meno che fare il pieno
    const float COST_PER_PCT_EV = 0.35f;
    // il rifornimento richiede tempo, come nella vita:
    // pieno di benzina in 30 secondi, ricarica completa in 60
    const float PUMP_PER_SEC = 100f / 30f;
    const float CHARGE_PER_SEC = 100f / 60f;
    const float GAS_RADIUS = 20f;

    static readonly float[] GX = new float[] {
        49.4187f, 263.894f, 1039.958f, 1207.260f, 2539.685f, 2679.858f, 2005.055f,
        1687.156f, 1701.314f, 179.857f, -94.4619f, -2554.996f, -1800.375f, -1437.622f,
        -2096.243f, -724.619f, -526.019f, -70.2148f, 265.648f, 819.653f, 1208.951f,
        1181.381f, 620.843f, 2581.321f, 176.631f
    };
    static readonly float[] GY = new float[] {
        2778.793f, 2606.463f, 2671.134f, 2660.175f, 2594.192f, 3263.946f, 3773.887f,
        4929.392f, 6416.028f, 6602.839f, 6419.594f, 2334.40f, 803.661f, -276.747f,
        -320.286f, -935.1631f, -1211.003f, -1761.792f, -1261.309f, -1028.846f, -1402.567f,
        -330.847f, 269.100f, 362.039f, -1562.025f
    };
    static readonly float[] GZ = new float[] {
        58.043f, 44.983f, 39.550f, 37.899f, 37.944f, 55.240f, 32.403f,
        42.078f, 32.763f, 31.868f, 31.489f, 33.078f, 138.651f, 46.207f,
        13.168f, 19.213f, 18.184f, 29.534f, 29.292f, 26.403f, 35.224f,
        69.316f, 103.089f, 108.468f, 29.263f
    };
    int[] gasBlips = null;

    // ---------- fame e sete ----------
    TItem tBody;
    float hunger = 100f;
    float thirst = 100f;
    int lastBodyHour = -1;
    int starveNext = 0;

    // market 24/7 accessibili
    static readonly float[] MKX = new float[] {
        373.55f, 25.75f, -3038.71f, -3241.47f, 547.79f,
        1961.48f, 2678.91f, 1729.21f, -2519.23f
    };
    static readonly float[] MKY = new float[] {
        325.56f, -1346.94f, 585.95f, 1001.14f, 2671.79f,
        3740.69f, 3280.67f, 6414.13f, 2316.93f
    };
    static readonly float[] MKZ = new float[] {
        103.56f, 29.49f, 7.90f, 12.83f, 42.16f,
        32.34f, 55.24f, 35.04f, 33.41f
    };
    int[] mkBlips = null;


    List<string> tankKey = new List<string>();
    List<float> tankVal = new List<float>();

    // ---------- olio motore ----------
    // Cala coi chilometri, non col tempo: un tagliando ogni ~300 km.
    // Sotto il 15% il motore comincia a soffrire davvero.
    List<string> oilKey = new List<string>();
    List<float> oilVal = new List<float>();
    string curOilKey = "";
    float oil = 100f;          // quanto manca al tagliando, in percentuale
    float servM = 0f;         // metri dell'odometro all'ultimo tagliando
    int oilWarnAt = 0;
    int oilSlowVeh = 0;      // veicolo a cui e' stata tolta potenza

    // ---------- icone del cruscotto ----------
    // Sono PNG normali in scripts\Trainer\icone\: CustomSprite li disegna
    // direttamente dal disco, senza doverli impacchettare nel gioco.
    // Se qualcosa non va si spengono da sole e il cruscotto resta come prima.
    bool iconsOk = true;
    bool iconsTried = false;
    bool dictSaid = false;
    // tagliando: benzina ogni 1000 km, elettriche ogni 2000
    const float SERVICE_M_PETROL = 1000000f;
    const float SERVICE_M_EV = 2000000f;
    const int OIL_SERVICE_COST = 120;

    // ---------- odometro ----------
    // I chilometri li conta il trainer, uno per veicolo: il contachilometri
    // del gioco non esiste. Serve anche a sapere quanto manca al tagliando.
    List<string> odoKey = new List<string>();
    List<float> odoVal = new List<float>();      // metri
    string curOdoKey = "";
    int fermoDa = 0;          // da quando la macchina e' ferma (GameTime)
    int frecciaSxFino = 0;    // freccia automatica: resta accesa fino a...
    int frecciaDxFino = 0;
    bool hyHot = false;       // ibrida: termico entrato, resta finche' non ti fermi
    float odoM = 0f;
    int odoSaveAt = 0;
    float fuel = 100f;
    string curTankKey = "";
    int fuelHelpAt = 0;
    TItem tBlips;
    int trackedIdx = -1;
    int pendingRemove = -1;   // rimozione differita: mai dentro il frame del menu
    bool pendingClear = false;
    bool wasInVeh = false;
    Vehicle lastDriven = null;

    // ---------- stato ----------
    bool open = false;
    int cur = 0;                       // menu corrente
    List<TMenu> menus = new List<TMenu>();
    bool f5Last = false;
    bool comboLast = false;
    bool rbHeld = false;
    int navNext = 0;                   // anti-ripetizione navigazione

    public Trainer()
    {
        BuildMenus();
        Tick += OnTick;
        KeyDown += OnKeyDown;
        Aborted += OnAborted;
        Interval = 0;
    }

    // ============================================================
    //  QUI SI COSTRUISCE IL MENU - aggiungere voci qui
    // ============================================================
    int NewMenu(string title, int parent)
    {
        menus.Add(new TMenu(title, parent));
        return menus.Count - 1;
    }

    // spezza il nome interno in parole: CarbineRifleMk2 -> "Carbine Rifle Mk2"
    string PrettyName(string raw)
    {
        StringBuilder sb = new StringBuilder();
        int i;
        for (i = 0; i < raw.Length; i++)
        {
            char c = raw[i];
            if (i > 0 && char.IsUpper(c) && !char.IsUpper(raw[i - 1]))
            {
                sb.Append(' ');
            }
            sb.Append(c);
        }
        return sb.ToString();
    }

    int WeaponGroup(string n)
    {
        string q = n.ToLower();

        if (q.Contains("pistol") || q.Contains("revolver") || q.Contains("snspistol")
            || q.Contains("vintagepistol") || q.Contains("marksmanpistol")
            || q.Contains("stungun") || q.Contains("flaregun") || q.Contains("raypistol")) return 1;

        if (q.Contains("smg") || q.Contains("microsmg") || q.Contains("machinepistol")
            || q.Contains("minismg") || q.Contains("assaultsmg") || q.Contains("combatpdw")) return 2;

        if (q.Contains("shotgun") || q.Contains("bullpupshotgun") || q.Contains("musket")) return 3;

        if (q.Contains("rifle") || q.Contains("carbine") || q.Contains("bullpuprifle")
            || q.Contains("compactrifle") || q.Contains("militaryrifle")) return 4;

        if (q.Contains("sniper") || q.Contains("marksmanrifle") || q.Contains("heavysniper")) return 5;

        if (q.Contains("mg") || q.Contains("minigun") || q.Contains("rpg") || q.Contains("grenadelauncher")
            || q.Contains("railgun") || q.Contains("firework") || q.Contains("homing")
            || q.Contains("compactlauncher") || q.Contains("raycarbine")) return 6;

        if (q.Contains("grenade") || q.Contains("molotov") || q.Contains("stickybomb")
            || q.Contains("bzgas") || q.Contains("smokegrenade") || q.Contains("pipebomb")
            || q.Contains("snowball") || q.Contains("ball") || q.Contains("flare")
            || q.Contains("proximitymine") || q.Contains("petrolcan") || q.Contains("fireextinguisher")
            || q.Contains("parachute") || q.Contains("jerrycan")) return 7;

        if (q.Contains("knife") || q.Contains("bat") || q.Contains("crowbar") || q.Contains("golfclub")
            || q.Contains("hammer") || q.Contains("hatchet") || q.Contains("knuckle")
            || q.Contains("machete") || q.Contains("flashlight") || q.Contains("dagger")
            || q.Contains("bottle") || q.Contains("wrench") || q.Contains("poolcue")
            || q.Contains("nightstick") || q.Contains("battleaxe") || q.Contains("stone")) return 0;

        return 8;
    }



    void BuildWeaponList(int parent)
    {
        string[] gEn = new string[] { "Melee", "Pistols", "SMG", "Shotguns", "Rifles",
                                      "Sniper", "Heavy", "Throwables", "Other" };
        string[] gIt = new string[] { "Corpo a corpo", "Pistole", "Mitragliette", "Fucili a pompa",
                                      "Fucili d'assalto", "Cecchino", "Pesanti", "Lanciabili", "Altro" };

        int[] menu = new int[gEn.Length];
        int i;
        for (i = 0; i < menu.Length; i++) menu[i] = -1;

        Array vals = Enum.GetValues(typeof(WeaponHash));
        for (i = 0; i < vals.Length; i++)
        {
            WeaponHash w = (WeaponHash)vals.GetValue(i);
            if (w == WeaponHash.Unarmed) continue;

            string raw = w.ToString();
            int g = WeaponGroup(raw);

            if (menu[g] < 0)
            {
                menu[g] = NewMenu(gEn[g].ToUpper(), gIt[g].ToUpper(), parent);
                TItem sub = AddSub(parent, gEn[g], gIt[g], menu[g]);
                int ci = g % (PASTEL.Length / 3);
                sub.Cr = PASTEL[ci, 0]; sub.Cg = PASTEL[ci, 1]; sub.Cb = PASTEL[ci, 2];
                sub.Tinted = true;
            }

            string nice = PrettyName(raw);
            TItem it = AddAction(menu[g], nice, nice, 505);
            it.Data = ((int)w).ToString();
        }
    }

    void BuildMenus()
    {
        int root = NewMenu("TRAINER", -1);

        // ---------------- GIOCATORE ----------------
        int mPlayer = NewMenu("PLAYER", "GIOCATORE", root);
        AddSub(root, "Player", "Giocatore", mPlayer);

        AddAction(mPlayer, "Heal", "Cura completa", 100);
        AddAction(mPlayer, "Full armour", "Armatura piena", 101);
        tGod         = AddToggle(mPlayer, "Godmode", "Invincibilita", 102, false);
        tNeverWanted = AddToggle(mPlayer, "Never wanted", "Mai ricercato", 103, false);
        AddNumber(mPlayer, "Wanted level", "Livello ricercato", 104, 0, 0, 5, 1);
        tStamina     = AddToggle(mPlayer, "Infinite stamina", "Fiato infinito", 105, false);
        tBreath      = AddToggle(mPlayer, "Infinite breath", "Respiro infinito", 106, false);
        tJump        = AddToggle(mPlayer, "Super jump", "Super salto", 107, false);
        tFastRun     = AddToggle(mPlayer, "Fast run", "Corsa veloce", 108, false);
        tInvisible      = AddToggle(mPlayer, "Invisible", "Invisibile", 111, false);
        tNoRagdoll      = AddToggle(mPlayer, "No ragdoll", "Niente ragdoll", 112, false);
        tSeatbelt       = AddToggle(mPlayer, "Seatbelt", "Cintura di sicurezza", 113, false);
        tExplosiveAmmo  = AddToggle(mPlayer, "Explosive ammo", "Proiettili esplosivi", 114, false);
        tFireAmmo       = AddToggle(mPlayer, "Fire ammo", "Proiettili incendiari", 115, false);
        tExplosiveMelee = AddToggle(mPlayer, "Explosive melee", "Pugno esplosivo", 116, false);

        TItem money = AddList(mPlayer, "Money", "Soldi", 110,
                new string[] { "-100.000", "-10.000", "-1.000", "-100", "-10",
                               "0",
                               "+10", "+100", "+1.000", "+10.000", "+100.000" }, 5);
        money.SignedValue = true;

        // ---------------- VITA REALE (sotto Giocatore) ----------------
        int mReal = NewMenu("REAL LIFE", "VITA REALE", mPlayer);
        TItem rl = AddSub(mPlayer, "Real life", "Vita reale", mReal);
        rl.Cr = PASTEL[2, 0]; rl.Cg = PASTEL[2, 1]; rl.Cb = PASTEL[2, 2]; rl.Tinted = true;

        tFuel = AddToggle(mReal, "Fuel consumption", "Consumo benzina", 260, false);
        tBody = AddToggle(mReal, "Hunger & thirst", "Fame e sete", 261, false);
        AddAction(mReal, "Eat something ($12)", "Mangia qualcosa ($12)", 266);
        AddAction(mReal, "Drink something ($3)", "Bevi qualcosa ($3)", 267);

        tSpeedLimit = AddToggle(mReal, "Speed limits", "Limiti di velocita", 262, false);
        tLimCity = AddNumber(mReal, "City limit", "Limite citta", 263, 80, 30, 130, 10);
        tLimHwy  = AddNumber(mReal, "Highway limit", "Limite autostrada", 264, 140, 60, 200, 10);
        tLimDirt = AddNumber(mReal, "Dirt road limit", "Limite sterrato", 265, 65, 20, 120, 5);

        // ---------------- VEHICLES ----------------
        mVehicles = NewMenu("VEHICLES", "VEICOLI", root);
        AddSub(root, "Vehicles", "Veicoli", mVehicles);

        int mOpts = NewMenu("SPAWN OPTIONS", "OPZIONI SPAWN", mVehicles);
        tSpawnInside = AddToggle(mOpts, "Spawn inside", "Spawn dentro il veicolo", 201, true);
        tDelPrev     = AddToggle(mOpts, "Delete previous", "Elimina il precedente", 202, false);
        tMaxMods     = AddToggle(mOpts, "Max upgrades", "Elaborazione massima", 203, false);
        mSpawnOpts   = mOpts;
        // il contenuto di VEHICLES viene composto in BuildVehicleClasses(): prima le classi, poi le azioni

        // ---------------- WEAPONS ----------------
        int mWeap = NewMenu("WEAPONS", "ARMI", root);
        AddSub(root, "Weapons", "Armi", mWeap);

        AddAction(mWeap, "Give all weapons", "Dammi tutte le armi", 500);
        AddAction(mWeap, "Refill ammo", "Ricarica le munizioni", 501);
        tInfAmmo  = AddToggle(mWeap, "Infinite ammo", "Munizioni infinite", 502, false);
        tNoReload = AddToggle(mWeap, "No reload", "Non ricaricare mai", 503, false);
        AddAction(mWeap, "Remove all weapons", "Togli tutte le armi", 504);

        AddHeader(mWeap, "- CATEGORIES -", "- CATEGORIE -", 1);
        BuildWeaponList(mWeap);

        // ---------------- WORLD ----------------
        int mWorld = NewMenu("WORLD", "MONDO", root);
        AddSub(root, "World", "Mondo", mWorld);

        AddHeader(mWorld, "- WEATHER -", "- METEO -", 1);
        tWeather = AddList(mWorld, "Weather", "Meteo", 400, new string[] {
            "Extra sunny", "Clear", "Clouds", "Smog", "Foggy", "Overcast",
            "Rain", "Thunder", "Clearing", "Neutral", "Snow", "Blizzard",
            "Snow light", "Christmas", "Halloween" }, 1);
        tFreezeWeather = AddToggle(mWorld, "Freeze weather", "Blocca il meteo", 401, false);
        tBlackout = AddToggle(mWorld, "Blackout", "Blackout", 409, false);

        AddHeader(mWorld, "- TIME -", "- ORA -", 5);
        tHour   = AddNumber(mWorld, "Hour", "Ora", 402, 12, 0, 23, 1);
        tMinute = AddNumber(mWorld, "Minutes", "Minuti", 403, 0, 0, 59, 5);
        tFreezeTime = AddToggle(mWorld, "Freeze time", "Blocca l'ora", 404, false);
        tTimeSpeed = AddList(mWorld, "Time speed", "Velocita del tempo", 412,
                             new string[] {
                               "x1", "x1.5", "x2", "x2.5", "x3", "x3.5", "x4", "x4.5",
                               "x5", "x5.5", "x6", "x6.5", "x7", "x7.5", "x8", "x8.5",
                               "x9", "x9.5", "x10", "x20", "x30", "x40", "x50", "x60",
                               "x70", "x80", "x90", "x100", "x200", "x300", "x400",
                               "x500", "x600", "x700", "x800", "x900", "x1000",
                               "x2000", "x3000", "x4000", "x5000", "x6000", "x7000",
                               "x8000", "x9000", "x10000", "x100000" }, 0);
        AddAction(mWorld, "Dawn", "Alba", 405);
        AddAction(mWorld, "Midday", "Mezzogiorno", 406);
        AddAction(mWorld, "Sunset", "Tramonto", 407);
        AddAction(mWorld, "Night", "Notte", 408);

        AddHeader(mWorld, "- DENSITY -", "- DENSITA' -", 4);
        tTraffic = AddNumber(mWorld, "Traffic", "Traffico", 410, 100, 0, 100, 10);
        tPeds    = AddNumber(mWorld, "Pedestrians", "Pedoni", 411, 100, 0, 100, 10);

        // ---------------- TELEPORT ----------------
        int mTp = NewMenu("TELEPORT", "TELEPORT", root);
        AddSub(root, "Teleport", "Teleport", mTp);
        AddAction(mTp, "To waypoint", "Al waypoint", 300);
        AddAction(mTp, "To objective", "All'obiettivo", 301);
        AddAction(mTp, "Save current spot...", "Salva questo punto...", 303);

        mPlaces = NewMenu("MY PLACES", "I MIEI PUNTI", mTp);
        AddSub(mTp, "My places", "I miei punti", mPlaces);
        LoadPlaces();
        BuildPlaces();

        int mKnown = NewMenu("KNOWN PLACES", "LUOGHI NOTI", mTp);
        AddSub(mTp, "Known places", "Luoghi noti", mKnown);
        BuildKnownPlaces(mKnown);

        tAutoTp = AddList(mTp, "Auto teleport", "Teleport automatico", 302,
                          new string[] { "Off", "Waypoint", "Objective" }, 0);

        // ---------------- MODS ----------------
        BuildModsMenu(root);

        // ---------------- SETTINGS (sempre ultima voce) ----------------
        int mSet = NewMenu("SETTINGS", "IMPOSTAZIONI", root);
        AddSub(root, "Settings", "Impostazioni", mSet);
        tLang   = AddList(mSet, "Language", "Lingua", 900, new string[] { "English", "Italiano" }, 0);
        tTopBar = AddToggle(mSet, "Header", "Header", 901, true);
        BuildRadioItems(mSet);

        LoadConfig();
        if (tLang != null) lang = tLang.Sel;
    }

    string L(string en, string it)
    {
        return lang == 1 ? it : en;
    }

    string Txt(TItem it)
    {
        return lang == 1 ? it.TextIt : it.Text;
    }

    string TitleOf(TMenu m)
    {
        return lang == 1 ? m.TitleIt : m.Title;
    }

    // ============================================================
    //  lista veicoli -> sottomenu per classe (al primo tick)
    // ============================================================
    static readonly string[] VCLASS = new string[] {
        "Compacts", "Sedans", "SUVs", "Coupes", "Muscle", "Sports Classics", "Sports",
        "Super", "Motorcycles", "Off-road", "Industrial", "Utility", "Vans", "Cycles",
        "Boats", "Helicopters", "Planes", "Service", "Emergency", "Military",
        "Commercial", "Trains"
    };

    // palette pastello "Miami Vice"
    static readonly int[,] PASTEL = new int[,] {
        { 255, 133, 192 },   // rosa neon
        { 130, 225, 235 },   // azzurro acqua
        { 170, 235, 190 },   // menta
        { 200, 170, 245 },   // lilla
        { 255, 190, 135 },   // pesca
        { 250, 235, 150 },   // giallo pastello
        { 255, 160, 160 },   // corallo
        { 160, 200, 255 }    // celeste
    };

    // famiglia di colore per classe: mezzi simili, stessa tinta
    //   1 = auto di strada   0 = sportive   2 = due ruote   4 = lavoro/fuoristrada
    //   3 = aria             7 = acqua      6 = soccorso/militari   5 = treni
    static readonly int[] CCOLOR = new int[] {
        1, 1, 1, 1,      // Compacts, Sedans, SUVs, Coupes
        0, 0, 0, 0,      // Muscle, Sports Classics, Sports, Super
        2,               // Motorcycles
        4, 4, 4, 4,      // Off-road, Industrial, Utility, Vans
        2,               // Cycles
        7,               // Boats
        3, 3,            // Helicopters, Planes
        4,               // Service
        6, 6,            // Emergency, Military
        4,               // Commercial
        5                // Trains
    };

    static readonly string[] VCLASS_IT = new string[] {
        "Compatte", "Berline", "SUV", "Coupe", "Muscle", "Sportive classiche", "Sportive",
        "Super", "Moto", "Fuoristrada", "Industriali", "Utilitari", "Furgoni", "Bici",
        "Barche", "Elicotteri", "Aerei", "Servizi", "Emergenza", "Militari",
        "Commerciali", "Treni"
    };

    int ClassFromText(string t)
    {
        if (t == null || t.Length == 0)
        {
            return -1;
        }
        string q = t.Trim().ToLower();

        int i;
        for (i = 0; i < VCLASS.Length; i++)
        {
            if (VCLASS[i].ToLower() == q || VCLASS_IT[i].ToLower() == q)
            {
                return i;
            }
        }
        // tolleranza: singolare/plurale e forme corte
        for (i = 0; i < VCLASS.Length; i++)
        {
            string a = VCLASS[i].ToLower();
            string b = VCLASS_IT[i].ToLower();
            if (a.StartsWith(q) || b.StartsWith(q) || q.StartsWith(a) || q.StartsWith(b))
            {
                return i;
            }
        }
        return -1;
    }

    void BuildPaintMenus(int mPaint)
    {
        string cf = DATA_DIR + "\\colors.txt";
        if (!File.Exists(cf))
        {
            return;
        }

        string[] rows = File.ReadAllLines(cf);

        // 4 destinazioni: primario, secondario, perlato, cerchi
        int[] tgtId = new int[] { 220, 221, 222, 223 };
        string[] tgtEn = new string[] { "Primary", "Secondary", "Pearlescent", "Details" };
        string[] tgtIt = new string[] { "Primario", "Secondario", "Perlato", "Dettagli" };

        int t;
        for (t = 0; t < tgtId.Length; t++)
        {
            int mt = NewMenu(tgtEn[t].ToUpper(), tgtIt[t].ToUpper(), mPaint);
            AddSub(mPaint, tgtEn[t], tgtIt[t], mt);

            List<string> gk = new List<string>();
            List<int> gm = new List<int>();

            int i;
            for (i = 0; i < rows.Length; i++)
            {
                string row = rows[i].Trim();
                if (row.Length == 0 || row.StartsWith("#")) continue;

                string[] f = row.Split('|');
                if (f.Length < 2) continue;

                int idx;
                if (!int.TryParse(f[0].Trim(), out idx)) continue;

                string cname = f[1].Trim();
                string grp = f.Length >= 3 ? f[2].Trim() : "Other";
                if (grp.Length == 0) grp = "Other";

                int g = gk.IndexOf(grp.ToLower());
                if (g < 0)
                {
                    int nm = NewMenu(grp.ToUpper(), grp.ToUpper(), mt);
                    AddSub(mt, grp, grp, nm);
                    gk.Add(grp.ToLower());
                    gm.Add(nm);
                    g = gk.Count - 1;
                }

                TItem ci = AddAction(gm[g], cname, cname, tgtId[t]);
                ci.Data = idx.ToString();
            }
        }
    }

    Vector3 FindObjectiveBlip()
    {
        // gli obiettivi di missione sono blip gialli (colore 5)
        int sprite;
        for (sprite = 1; sprite <= 250; sprite++)
        {
            int b = Function.Call<int>(Hash.GET_FIRST_BLIP_INFO_ID, sprite);
            while (Function.Call<bool>(Hash.DOES_BLIP_EXIST, b))
            {
                int col = Function.Call<int>(Hash.GET_BLIP_COLOUR, b);
                if (col == 5)
                {
                    return Function.Call<Vector3>(Hash.GET_BLIP_INFO_ID_COORD, b);
                }
                b = Function.Call<int>(Hash.GET_NEXT_BLIP_INFO_ID, sprite);
            }
        }
        return Vector3.Zero;
    }

    void TeleportTo(Vector3 dest)
    {
        Ped ped = Game.Player.Character;
        Entity what = ped;
        Vehicle v = ped.CurrentVehicle;
        if (v != null && v.Exists())
        {
            what = v;
        }

        // porta il giocatore in quota e cerca il terreno scendendo
        float[] probe = new float[] {
            1000f, 800f, 650f, 500f, 400f, 320f, 260f, 200f, 160f, 130f,
            100f, 80f, 62f, 50f, 40f, 32f, 25f, 20f, 15f, 10f, 5f, 0f
        };

        Function.Call(Hash.SET_ENTITY_COORDS, what, dest.X, dest.Y, 1000f, false, false, false, true);
        Script.Wait(200);

        int i;
        float groundZ = 0f;
        bool ok = false;
        for (i = 0; i < probe.Length; i++)
        {
            Function.Call(Hash.SET_ENTITY_COORDS, what, dest.X, dest.Y, probe[i], false, false, false, true);
            Script.Wait(40);

            OutputArgument oz = new OutputArgument();
            if (Function.Call<bool>(Hash.GET_GROUND_Z_FOR_3D_COORD, dest.X, dest.Y, probe[i], oz, false))
            {
                groundZ = oz.GetResult<float>();
                ok = true;
                break;
            }
        }

        if (!ok)
        {
            // niente terreno: prova il livello dell'acqua
            OutputArgument ow = new OutputArgument();
            if (Function.Call<bool>(Hash.GET_WATER_HEIGHT, dest.X, dest.Y, 100f, ow))
            {
                groundZ = ow.GetResult<float>();
                ok = true;
            }
        }

        if (!ok)
        {
            groundZ = dest.Z;
        }

        Function.Call(Hash.SET_ENTITY_COORDS, what, dest.X, dest.Y, groundZ + 1.0f, false, false, false, true);
        if (v != null && v.Exists())
        {
            Function.Call(Hash.SET_VEHICLE_ON_GROUND_PROPERLY, v);
        }

        Notification.PostTicker("~g~" + L("Teleported", "Teletrasportato"), false);
    }

    // ---------- anteprima colore mentre scorri ----------
    bool paintPreview = false;
    int savePrim, saveSec, savePearl, saveWheel;
    int lastPreviewMenu = -1;
    int lastPreviewSel = -1;

    bool ReadPaint()
    {
        Vehicle v = TargetVehicle();
        if (v == null || !v.Exists())
        {
            return false;
        }

        OutputArgument a1 = new OutputArgument();
        OutputArgument a2 = new OutputArgument();
        Function.Call(Hash.GET_VEHICLE_COLOURS, v, a1, a2);
        savePrim = a1.GetResult<int>();
        saveSec = a2.GetResult<int>();

        OutputArgument b1 = new OutputArgument();
        OutputArgument b2 = new OutputArgument();
        Function.Call(Hash.GET_VEHICLE_EXTRA_COLOURS, v, b1, b2);
        savePearl = b1.GetResult<int>();
        saveWheel = b2.GetResult<int>();
        return true;
    }

    void RestorePaint()
    {
        Vehicle v = TargetVehicle();
        if (v == null || !v.Exists())
        {
            return;
        }
        Function.Call(Hash.SET_VEHICLE_MOD_KIT, v, 0);
        Function.Call(Hash.SET_VEHICLE_COLOURS, v, SafeColor(savePrim), SafeColor(saveSec));
        Function.Call(Hash.SET_VEHICLE_EXTRA_COLOURS, v, SafeColor(savePearl), SafeColor(saveWheel));
    }

    void UpdatePaintPreview()
    {
        TMenu m = menus[cur];
        if (m.Items.Count == 0)
        {
            return;
        }

        TItem it = m.Items[m.Sel];
        bool isColor = it.Kind == TItem.ACTION && it.Id >= 220 && it.Id <= 223;

        if (!isColor)
        {
            if (paintPreview)
            {
                RestorePaint();
                paintPreview = false;
            }
            lastPreviewMenu = -1;
            lastPreviewSel = -1;
            return;
        }

        if (!paintPreview)
        {
            if (!ReadPaint())
            {
                return;
            }
            paintPreview = true;
        }

        if (cur == lastPreviewMenu && m.Sel == lastPreviewSel)
        {
            return;
        }
        lastPreviewMenu = cur;
        lastPreviewSel = m.Sel;

        int ci;
        if (int.TryParse(it.Data, out ci))
        {
            ApplyPaint(it.Id - 220, ci);
        }
    }

    // ============================================================
    //  VEICOLI SALVATI  (myvehicles.txt)
    //  formato: modello|targa|prim|sec|perlato|cerchi|x|y|z|heading|nome
    // ============================================================
    string MyVehFile()
    {
        return Path.Combine(DATA_DIR, "myvehicles.txt");
    }

    void LoadMyVehicles()
    {
        pvRaw.Clear();
        try
        {
            if (!File.Exists(MyVehFile())) return;
            string[] l = File.ReadAllLines(MyVehFile());
            int i;
            for (i = 0; i < l.Length; i++)
            {
                string row = l[i].Trim();
                if (row.Length == 0 || row.StartsWith("#")) continue;
                if (row.Split('|').Length < 11) continue;
                pvRaw.Add(row);
            }
        }
        catch (Exception)
        {
        }
    }

    void SaveMyVehicles()
    {
        try
        {
            Directory.CreateDirectory(DATA_DIR);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("# I MIEI VEICOLI - salvati dal trainer");
            sb.AppendLine("# hashmodello|targa|primario|secondario|perlato|cerchi|x|y|z|heading|nome|elaborazioni");
            int i;
            for (i = 0; i < pvRaw.Count; i++)
            {
                sb.AppendLine(pvRaw[i]);
            }
            File.WriteAllText(MyVehFile(), sb.ToString());
        }
        catch (Exception)
        {
        }
    }

    string PvField(int idx, int field)
    {
        if (idx < 0 || idx >= pvRaw.Count) return "";
        string[] f = pvRaw[idx].Split('|');
        if (field < 0 || field >= f.Length) return "";
        return f[field].Trim();
    }

    float PvFloat(int idx, int field)
    {
        float r;
        if (float.TryParse(PvField(idx, field), NumberStyles.Float, CultureInfo.InvariantCulture, out r)) return r;
        return 0f;
    }

    // il campo 0 e' l'hash del modello; le righe vecchie hanno un nome
    // le targhe di GTA arrivano riempite di spazi: vanno sempre normalizzate,
    // altrimenti il confronto fallisce e si creano doppioni all'infinito
    string PlateOf(Vehicle v)
    {
        string t = Function.Call<string>(Hash.GET_VEHICLE_NUMBER_PLATE_TEXT, v);
        if (t == null) return "";
        return t.Trim().ToUpper();
    }

    string PvPlate(int idx)
    {
        return PvField(idx, 1).Trim().ToUpper();
    }

    int PvHash(int idx)
    {
        string f0 = PvField(idx, 0);
        int h;
        if (int.TryParse(f0, out h)) return h;
        return Function.Call<int>(Hash.GET_HASH_KEY, f0);
    }

    int PvInt(int idx, int field)
    {
        int r;
        if (int.TryParse(PvField(idx, field), out r)) return r;
        return 0;
    }

    void BuildMyVehicles()
    {
        if (mMyVeh < 0) return;

        menus[mMyVeh].Items.Clear();
        menus[mMyVeh].Sel = 0;
        menus[mMyVeh].Top = 0;

        int i;
        for (i = 0; i < pvRaw.Count; i++)
        {
            string nm = PvField(i, 10);
            if (nm.Length == 0) nm = PvField(i, 0);

            int sm = NewMenu(nm.ToUpper(), nm.ToUpper(), mMyVeh);
            AddSub(mMyVeh, nm, nm, sm);

            TItem a1 = AddAction(sm, "Go to vehicle", "Vai al veicolo", 230);
            a1.Data = i.ToString();
            TItem a2 = AddAction(sm, "Bring here", "Portalo qui", 231);
            a2.Data = i.ToString();
            TItem a3 = AddAction(sm, "Remove from list", "Rimuovi dalla lista", 232);
            a3.Data = i.ToString();
        }
    }

    int FindMyVehicle(Vehicle v)
    {
        if (v == null || !v.Exists()) return -1;

        string plate = PlateOf(v);
        int hash = v.Model.Hash;

        int i;
        for (i = 0; i < pvRaw.Count; i++)
        {
            if (PvPlate(i) != plate) continue;
            if (PvHash(i) == hash) return i;
        }
        return -1;
    }

    string ComposeEntry(Vehicle v, string name)
    {
        OutputArgument a1 = new OutputArgument();
        OutputArgument a2 = new OutputArgument();
        Function.Call(Hash.GET_VEHICLE_COLOURS, v, a1, a2);
        OutputArgument b1 = new OutputArgument();
        OutputArgument b2 = new OutputArgument();
        Function.Call(Hash.GET_VEHICLE_EXTRA_COLOURS, v, b1, b2);

        string plate = PlateOf(v);
        Vector3 pp = v.Position;

        return v.Model.Hash + "|" + plate + "|"
             + a1.GetResult<int>() + "|" + a2.GetResult<int>() + "|"
             + b1.GetResult<int>() + "|" + b2.GetResult<int>() + "|"
             + pp.X.ToString("0.000", CultureInfo.InvariantCulture) + "|"
             + pp.Y.ToString("0.000", CultureInfo.InvariantCulture) + "|"
             + pp.Z.ToString("0.000", CultureInfo.InvariantCulture) + "|"
             + v.Heading.ToString("0.0", CultureInfo.InvariantCulture) + "|"
             + name + "|"
             + CollectMods(v);
    }

    void SaveVehicleEntry(Vehicle v, string modelName)
    {
        if (v == null || !v.Exists()) return;

        string label = VehLabel(v.Model.Hash, modelName);
        string line = ComposeEntry(v, label);

        int idx = FindMyVehicle(v);
        if (idx >= 0)
        {
            pvRaw[idx] = line;
        }
        else
        {
            pvRaw.Add(line);
            idx = pvRaw.Count - 1;
        }

        trackedIdx = idx;
        SaveMyVehicles();
        BuildMyVehicles();
    }

    // ============================================================
    //  elaborazioni: le legge dal veicolo e le riscrive identiche
    //  formato compatto:  m<slot>=<idx>;t<slot>=<0|1>;wt=..;tint=..;ts=r.g.b;liv=..;ps=..;bp=..;x<n>=<0|1>
    // ============================================================
    static readonly int[] TOGGLE_SLOTS = new int[] { 17, 18, 19, 20, 21, 22 };

    static readonly string[] SLOT_EN = new string[] {
        "Spoiler", "Front bumper", "Rear bumper", "Side skirts", "Exhaust", "Roll cage",
        "Grille", "Hood", "Left fender", "Right fender", "Roof", "Engine", "Brakes",
        "Transmission", "Horn", "Suspension", "Armour", "Slot 17", "Turbo", "Slot 19",
        "Tyre smoke", "Slot 21", "Xenon lights", "Front wheels", "Rear wheels",
        "Plate holder", "Vanity plate", "Trim design", "Ornaments", "Dashboard",
        "Dials", "Door speakers", "Seats", "Steering wheel", "Shifter", "Plaques",
        "Speakers", "Trunk", "Hydraulics", "Engine block", "Air filter", "Struts",
        "Arch covers", "Aerials", "Trim", "Tank", "Windows", "Slot 47", "Livery"
    };

    static readonly string[] SLOT_IT = new string[] {
        "Spoiler", "Paraurti anteriore", "Paraurti posteriore", "Minigonne", "Scarico", "Roll bar",
        "Griglia", "Cofano", "Parafango sx", "Parafango dx", "Tetto", "Motore", "Freni",
        "Cambio", "Clacson", "Sospensioni", "Corazzatura", "Slot 17", "Turbo", "Slot 19",
        "Fumo gomme", "Slot 21", "Fari allo xeno", "Cerchi anteriori", "Cerchi posteriori",
        "Portatarga", "Targa personalizzata", "Rivestimenti", "Ornamenti", "Cruscotto",
        "Strumenti", "Casse portiere", "Sedili", "Volante", "Leva del cambio", "Targhette",
        "Casse", "Bagagliaio", "Idraulica", "Blocco motore", "Filtro aria", "Montanti",
        "Passaruota", "Antenne", "Finiture", "Serbatoio", "Finestrini", "Slot 47", "Livrea"
    };

    bool IsToggleSlot(int slot)
    {
        int i;
        for (i = 0; i < TOGGLE_SLOTS.Length; i++)
        {
            if (TOGGLE_SLOTS[i] == slot) return true;
        }
        return false;
    }

    string CollectMods(Vehicle v)
    {
        if (v == null || !v.Exists()) return "";

        Function.Call(Hash.SET_VEHICLE_MOD_KIT, v, 0);
        StringBuilder sb = new StringBuilder();

        int slot;
        for (slot = 0; slot <= 48; slot++)
        {
            if (IsToggleSlot(slot))
            {
                if (Function.Call<bool>(Hash.IS_TOGGLE_MOD_ON, v, slot))
                {
                    sb.Append("t" + slot + "=1;");
                }
            }
            else
            {
                int mod = Function.Call<int>(Hash.GET_VEHICLE_MOD, v, slot);
                if (mod >= 0)
                {
                    sb.Append("m" + slot + "=" + mod + ";");
                }
            }
        }

        sb.Append("wt=" + Function.Call<int>(Hash.GET_VEHICLE_WHEEL_TYPE, v) + ";");
        sb.Append("tint=" + Function.Call<int>(Hash.GET_VEHICLE_WINDOW_TINT, v) + ";");
        sb.Append("liv=" + Function.Call<int>(Hash.GET_VEHICLE_LIVERY, v) + ";");
        sb.Append("ps=" + Function.Call<int>(Hash.GET_VEHICLE_NUMBER_PLATE_TEXT_INDEX, v) + ";");

        OutputArgument sr = new OutputArgument();
        OutputArgument sg = new OutputArgument();
        OutputArgument sbb = new OutputArgument();
        Function.Call(Hash.GET_VEHICLE_TYRE_SMOKE_COLOR, v, sr, sg, sbb);
        sb.Append("ts=" + sr.GetResult<int>() + "." + sg.GetResult<int>() + "." + sbb.GetResult<int>() + ";");

        int ex;
        for (ex = 1; ex <= 14; ex++)
        {
            if (Function.Call<bool>(Hash.DOES_EXTRA_EXIST, v, ex))
            {
                bool on = Function.Call<bool>(Hash.IS_VEHICLE_EXTRA_TURNED_ON, v, ex);
                sb.Append("x" + ex + "=" + (on ? "1" : "0") + ";");
            }
        }

        return sb.ToString();
    }

    void ApplyMods(Vehicle v, string data)
    {
        if (v == null || !v.Exists()) return;
        if (data == null || data.Length == 0) return;

        Function.Call(Hash.SET_VEHICLE_MOD_KIT, v, 0);

        string[] parts = data.Split(';');
        int i;

        // il tipo di cerchio va impostato prima dei cerchi stessi
        for (i = 0; i < parts.Length; i++)
        {
            string q = parts[i].Trim();
            if (!q.StartsWith("wt=")) continue;
            int wt;
            if (int.TryParse(q.Substring(3), out wt))
            {
                Function.Call(Hash.SET_VEHICLE_WHEEL_TYPE, v, wt);
            }
        }

        for (i = 0; i < parts.Length; i++)
        {
            string q = parts[i].Trim();
            if (q.Length < 3) continue;

            int eq = q.IndexOf('=');
            if (eq < 1) continue;

            string key = q.Substring(0, eq);
            string val = q.Substring(eq + 1);

            if (key == "wt")
            {
                continue;
            }
            else if (key == "tint")
            {
                int t;
                if (int.TryParse(val, out t)) Function.Call(Hash.SET_VEHICLE_WINDOW_TINT, v, t);
            }
            else if (key == "liv")
            {
                int t;
                if (int.TryParse(val, out t) && t >= 0) Function.Call(Hash.SET_VEHICLE_LIVERY, v, t);
            }
            else if (key == "ps")
            {
                int t;
                if (int.TryParse(val, out t)) Function.Call(Hash.SET_VEHICLE_NUMBER_PLATE_TEXT_INDEX, v, t);
            }
            else if (key == "ts")
            {
                string[] rgb = val.Split('.');
                if (rgb.Length == 3)
                {
                    int r, g, b;
                    if (int.TryParse(rgb[0], out r) && int.TryParse(rgb[1], out g) && int.TryParse(rgb[2], out b))
                    {
                        Function.Call(Hash.SET_VEHICLE_TYRE_SMOKE_COLOR, v, r, g, b);
                    }
                }
            }
            else if (key.StartsWith("m"))
            {
                int slot, idx;
                if (int.TryParse(key.Substring(1), out slot) && int.TryParse(val, out idx))
                {
                    // un indice che quel modello non ha fa crashare il gioco
                    int num = Function.Call<int>(Hash.GET_NUM_VEHICLE_MODS, v, slot);
                    if (idx >= 0 && idx < num)
                    {
                        Function.Call(Hash.SET_VEHICLE_MOD, v, slot, idx, false);
                    }
                }
            }
            else if (key.StartsWith("t"))
            {
                int slot;
                if (int.TryParse(key.Substring(1), out slot))
                {
                    Function.Call(Hash.TOGGLE_VEHICLE_MOD, v, slot, val == "1");
                }
            }
            else if (key.StartsWith("x"))
            {
                int ex;
                if (int.TryParse(key.Substring(1), out ex))
                {
                    Function.Call(Hash.SET_VEHICLE_EXTRA, v, ex, val == "1" ? 0 : 1);
                }
            }
        }
    }

    // a quale gruppo appartiene ogni slot
    //  0 = carrozzeria   1 = meccanica   2 = ruote   3 = luci e altro
    static readonly int[] SLOT_GROUP = new int[] {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,   // 0-10  spoiler ... tetto
        1, 1, 1,                            // 11 motore, 12 freni, 13 cambio
        3,                                  // 14 clacson
        1, 1,                               // 15 sospensioni, 16 corazzatura
        3, 1, 3, 3, 3,                      // 17, 18 turbo, 19, 20 fumo, 21
        3,                                  // 22 xeno
        2, 2,                               // 23-24 cerchi
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 25-36 interni ed estetica
        0,                                  // 37 bagagliaio
        1,                                  // 38 idraulica
        0, 0, 0, 0, 0, 0, 0, 0,             // 39-46
        0,                                  // 47
        0                                   // 48 livrea
    };

    int MenuForGroup(int g)
    {
        if (g == 1) return mMech;
        if (g == 2) return mWheels;
        if (g == 3) return mLights;
        return mBody;
    }

    void BuildModShop()
    {
        if (mModShop < 0) return;

        menus[mModShop].Items.Clear();
        menus[mModShop].Sel = 0;
        menus[mModShop].Top = 0;
        menus[mBody].Items.Clear();
        menus[mMech].Items.Clear();
        menus[mWheels].Items.Clear();
        menus[mLights].Items.Clear();
        menus[mExtras].Items.Clear();

        Vehicle v = TargetVehicle();
        if (v == null || !v.Exists())
        {
            AddAction(mModShop, "No vehicle nearby", "Nessun veicolo vicino", -1);
            return;
        }

        Function.Call(Hash.SET_VEHICLE_MOD_KIT, v, 0);

        // ---- tipo di cerchio: sempre in cima al menu ruote ----
        string[] wtn = new string[] {
            "Sport", "Muscle", "Lowrider", "SUV", "Offroad", "Tuner",
            "Bike", "High End", "Benny's Original", "Benny's Bespoke", "Open Wheel",
            "Street", "Track"
        };
        TItem wt = AddList(mWheels, "Wheel type", "Tipo cerchi", 243, wtn, 0);
        int cwt = Function.Call<int>(Hash.GET_VEHICLE_WHEEL_TYPE, v);
        if (cwt >= 0 && cwt < wtn.Length) wt.Sel = cwt;

        // ---- tutti gli slot, ognuno nel suo gruppo ----
        int slot;
        for (slot = 0; slot <= 48; slot++)
        {
            string nameEn = slot < SLOT_EN.Length ? SLOT_EN[slot] : ("Slot " + slot);
            string nameIt = slot < SLOT_IT.Length ? SLOT_IT[slot] : ("Slot " + slot);
            int dest = MenuForGroup(slot < SLOT_GROUP.Length ? SLOT_GROUP[slot] : 0);

            if (IsToggleSlot(slot))
            {
                if (slot != 18 && slot != 20 && slot != 22) continue;
                TItem tg = AddToggle(dest, nameEn, nameIt, 242, false);
                tg.Data = slot.ToString();
                tg.On = Function.Call<bool>(Hash.IS_TOGGLE_MOD_ON, v, slot);
                continue;
            }

            int num = Function.Call<int>(Hash.GET_NUM_VEHICLE_MODS, v, slot);
            if (num <= 0) continue;

            string[] opts = new string[num + 1];
            opts[0] = L("Stock", "Di serie");
            int k;
            for (k = 0; k < num; k++)
            {
                opts[k + 1] = (k + 1).ToString();
            }

            TItem li = AddList(dest, nameEn, nameIt, 241, opts, 0);
            li.Data = slot.ToString();
            int curMod = Function.Call<int>(Hash.GET_VEHICLE_MOD, v, slot);
            li.Sel = (curMod >= 0 && curMod < num) ? curMod + 1 : 0;
        }

        // ---- vetri e livrea ----
        string[] tints = new string[] { "None", "Black", "Dark smoke", "Light smoke", "Limo", "Green" };
        TItem ti = AddList(mLights, "Window tint", "Vetri oscurati", 244, tints, 0);
        int ct = Function.Call<int>(Hash.GET_VEHICLE_WINDOW_TINT, v);
        if (ct >= 0 && ct < tints.Length) ti.Sel = ct;

        int livCount = Function.Call<int>(Hash.GET_VEHICLE_LIVERY_COUNT, v);
        if (livCount > 0)
        {
            string[] livs = new string[livCount + 1];
            livs[0] = L("None", "Nessuna");
            int q;
            for (q = 0; q < livCount; q++)
            {
                livs[q + 1] = (q + 1).ToString();
            }
            TItem lv = AddList(mBody, "Livery", "Livrea", 246, livs, 0);
            int cl = Function.Call<int>(Hash.GET_VEHICLE_LIVERY, v);
            lv.Sel = (cl >= 0 && cl < livCount) ? cl + 1 : 0;
        }

        // ---- extra del modello ----
        int ex;
        for (ex = 1; ex <= 14; ex++)
        {
            if (!Function.Call<bool>(Hash.DOES_EXTRA_EXIST, v, ex)) continue;
            TItem xt = AddToggle(mExtras, "Extra " + ex, "Extra " + ex, 247, false);
            xt.Data = ex.ToString();
            xt.On = Function.Call<bool>(Hash.IS_VEHICLE_EXTRA_TURNED_ON, v, ex);
        }

        // ---- indice del menu officina ----
        AddAction(mModShop, "Max upgrades", "Elaborazione massima", 248);
        AddAction(mModShop, "Back to stock", "Torna di serie", 249);

        AddHeader(mModShop, "- SECTIONS -", "- SEZIONI -", 1);
        if (menus[mBody].Items.Count > 0)
        {
            TItem b1 = AddSub(mModShop, "Bodywork", "Carrozzeria", mBody);
            b1.Cr = PASTEL[1, 0]; b1.Cg = PASTEL[1, 1]; b1.Cb = PASTEL[1, 2]; b1.Tinted = true;
        }
        if (menus[mMech].Items.Count > 0)
        {
            TItem b2 = AddSub(mModShop, "Mechanics", "Meccanica", mMech);
            b2.Cr = PASTEL[0, 0]; b2.Cg = PASTEL[0, 1]; b2.Cb = PASTEL[0, 2]; b2.Tinted = true;
        }
        if (menus[mWheels].Items.Count > 0)
        {
            TItem b3 = AddSub(mModShop, "Wheels", "Ruote", mWheels);
            b3.Cr = PASTEL[2, 0]; b3.Cg = PASTEL[2, 1]; b3.Cb = PASTEL[2, 2]; b3.Tinted = true;
        }
        if (menus[mLights].Items.Count > 0)
        {
            TItem b4 = AddSub(mModShop, "Lights & other", "Luci e altro", mLights);
            b4.Cr = PASTEL[5, 0]; b4.Cg = PASTEL[5, 1]; b4.Cb = PASTEL[5, 2]; b4.Tinted = true;
        }
        if (menus[mExtras].Items.Count > 0)
        {
            TItem b5 = AddSub(mModShop, "Extras", "Extra", mExtras);
            b5.Cr = PASTEL[4, 0]; b5.Cg = PASTEL[4, 1]; b5.Cb = PASTEL[4, 2]; b5.Tinted = true;
        }

        menus[mModShop].Sel = FirstSelectable(mModShop);
    }

    void TouchSaved(Vehicle v)
    {
        int ti = FindMyVehicle(v);
        if (ti < 0) return;

        int keep = trackedIdx;
        trackedIdx = ti;
        UpdateTrackedEntry(v);
        trackedIdx = keep < 0 ? ti : keep;
    }

    void UpdateTrackedEntry(Vehicle v)
    {
        if (trackedIdx < 0 || trackedIdx >= pvRaw.Count) return;
        if (v == null || !v.Exists()) return;

        string[] old = pvRaw[trackedIdx].Split('|');
        if (old.Length < 11) return;

        string name = old[10];

        OutputArgument a1 = new OutputArgument();
        OutputArgument a2 = new OutputArgument();
        Function.Call(Hash.GET_VEHICLE_COLOURS, v, a1, a2);
        OutputArgument b1 = new OutputArgument();
        OutputArgument b2 = new OutputArgument();
        Function.Call(Hash.GET_VEHICLE_EXTRA_COLOURS, v, b1, b2);

        string plate = PlateOf(v);
        Vector3 pp = v.Position;

        pvRaw[trackedIdx] = v.Model.Hash + "|" + plate + "|"
            + a1.GetResult<int>() + "|" + a2.GetResult<int>() + "|"
            + b1.GetResult<int>() + "|" + b2.GetResult<int>() + "|"
            + pp.X.ToString("0.000", CultureInfo.InvariantCulture) + "|"
            + pp.Y.ToString("0.000", CultureInfo.InvariantCulture) + "|"
            + pp.Z.ToString("0.000", CultureInfo.InvariantCulture) + "|"
            + v.Heading.ToString("0.0", CultureInfo.InvariantCulture) + "|"
            + name + "|"
            + CollectMods(v);

        SaveMyVehicles();
    }

    // ============================================================
    //  comparsa "pigra": il veicolo esiste solo quando gli sei vicino.
    //  Entro LAZY_RANGE viene creato, oltre CLEANUP_RANGE viene tolto.
    //  La posizione resta comunque scritta nel file.
    // ============================================================
    const float LAZY_RANGE = 200f;
    const float CLEANUP_RANGE = 500f;
    const int LAZY_INTERVAL = 500;
    int lazyNext = 0;

    void SetBlipName(int blip, string name)
    {
        Function.Call(Hash.BEGIN_TEXT_COMMAND_SET_BLIP_NAME, "STRING");
        Function.Call(Hash.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME, name);
        Function.Call(Hash.END_TEXT_COMMAND_SET_BLIP_NAME, blip);
    }

    void ClearBlips()
    {
        int i;
        for (i = 0; i < pvBlip.Count; i++)
        {
            HideBlip(pvBlip[i]);
        }
        pvBlip.Clear();
    }

    void UpdateBlips(Vehicle[] all)
    {
        // allinea la lista dei blip a quella dei veicoli salvati
        while (pvBlip.Count < pvRaw.Count) pvBlip.Add(0);
        while (pvBlip.Count > pvRaw.Count)
        {
            int last = pvBlip.Count - 1;
            HideBlip(pvBlip[last]);
            pvBlip.RemoveAt(last);
        }

        bool on = (tBlips != null && tBlips.On) && (tPersist != null && tPersist.On);

        int i;
        for (i = 0; i < pvRaw.Count; i++)
        {
            if (!on)
            {
                HideBlip(pvBlip[i]);
                continue;
            }

            Vehicle wv = FindWorldVehicle(i, all);

            // posizione: quella vera se il veicolo esiste, altrimenti quella salvata
            Vector3 pos = new Vector3(PvFloat(i, 6), PvFloat(i, 7), PvFloat(i, 8));
            if (wv != null && wv.Exists()) pos = wv.Position;

            // se lo stai guidando il blip non serve: si NASCONDE, non si distrugge.
            // Ricrearlo ogni volta significherebbe rifare il comando di testo per
            // il nome mentre il gioco ne sta usando uno suo, e li' crasha.
            Vehicle mine = Game.Player.Character.CurrentVehicle;
            bool driving = (wv != null && mine != null && wv.Handle == mine.Handle);

            if (pvBlip[i] == 0 || !Function.Call<bool>(Hash.DOES_BLIP_EXIST, pvBlip[i]))
            {
                if (driving) continue;   // niente creazione mentre sei a bordo

                int b = Function.Call<int>(Hash.ADD_BLIP_FOR_COORD, pos.X, pos.Y, pos.Z);

                int hash = PvHash(i);
                int cls = Function.Call<int>(Hash.GET_VEHICLE_CLASS_FROM_NAME, hash);
                int sprite = 225;                       // auto personale
                if (cls == 8 || cls == 13) sprite = 226; // moto / bici
                else if (cls == 14) sprite = 427;        // barca
                else if (cls == 15) sprite = 422;        // elicottero
                else if (cls == 16) sprite = 423;        // aereo

                Function.Call(Hash.SET_BLIP_SPRITE, b, sprite);
                Function.Call(Hash.SET_BLIP_COLOUR, b, 3);
                Function.Call(Hash.SET_BLIP_SCALE, b, 0.75f);
                Function.Call(Hash.SET_BLIP_AS_SHORT_RANGE, b, true);
                SetBlipName(b, PvField(i, 10));

                pvBlip[i] = b;
            }
            else if (driving)
            {
                Function.Call(Hash.SET_BLIP_ALPHA, pvBlip[i], 0);
            }
            else
            {
                ShowBlip(pvBlip[i]);
                Function.Call(Hash.SET_BLIP_COORDS, pvBlip[i], pos.X, pos.Y, pos.Z);
            }
        }
    }

    // ============================================================
    //  BENZINA
    // ============================================================
    int gasMade = 0;

    void MakeGasBlips()
    {
        if (gasBlips != null) return;
        gasBlips = new int[GX.Length];
        gasMade = 0;
    }

    // senza rinomina non ci sono comandi di testo, ma li creiamo lo stesso
    // a piccoli gruppi: e' lavoro sparso invece che un picco in un frame
    void PumpGasBlips()
    {
        if (gasBlips == null) return;
        if (gasMade >= GX.Length) return;

        int made = 0;
        while (gasMade < GX.Length && made < 2)
        {
            int i = gasMade;
            int b = Function.Call<int>(Hash.ADD_BLIP_FOR_COORD, GX[i], GY[i], GZ[i]);
            Function.Call(Hash.SET_BLIP_SPRITE, b, 361);
            Function.Call(Hash.SET_BLIP_COLOUR, b, 1);       // rosso
            Function.Call(Hash.SET_BLIP_SCALE, b, 0.65f);
            Function.Call(Hash.SET_BLIP_AS_SHORT_RANGE, b, true);
            gasBlips[i] = b;

            gasMade++;
            made++;
        }
    }


    string TankKeyOf(Vehicle v)
    {
        if (v == null || !v.Exists()) return "";
        return v.Model.Hash + ":" + Function.Call<string>(Hash.GET_VEHICLE_NUMBER_PLATE_TEXT, v);
    }

    float GetTank(string key)
    {
        int i = tankKey.IndexOf(key);
        if (i < 0) return 100f;
        return tankVal[i];
    }

    void SetTank(string key, float val)
    {
        if (key.Length == 0) return;
        int i = tankKey.IndexOf(key);
        if (i < 0)
        {
            tankKey.Add(key);
            tankVal.Add(val);
        }
        else
        {
            tankVal[i] = val;
        }
    }

    float GetOil(string key)
    {
        int i = oilKey.IndexOf(key);
        if (i < 0) return 100f;
        return oilVal[i];
    }

    void SetOil(string key, float val)
    {
        if (key.Length == 0) return;
        int i = oilKey.IndexOf(key);
        if (i < 0)
        {
            oilKey.Add(key);
            oilVal.Add(val);
        }
        else
        {
            oilVal[i] = val;
        }
    }

    void SaveOil()
    {
        try
        {
            Directory.CreateDirectory(DATA_DIR);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("# tagliando: modello:targa=metri odometro all'ultimo servizio");
            int i;
            for (i = 0; i < oilKey.Count; i++)
            {
                sb.AppendLine(oilKey[i] + "=" + oilVal[i].ToString("0.#", CultureInfo.InvariantCulture));
            }
            File.WriteAllText(Path.Combine(DATA_DIR, "oil.txt"), sb.ToString());
        }
        catch (Exception) { }
    }

    void LoadOil()
    {
        try
        {
            string f = Path.Combine(DATA_DIR, "oil.txt");
            if (!File.Exists(f)) return;

            oilKey.Clear();
            oilVal.Clear();

            string[] rows = File.ReadAllLines(f);
            int i;
            for (i = 0; i < rows.Length; i++)
            {
                string row = rows[i].Trim();
                if (row.Length == 0 || row.StartsWith("#")) continue;
                int eq = row.LastIndexOf('=');
                if (eq < 1) continue;
                float val;
                if (!float.TryParse(row.Substring(eq + 1), NumberStyles.Float,
                                    CultureInfo.InvariantCulture, out val)) continue;
                oilKey.Add(row.Substring(0, eq));
                oilVal.Add(val);
            }
        }
        catch (Exception) { }
    }

    // Il tagliando si misura sui chilometri percorsi dall'ultimo, non su un
    // livello a se': l'olio che vedi scendere e' la stessa cosa vista da
    // un'altra parte. Benzina 1000 km, elettriche 2000 (li' non c'e' olio,
    // ma freni, gomme e batteria un controllo lo vogliono lo stesso).
    float ServiceKmLeft(Vehicle v, bool ev)
    {
        float total = ev ? SERVICE_M_EV : SERVICE_M_PETROL;
        float done = odoM - servM;
        if (done < 0f) done = 0f;
        return (total - done) / 1000f;
    }

    void UpdateOil(Ped p, Vehicle v, float meters, bool ev)
    {
        string k = TankKeyOf(v);
        if (k != curOilKey)
        {
            if (curOilKey.Length > 0) SetOil(curOilKey, servM);
            curOilKey = k;
            servM = GetOil(k);
        }

        float total = ev ? SERVICE_M_EV : SERVICE_M_PETROL;
        float done = odoM - servM;
        if (done < 0f) { done = 0f; servM = odoM; }

        // l'olio e' la percentuale di tagliando che ti resta
        oil = 100f * (1f - done / total);
        if (oil < 0f) oil = 0f;
        if (oil > 100f) oil = 100f;

        SetOil(curOilKey, servM);

        int now = Game.GameTime;

        // ---- le elettriche non perdono potenza: solo il promemoria ----
        if (ev)
        {
            if (oil <= 0f && now > oilWarnAt + 90000)
            {
                oilWarnAt = now;
                Notification.PostTicker("~y~" + L("Service due", "Tagliando da fare")
                    + "~s~ - " + ((int)(odoM / 1000f)) + " km", false);
            }
            return;
        }

        // ---- benzina: olio vero, e se lo trascuri la macchina non tira ----
        if (oil < 30f)
        {
            float mult = 0.55f + (oil / 30f) * 0.45f;    // da 1.00 a 0.55
            Function.Call(Hash.MODIFY_VEHICLE_TOP_SPEED, v, mult);
            oilSlowVeh = v.Handle;
        }
        else if (oilSlowVeh == v.Handle)
        {
            Function.Call(Hash.MODIFY_VEHICLE_TOP_SPEED, v, 1f);
            oilSlowVeh = 0;
        }

        if (oil <= 0f)
        {
            float eh = Function.Call<float>(Hash.GET_VEHICLE_ENGINE_HEALTH, v);
            if (eh > 200f && meters > 0f)
            {
                Function.Call(Hash.SET_VEHICLE_ENGINE_HEALTH, v, eh - meters * 0.05f);
            }
            if (now > oilWarnAt + 30000)
            {
                oilWarnAt = now;
                Notification.PostTicker("~r~" + L("No oil!", "Olio finito!") + "~s~ "
                    + L("the engine is wearing out - service it now",
                        "il motore si sta rovinando - fai subito il tagliando"), false);
            }
        }
        else if (oil < 10f && now > oilWarnAt + 60000)
        {
            oilWarnAt = now;
            Notification.PostTicker("~r~" + L("Service overdue", "Tagliando scaduto") + "~s~ - "
                + L("the engine is losing power", "il motore non tira piu'"), false);
        }
        else if (oil < 25f && now > oilWarnAt + 120000)
        {
            oilWarnAt = now;
            Notification.PostTicker("~y~" + L("Service due soon", "Tagliando in scadenza")
                + "~s~ - " + ((int)ServiceKmLeft(v, ev)) + " km", false);
        }
    }

    float GetOdo(string key)
    {
        int i = odoKey.IndexOf(key);
        if (i < 0) return 0f;
        return odoVal[i];
    }

    void SetOdo(string key, float val)
    {
        if (key.Length == 0) return;
        int i = odoKey.IndexOf(key);
        if (i < 0) { odoKey.Add(key); odoVal.Add(val); }
        else odoVal[i] = val;
    }

    void SaveOdo()
    {
        try
        {
            Directory.CreateDirectory(DATA_DIR);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("# odometro: modello:targa=metri");
            int i;
            for (i = 0; i < odoKey.Count; i++)
            {
                sb.AppendLine(odoKey[i] + "=" + odoVal[i].ToString("0", CultureInfo.InvariantCulture));
            }
            File.WriteAllText(Path.Combine(DATA_DIR, "odo.txt"), sb.ToString());
        }
        catch (Exception) { }
    }

    void LoadOdo()
    {
        try
        {
            string f = Path.Combine(DATA_DIR, "odo.txt");
            if (!File.Exists(f)) return;

            odoKey.Clear();
            odoVal.Clear();

            string[] rows = File.ReadAllLines(f);
            int i;
            for (i = 0; i < rows.Length; i++)
            {
                string row = rows[i].Trim();
                if (row.Length == 0 || row.StartsWith("#")) continue;
                int eq = row.LastIndexOf('=');
                if (eq < 1) continue;
                float val;
                if (!float.TryParse(row.Substring(eq + 1), NumberStyles.Float,
                                    CultureInfo.InvariantCulture, out val)) continue;
                odoKey.Add(row.Substring(0, eq));
                odoVal.Add(val);
            }
        }
        catch (Exception) { }
    }

    void UpdateOdo(Vehicle v, float meters)
    {
        string k = TankKeyOf(v);
        if (k != curOdoKey)
        {
            if (curOdoKey.Length > 0) SetOdo(curOdoKey, odoM);
            curOdoKey = k;
            odoM = GetOdo(k);
        }

        if (meters > 0f) odoM = odoM + meters;
        SetOdo(curOdoKey, odoM);

        // su file ogni mezzo minuto: non ha senso scrivere a ogni frame
        int now = Game.GameTime;
        if (now > odoSaveAt + 30000)
        {
            odoSaveAt = now;
            SaveOdo();
        }
    }

    void SaveTanks()
    {
        try
        {
            Directory.CreateDirectory(DATA_DIR);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("# serbatoi: modello:targa=litri%");
            int i;
            for (i = 0; i < tankKey.Count; i++)
            {
                sb.AppendLine(tankKey[i] + "=" + tankVal[i].ToString("0.#", CultureInfo.InvariantCulture));
            }
            File.WriteAllText(Path.Combine(DATA_DIR, "fuel.txt"), sb.ToString());
        }
        catch (Exception)
        {
        }
    }

    void LoadTanks()
    {
        try
        {
            string f = Path.Combine(DATA_DIR, "fuel.txt");
            if (!File.Exists(f)) return;

            tankKey.Clear();
            tankVal.Clear();
            string[] l = File.ReadAllLines(f);
            int i;
            for (i = 0; i < l.Length; i++)
            {
                string row = l[i].Trim();
                if (row.Length == 0 || row.StartsWith("#")) continue;
                int eq = row.LastIndexOf('=');
                if (eq < 1) continue;
                float val;
                if (!float.TryParse(row.Substring(eq + 1), NumberStyles.Float, CultureInfo.InvariantCulture, out val)) continue;
                tankKey.Add(row.Substring(0, eq));
                tankVal.Add(val);
            }
        }
        catch (Exception)
        {
        }
    }

    bool IsHybrid(Vehicle v)
    {
        if (v == null || !v.Exists()) return false;
        int hash = v.Model.Hash;
        int i;
        for (i = 0; i < HYBRID.Length; i++)
        {
            if (Function.Call<int>(Hash.GET_HASH_KEY, HYBRID[i]) == hash) return true;
        }
        return false;
    }

    bool IsElectric(Vehicle v)
    {
        if (v == null || !v.Exists()) return false;

        int hash = v.Model.Hash;
        int i;
        for (i = 0; i < ELECTRIC.Length; i++)
        {
            if (Function.Call<int>(Hash.GET_HASH_KEY, ELECTRIC[i]) == hash) return true;
        }
        return false;
    }

    void UpdateFuel(Ped p)
    {
        if (tFuel == null || !tFuel.On) return;

        Vehicle v = p.CurrentVehicle;
        if (v == null || !v.Exists())
        {
            if (curTankKey.Length > 0)
            {
                SetTank(curTankKey, fuel);
                SaveTanks();
                curTankKey = "";
            }
            return;
        }

        // cambio mezzo: ogni veicolo ha il suo serbatoio
        string k = TankKeyOf(v);
        if (k != curTankKey)
        {
            if (curTankKey.Length > 0) SetTank(curTankKey, fuel);
            curTankKey = k;
            fuel = GetTank(k);
        }

        bool evNow = IsElectric(v);
        evCurrent = evNow;

        // tiene allineato l'olio al mezzo su cui sei, anche da fermo
        if (TankKeyOf(v) != curOilKey) UpdateOil(p, v, 0f, evNow);
        if (TankKeyOf(v) != curOdoKey) UpdateOdo(v, 0f);

        bool vehGod = (VehGodMode() == 3) || v.IsInvincible;   // solo Full toglie il consumo

        Ped drv = v.Driver;
        if (drv != null && drv.Handle == p.Handle && fuel > 0f && !vehGod)
        {
            float accel = Function.Call<float>(Hash.GET_CONTROL_NORMAL, 0, 71);
            float meters = Function.Call<float>(Hash.GET_ENTITY_SPEED, v) * Game.LastFrameTime;

            if (evNow)
            {
                // l'elettrica consuma soprattutto in accelerazione: a gas
                // fermo scorre quasi gratis, col piede giu' beve il doppio
                fuel = fuel - meters * PCT_PER_METER_EV * (0.5f + 1.0f * accel);
            }
            else if (IsHybrid(v))
            {
                fuel = fuel - meters * PCT_PER_METER_HY * (0.75f + 0.5f * accel);
            }
            else
            {
                fuel = fuel - meters * PCT_PER_METER * (0.75f + 0.5f * accel);
            }

            UpdateOil(p, v, meters, evNow);
            UpdateOdo(v, meters);

            if (fuel <= 0f)
            {
                fuel = 0f;
                if (evNow)
                {
                    Notification.PostTicker("~r~" + L("Battery empty!", "Batteria scarica!") + "~s~ "
                        + L("Find a charging point.", "Raggiungi una colonnina."), false);
                }
                else
                {
                    Notification.PostTicker("~r~" + L("Out of fuel!", "Sei rimasto a secco!") + "~s~ "
                        + L("Find a gas station.", "Raggiungi un benzinaio."), false);
                }
            }
        }

        if (fuel <= 0f)
        {
            Function.Call(Hash.SET_VEHICLE_ENGINE_ON, v, false, true, true);
        }

        SetTank(curTankKey, fuel);
        UpdateRefuel(p, v);
    }

    void UpdateRefuel(Ped p, Vehicle v)
    {
        bool ev = evCurrent;
        float perPct = ev ? COST_PER_PCT_EV : COST_PER_PCT;
        float rate = ev ? CHARGE_PER_SEC : PUMP_PER_SEC;

        float speed = Function.Call<float>(Hash.GET_ENTITY_SPEED, v);

        // ---- rifornimento in corso ----
        // Si paga mano a mano che sale, non tutto in anticipo: se stacchi
        // a meta' hai pagato meta'.
        if (pumping)
        {
            if (speed > 0.5f || !NearStation(p))
            {
                pumping = false;
                Notification.PostTicker("~y~" + (ev ? L("Charging stopped", "Ricarica interrotta")
                                                   : L("Refuelling stopped", "Rifornimento interrotto")), false);
            }
            else
            {
                float add = rate * Game.LastFrameTime;
                if (fuel + add > 100f) add = 100f - fuel;

                pumpDebt = pumpDebt + add * perPct;
                int pay = (int)pumpDebt;
                if (pay > 0)
                {
                    int money = Game.Player.Money;
                    if (money < pay)
                    {
                        pumping = false;
                        Notification.PostTicker("~r~" + L("Out of money", "Soldi finiti"), false);
                        SetTank(curTankKey, fuel);
                        SaveTanks();
                        return;
                    }
                    Game.Player.Money = money - pay;
                    pumpDebt = pumpDebt - pay;
                }

                fuel = fuel + add;

                if (fuel >= 99.99f)
                {
                    fuel = 100f;
                    pumping = false;
                    Notification.PostTicker("~g~" + (ev ? L("Battery full", "Batteria carica")
                                                        : L("Tank full", "Pieno fatto")), false);
                    Function.Call(Hash.PLAY_SOUND_FRONTEND, -1, "PURCHASE",
                                  "HUD_LIQUOR_STORE_SOUNDSET", true);
                    SaveTanks();
                }

                SetTank(curTankKey, fuel);
                return;
            }
        }

        if (fuel >= 99.5f) return;
        if (speed > 0.5f) return;
        if (!NearStation(p)) return;

        int cost = (int)((100f - fuel) * perPct) + 1;
        int secs = (int)((100f - fuel) / rate) + 1;

        int now = Game.GameTime;
        if (now > fuelHelpAt + 4000)
        {
            fuelHelpAt = now;
            Notification.PostTicker("~b~E~s~ - "
                + (ev ? L("charge", "ricarica") : L("refuel", "fai benzina"))
                + " ($" + cost + ", " + secs + "s)", false);
        }

        if (Function.Call<bool>(Hash.IS_CONTROL_JUST_PRESSED, 0, 51))
        {
            if (Game.Player.Money <= 0)
            {
                Notification.PostTicker("~r~" + L("No money", "Non hai soldi"), false);
                return;
            }

            pumping = true;
            pumpDebt = 0f;
            Notification.PostTicker("~g~" + (ev ? L("Charging...", "In carica...")
                                                : L("Refuelling...", "Rifornimento..."))
                + "~s~ - " + L("stay parked", "resta fermo"), false);
        }
    }

    // sei fermo a un distributore? (le colonnine stanno li': stessa piazzola)
    bool NearStation(Ped p)
    {
        Vector3 pp = p.Position;
        int i;
        for (i = 0; i < GX.Length; i++)
        {
            float dx = pp.X - GX[i];
            float dy = pp.Y - GY[i];
            if (dx * dx + dy * dy < GAS_RADIUS * GAS_RADIUS) return true;
        }
        return false;
    }

    // ============================================================
    //  FAME E SETE
    // ============================================================
    int mkMade = 0;

    void MakeMarketBlips()
    {
        if (mkBlips != null) return;
        mkBlips = new int[MKX.Length];
        mkMade = 0;
    }

    void PumpMarketBlips()
    {
        if (mkBlips == null) return;
        if (mkMade >= MKX.Length) return;

        int made = 0;
        while (mkMade < MKX.Length && made < 2)
        {
            int i = mkMade;
            int b = Function.Call<int>(Hash.ADD_BLIP_FOR_COORD, MKX[i], MKY[i], MKZ[i]);
            Function.Call(Hash.SET_BLIP_SPRITE, b, 52);
            Function.Call(Hash.SET_BLIP_COLOUR, b, 0);
            Function.Call(Hash.SET_BLIP_SCALE, b, 0.65f);
            Function.Call(Hash.SET_BLIP_AS_SHORT_RANGE, b, true);
            mkBlips[i] = b;

            mkMade++;
            made++;
        }
    }


    void SaveBody()
    {
        try
        {
            Directory.CreateDirectory(DATA_DIR);
            string txt = "hunger=" + hunger.ToString("0.#", CultureInfo.InvariantCulture) + "\r\n"
                       + "thirst=" + thirst.ToString("0.#", CultureInfo.InvariantCulture) + "\r\n";
            File.WriteAllText(Path.Combine(DATA_DIR, "body.txt"), txt);
        }
        catch (Exception)
        {
        }
    }

    void LoadBody()
    {
        try
        {
            string f = Path.Combine(DATA_DIR, "body.txt");
            if (!File.Exists(f)) return;

            string[] l = File.ReadAllLines(f);
            int i;
            for (i = 0; i < l.Length; i++)
            {
                string[] kv = l[i].Split('=');
                if (kv.Length != 2) continue;
                float val;
                if (!float.TryParse(kv[1].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out val)) continue;
                if (kv[0].Trim() == "hunger") hunger = val;
                if (kv[0].Trim() == "thirst") thirst = val;
            }
        }
        catch (Exception)
        {
        }
    }






    int snackNext = 0;
    int lastHealth = -1;
    int lastMoney = -1;

    void Feed(float food, float drink, int nowS)
    {
        hunger = hunger + food;
        thirst = thirst + drink;
        if (hunger > 100f) hunger = 100f;
        if (thirst > 100f) thirst = 100f;

        lastMoney = Game.Player.Money;
        lastHealth = Game.Player.Character.Health;
        snackNext = nowS + 6000;

        SaveBody();
        Notification.PostTicker("~g~" + L("Fed", "Rifocillato"), false);
    }

    void CheckGameSnacks(Ped p)
    {
        int nowS = Game.GameTime;
        if (nowS < snackNext) return;
        snackNext = nowS + 250;

        // mangiare o bere fa salire la vita di colpo; la rigenerazione
        // naturale invece sale un punto alla volta
        int hp = p.Health;
        if (lastHealth < 0)
        {
            lastHealth = hp;
        }
        else
        {
            int jump = hp - lastHealth;
            lastHealth = hp;

            if (jump >= 8 && jump <= 80)   // sopra gli 80 e' una rinascita, non un panino
            {
                float gain = jump * 1.2f;
                if (gain > 60f) gain = 60f;
                Feed(gain, gain * 0.8f, nowS);
                return;
            }
        }

        // secondo segnale: con la vita gia' piena il cibo non cura, ma lo paghi.
        // Una spesa piccola a piedi e' quasi sempre un distributore o uno snack.
        int money = Game.Player.Money;
        if (lastMoney < 0)
        {
            lastMoney = money;
        }
        else
        {
            int spent = lastMoney - money;
            lastMoney = money;

            if (spent >= 1 && spent <= 25)
            {
                Feed(30f, 35f, nowS);
            }
        }
    }


    bool rechargeOff = false;

    void UpdateBody(Ped p)
    {
        int pidb = Function.Call<int>(Hash.PLAYER_ID);

        if (tBody == null || !tBody.On)
        {
            // sistema spento: ridai al gioco la sua rigenerazione
            if (rechargeOff)
            {
                Function.Call(Hash.SET_PLAYER_HEALTH_RECHARGE_MULTIPLIER, pidb, 1.0f);
                rechargeOff = false;
            }
            return;
        }

        // il gioco puo' curarti normalmente, ma solo fino al livello che
        // fame e sete consentono: cosi' le ferite guariscono e non c'e'
        // nessun tiro alla fune con la barra
        rechargeOff = true;
        float avgNow = (hunger + thirst) * 0.5f;
        if (avgNow < 0f) avgNow = 0f;
        if (avgNow > 100f) avgNow = 100f;

        // il gioco ricarica solo finche' sei sotto il tetto: sopra, la spengo.
        // Cosi' le ferite guariscono ma non oltre quello che la pancia consente.
        int maxH2 = Function.Call<int>(Hash.GET_ENTITY_MAX_HEALTH, p);
        int curH2 = Function.Call<int>(Hash.GET_ENTITY_HEALTH, p);
        int floorH2 = (maxH2 > 150) ? 100 : 0;
        float capNow = floorH2 + (maxH2 - floorH2) * (avgNow / 100f);

        Function.Call(Hash.SET_PLAYER_HEALTH_RECHARGE_MULTIPLIER, pidb,
                      curH2 < capNow ? 1.0f : 0.0f);

        int now = Game.GameTime;

        // consumo legato all'ORA DI GIOCO, sempre, 24 ore su 24
        int gh = Function.Call<int>(Hash.GET_CLOCK_HOURS);
        if (lastBodyHour < 0)
        {
            lastBodyHour = gh;
        }
        else if (gh != lastBodyHour)
        {
            lastBodyHour = gh;

            // in invincibilita' il corpo non consuma
            bool god = (tGod != null && tGod.On) || p.IsInvincible;
            if (god)
            {
                return;
            }

            hunger = hunger - 2.5f;
            thirst = thirst - 3.5f;
            if (hunger < 0f) hunger = 0f;
            if (thirst < 0f) thirst = 0f;

            if (hunger > 0f && hunger < 25f)
            {
                Notification.PostTicker("~o~" + L("You are hungry", "Hai fame"), false);
            }
            if (thirst > 0f && thirst < 25f)
            {
                Notification.PostTicker("~b~" + L("You are thirsty", "Hai sete"), false);
            }

            SaveBody();
        }

        // la vita segue di pari passo la media di fame e sete: al 70% di media
        // hai il 70% di vita. A zero muori. Cosi' il negozio ti vende da mangiare
        // anche quando sei solo un po' affamato.
        if (now > starveNext)
        {
            starveNext = now + 3000;

            bool god2 = (tGod != null && tGod.On) || p.IsInvincible;
            if (!god2)
            {
                float avg = (hunger + thirst) * 0.5f;
                if (avg < 0f) avg = 0f;
                if (avg > 100f) avg = 100f;

                // ATTENZIONE alla scala: per il giocatore la salute va da 100
                // (morto) a 200 (piena). Trattarla come 0-200 significava
                // ridurre a un filo di vita gia' a meta' fame.
                int maxH = Function.Call<int>(Hash.GET_ENTITY_MAX_HEALTH, p);
                int curH = Function.Call<int>(Hash.GET_ENTITY_HEALTH, p);
                int floorH = (maxH > 150) ? 100 : 0;

                float cap = floorH + (maxH - floorH) * (avg / 100f);

                if (curH > cap)
                {
                    Function.Call(Hash.SET_ENTITY_HEALTH, p, (int)cap);
                }
            }
        }

        if (p.IsInVehicle()) return;

        CheckGameSnacks(p);
    }



    // ============================================================
    //  AUTOVELOX
    //  140 in autostrada, 80 sulle altre strade, +10 di tolleranza.
    //  Se resti oltre la tolleranza per 10 secondi filati, multa.
    // ============================================================
    int SpeedLimitNow()
    {
        if (roadKind == 1) return tLimHwy != null ? tLimHwy.Val : 140;
        if (roadKind == 2) return tLimDirt != null ? tLimDirt.Val : 65;
        return tLimCity != null ? tLimCity.Val : 80;
    }

    string RoadLabel()
    {
        if (roadKind == 1) return L("highway", "autostrada");
        if (roadKind == 2) return L("dirt road", "sterrato");
        return L("town", "citta");
    }

    // ---------- contromano ----------

    void UpdateSpeedLimit(Ped p)
    {
        Vehicle v = p.CurrentVehicle;
        if (v == null || !v.Exists() || v.Driver == null || v.Driver.Handle != p.Handle)
        {
            overSince = -1f;
            return;
        }

        int now = Game.GameTime;

        // che strada e'? si controlla due volte al secondo, non ogni frame
        if (now > speedCheckNext)
        {
            speedCheckNext = now + 500;

            Vector3 pp = v.Position;
            OutputArgument sh = new OutputArgument();
            OutputArgument ch = new OutputArgument();
            Function.Call(Hash.GET_STREET_NAME_AT_COORD, pp.X, pp.Y, pp.Z, sh, ch);

            string street = Function.Call<string>(Hash.GET_STREET_NAME_FROM_HASH_KEY, sh.GetResult<int>());
            if (street == null) street = "";
            string low = street.ToLower();

            bool named = street.Length > 0 && low != "unknown";
            bool onRoad = Function.Call<bool>(Hash.IS_POINT_ON_ROAD, pp.X, pp.Y, pp.Z, v);

            if (low.Contains("freeway") || low.Contains("highway"))
            {
                roadKind = 1;
            }
            else if (!named && !onRoad)
            {
                // solo quando sei davvero fuori strada: niente nome della via
                // E nessuna carreggiata sotto. Bastava una delle due e in campagna
                // dava sterrato anche sull'asfalto.
                roadKind = 2;
            }
            else
            {
                roadKind = 0;
            }
        }

        // senza l'interruttore il cartello si vede lo stesso, ma non succede nulla
        if (tSpeedLimit == null || !tSpeedLimit.On)
        {
            overSince = -1f;
            return;
        }

        int kmh = (int)(Function.Call<float>(Hash.GET_ENTITY_SPEED, v) * 3.6f);
        int limit = SpeedLimitNow();

        // il bip parte a meta' strada verso la multa, non subito
        if (overSince >= 0f && now - overSince >= (OVER_SECONDS * 1000) / 2)
        {
            if (now > beepNext)
            {
                beepNext = now + 600;
                Function.Call(Hash.PLAY_SOUND_FRONTEND, -1, "Beep_Red",
                              "DLC_HEIST_HACKING_SNAKE_SOUNDS", true);
            }
        }

        if (kmh <= limit + SPEED_MARGIN)
        {
            overSince = -1f;
            return;
        }

        // oltre la tolleranza: parte il cronometro
        if (overSince < 0f)
        {
            overSince = now;
            return;
        }

        if (now - overSince < OVER_SECONDS * 1000) return;
        if (now < fineCooldown) return;

        // ---- limite superato troppo a lungo ----
        overSince = -1f;
        fineCooldown = now + 30000;

        OnSpeedingCaught(kmh, limit);
    }

    // QUI si decide cosa succede quando ti beccano: per ora solo un avviso.
    // Multa, polizia, punti patente... si aggiunge qui dentro.
    void OnSpeedingCaught(int kmh, int limit)
    {
        // multa: 100 in autostrada, 50 sulle altre strade
        int amount = (roadKind == 1) ? 100 : 50;

        int money = Game.Player.Money;
        if (money < amount) amount = money;
        Game.Player.Money = money - amount;

        Notification.PostTicker("~r~" + L("Speeding ticket", "Multa per eccesso")
            + "~s~  " + kmh + " / " + limit + " km/h  (" + RoadLabel() + ")   -$" + amount, false);
        Function.Call(Hash.PLAY_SOUND_FRONTEND, -1, "LOSER", "HUD_AWARDS", true);

        // oltre il 50% del limite: la polizia si accorge di te
        if (kmh >= limit + limit / 2)
        {
            int pid = Function.Call<int>(Hash.PLAYER_ID);
            if (Function.Call<int>(Hash.GET_PLAYER_WANTED_LEVEL, pid) < 1)
            {
                Function.Call(Hash.SET_PLAYER_WANTED_LEVEL, pid, 1, false);
                Function.Call(Hash.SET_PLAYER_WANTED_LEVEL_NOW, pid, false);
            }
            Notification.PostTicker("~r~" + L("Police alerted", "La polizia ti ha visto"), false);
        }
    }

    // eseguita a inizio tick, prima di disegnare qualsiasi cosa
    void ProcessPending()
    {
        if (pendingClear)
        {
            pendingClear = false;
            ClearArea();
            return;
        }

        if (pendingRemove < 0) return;

        int idx = pendingRemove;
        pendingRemove = -1;

        if (idx >= pvRaw.Count) return;

        // 1. l'icona si NASCONDE: REMOVE_BLIP fa crashare questo build del gioco
        if (idx < pvBlip.Count)
        {
            HideBlip(pvBlip[idx]);
            pvBlip.RemoveAt(idx);
        }

        // 2. via il veicolo dal mondo, se non ci sei dentro
        Vehicle wv = FindWorldVehicle(idx);
        Ped ped = Game.Player.Character;
        if (wv != null && wv.Exists() && (ped.CurrentVehicle == null || ped.CurrentVehicle.Handle != wv.Handle))
        {
            wv.IsPersistent = false;
            wv.Delete();
        }

        // 3. via la riga dal file
        pvRaw.RemoveAt(idx);
        if (trackedIdx == idx) trackedIdx = -1;
        else if (trackedIdx > idx) trackedIdx--;

        SaveMyVehicles();
        BuildMyVehicles();

        if (cur == mMyVeh)
        {
            menus[cur].Sel = FirstSelectable(cur);
            menus[cur].Top = 0;
        }

        Notification.PostTicker("~g~" + L("Removed", "Rimosso"), false);
    }

    // cancella i veicoli vuoti entro 60 metri: non tocca quello che guidi
    // ne' quelli con qualcuno a bordo
    void ClearArea()
    {
        Ped ped = Game.Player.Character;
        Vector3 me = ped.Position;
        int mine = (ped.CurrentVehicle != null) ? ped.CurrentVehicle.Handle : 0;

        Vehicle[] all = World.GetAllVehicles();
        int i;
        int killed = 0;

        for (i = 0; i < all.Length; i++)
        {
            Vehicle v = all[i];
            if (v == null || !v.Exists()) continue;
            if (v.Handle == mine) continue;
            if (v.IsSeatFree(VehicleSeat.Driver) == false) continue;

            Vector3 d = v.Position - me;
            if (d.Length() > 60f) continue;

            v.IsPersistent = false;
            v.Delete();
            killed++;
        }

        Notification.PostTicker("~g~" + killed + "~s~ " + L("vehicles removed", "veicoli rimossi"), false);
    }

    void RemoveDuplicates(int idx, Vehicle[] all, Vehicle keep)
    {
        if (keep == null || !keep.Exists()) return;

        int hash = PvHash(idx);
        string plate = PvPlate(idx);

        Ped ped = Game.Player.Character;
        int mine = (ped.CurrentVehicle != null) ? ped.CurrentVehicle.Handle : 0;

        int i;
        int killed = 0;
        for (i = 0; i < all.Length && killed < 4; i++)
        {
            Vehicle v = all[i];
            if (v == null || !v.Exists()) continue;
            if (v.Handle == keep.Handle) continue;
            if (v.Handle == mine) continue;
            if (v.Model.Hash != hash) continue;
            if (PlateOf(v) != plate) continue;

            v.IsPersistent = false;
            v.Delete();
            killed++;
        }
    }

    void LazyVehicles()
    {
        if (tPersist == null || !tPersist.On)
        {
            if (pvBlip.Count > 0) ClearBlips();
            return;
        }
        if (pvRaw.Count == 0)
        {
            if (pvBlip.Count > 0) ClearBlips();
            return;
        }

        int now = Game.GameTime;
        if (now < lazyNext) return;
        lazyNext = now + LAZY_INTERVAL;

        Ped ped = Game.Player.Character;
        if (ped == null || !ped.Exists()) return;
        Vector3 me = ped.Position;
        Vehicle[] all = World.GetAllVehicles();

        UpdateBlips(all);

        int i;
        for (i = 0; i < pvRaw.Count; i++)
        {
            Vector3 sp = new Vector3(PvFloat(i, 6), PvFloat(i, 7), PvFloat(i, 8));
            Vector3 d = sp - me;
            float dist = d.Length();

            Vehicle wv = FindWorldVehicle(i, all);

            // la distanza per la pulizia si misura sul veicolo VERO, non sul
            // punto salvato: teleportandoti col mezzo il punto salvato resta
            // lontano e prima lo cancellavo mentre ce l'avevi accanto
            if (wv != null && wv.Exists())
            {
                Vector3 dv = wv.Position - me;
                dist = dv.Length();
            }

            // se per qualsiasi motivo ne esistono piu' di uno con lo stesso
            // modello e la stessa targa, restano doppioni: se ne tiene uno solo
            RemoveDuplicates(i, all, wv);

            if (dist <= LAZY_RANGE)
            {
                if (wv == null)
                {
                    SpawnSaved(i, false);
                    trackedIdx = -1;
                    return;   // uno per volta, cosi' non blocca il frame
                }
            }
            else if (dist > CLEANUP_RANGE)
            {
                // non toccare quello che stai guidando
                if (wv != null && wv.Exists() && ped.CurrentVehicle != wv)
                {
                    wv.IsPersistent = false;
                    wv.Delete();
                }
            }
        }
    }

    Vehicle FindWorldVehicle(int idx)
    {
        return FindWorldVehicle(idx, World.GetAllVehicles());
    }

    Vehicle FindWorldVehicle(int idx, Vehicle[] all)
    {
        if (idx < 0 || idx >= pvRaw.Count) return null;
        if (all == null) return null;

        int hash = PvHash(idx);
        string plate = PvPlate(idx);

        int i;
        for (i = 0; i < all.Length; i++)
        {
            Vehicle v = all[i];
            if (v == null || !v.Exists()) continue;
            if (v.Model.Hash != hash) continue;
            if (PlateOf(v) != plate) continue;
            return v;
        }
        return null;
    }

    void SpawnSaved(int idx, bool atPlayer)
    {
        if (idx < 0 || idx >= pvRaw.Count) return;

        int hash = PvHash(idx);
        if (!Function.Call<bool>(Hash.IS_MODEL_IN_CDIMAGE, hash) || !Function.Call<bool>(Hash.IS_MODEL_A_VEHICLE, hash))
        {
            Notification.PostTicker("~r~" + L("Invalid model", "Modello non valido") + ":~s~ "
                + PvField(idx, 10), false);
            return;
        }

        Ped ped = Game.Player.Character;

        // se il veicolo esiste gia' nel mondo lo si sposta, non se ne crea un altro
        Vehicle exist = FindWorldVehicle(idx);
        if (exist != null)
        {
            if (atPlayer)
            {
                Vector3 dst = ped.Position + ped.ForwardVector * 5.0f;
                exist.Position = dst;
                exist.Heading = ped.Heading + 90f;
                Function.Call(Hash.SET_VEHICLE_ON_GROUND_PROPERLY, exist);
                Notification.PostTicker("~g~" + PvField(idx, 10), false);
            }
            exist.IsPersistent = true;
            trackedIdx = idx;
            return;
        }

        Model m = new Model(hash);
        m.Request();
        int waited = 0;
        while (!m.IsLoaded && waited < 4000)
        {
            Script.Wait(50);
            waited += 50;
        }
        if (!m.IsLoaded) return;

        Vector3 pos;
        float head;
        if (atPlayer)
        {
            pos = ped.Position + ped.ForwardVector * 5.0f;
            head = ped.Heading + 90f;
        }
        else
        {
            pos = new Vector3(PvFloat(idx, 6), PvFloat(idx, 7), PvFloat(idx, 8));
            head = PvFloat(idx, 9);
        }

        Vehicle v = World.CreateVehicle(m, pos, head);
        m.MarkAsNoLongerNeeded();
        if (v == null || !v.Exists()) return;

        Function.Call(Hash.SET_VEHICLE_MOD_KIT, v, 0);
        Function.Call(Hash.SET_VEHICLE_COLOURS, v, SafeColor(PvInt(idx, 2)), SafeColor(PvInt(idx, 3)));
        Function.Call(Hash.SET_VEHICLE_EXTRA_COLOURS, v, SafeColor(PvInt(idx, 4)), SafeColor(PvInt(idx, 5)));
        Function.Call(Hash.SET_VEHICLE_NUMBER_PLATE_TEXT, v, PvPlate(idx));
        ApplyMods(v, PvField(idx, 11));
        Function.Call(Hash.SET_VEHICLE_ON_GROUND_PROPERLY, v);
        v.IsPersistent = true;

        trackedIdx = idx;

        if (atPlayer)
        {
            Notification.PostTicker("~g~" + PvField(idx, 10), false);
        }
    }

    Vehicle TargetVehicle()
    {
        Ped ped = Game.Player.Character;
        Vehicle v = ped.CurrentVehicle;
        if (v != null && v.Exists())
        {
            return v;
        }

        Vehicle near = World.GetClosestVehicle(ped.Position, 12f);
        if (near != null && near.Exists())
        {
            return near;
        }
        return null;
    }

    static readonly string[] WEATHER_ID = new string[] {
        "EXTRASUNNY", "CLEAR", "CLOUDS", "SMOG", "FOGGY", "OVERCAST",
        "RAIN", "THUNDER", "CLEARING", "NEUTRAL", "SNOW", "BLIZZARD",
        "SNOWLIGHT", "XMAS", "HALLOWEEN"
    };

    // ---------- luoghi ----------
    static readonly string[] KNOWN = new string[] {
        "Casa di Michael|-813.0|179.0|72.2",
        "Casa di Franklin|7.9|539.0|176.0",
        "Roulotte di Trevor|1985.7|3812.2|32.2",
        "Aeroporto LS|-1037.0|-2737.0|20.2",
        "Sandy Shores|1961.0|3740.0|32.3",
        "Paleto Bay|-275.0|6635.0|7.4",
        "Monte Chiliad|501.5|5604.5|797.9",
        "Scritta Vinewood|711.0|1198.0|348.0",
        "Tetto Maze Bank|-75.0|-818.0|326.0",
        "Molo Del Perro|-1850.0|-1231.0|13.0",
        "Carcere|1845.0|2585.0|45.0",
        "Casino|925.0|46.0|80.9",
        "Porto|850.0|-3000.0|5.9",
        "Base militare|-2050.0|3200.0|32.8"
    };

    void BuildKnownPlaces(int menu)
    {
        int i;
        for (i = 0; i < KNOWN.Length; i++)
        {
            string[] f = KNOWN[i].Split('|');
            TItem it = AddAction(menu, f[0], f[0], 306);
            it.Data = f[1] + "|" + f[2] + "|" + f[3];
        }
    }

    string PlacesFile()
    {
        return Path.Combine(DATA_DIR, "places.txt");
    }

    void LoadPlaces()
    {
        placeRaw.Clear();
        try
        {
            if (!File.Exists(PlacesFile())) return;
            string[] l = File.ReadAllLines(PlacesFile());
            int i;
            for (i = 0; i < l.Length; i++)
            {
                string row = l[i].Trim();
                if (row.Length == 0 || row.StartsWith("#")) continue;
                if (row.Split('|').Length < 4) continue;
                placeRaw.Add(row);
            }
        }
        catch (Exception)
        {
        }
    }

    void SavePlaces()
    {
        try
        {
            Directory.CreateDirectory(DATA_DIR);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("# I MIEI PUNTI - nome|x|y|z");
            int i;
            for (i = 0; i < placeRaw.Count; i++) sb.AppendLine(placeRaw[i]);
            File.WriteAllText(PlacesFile(), sb.ToString());
        }
        catch (Exception)
        {
        }
    }

    void BuildPlaces()
    {
        if (mPlaces < 0) return;

        menus[mPlaces].Items.Clear();
        menus[mPlaces].Sel = 0;
        menus[mPlaces].Top = 0;

        int i;
        for (i = 0; i < placeRaw.Count; i++)
        {
            string[] f = placeRaw[i].Split('|');
            TItem it = AddAction(mPlaces, f[0], f[0], 304);
            it.Data = f[1] + "|" + f[2] + "|" + f[3];

            TItem rm = AddAction(mPlaces, "   " + L("remove", "rimuovi"), "   " + L("remove", "rimuovi"), 305);
            rm.Data = i.ToString();
        }
    }

    void AutoTeleport()
    {
        if (tAutoTp == null || tAutoTp.Sel == 0) return;

        int now = Game.GameTime;
        if (now < autoTpNext) return;
        autoTpNext = now + 1000;

        Vector3 dest = Vector3.Zero;

        if (tAutoTp.Sel == 1)
        {
            int b = Function.Call<int>(Hash.GET_FIRST_BLIP_INFO_ID, 8);
            if (!Function.Call<bool>(Hash.DOES_BLIP_EXIST, b))
            {
                lastAutoTp = Vector3.Zero;   // waypoint tolto: pronto per il prossimo
                return;
            }
            dest = Function.Call<Vector3>(Hash.GET_BLIP_INFO_ID_COORD, b);
        }
        else
        {
            dest = FindObjectiveBlip();
            if (dest.X == 0f && dest.Y == 0f) return;
        }

        // gia' fatto per questo punto? non insistere
        Vector3 d = dest - lastAutoTp;
        if (d.Length() < 5f) return;

        lastAutoTp = dest;
        autoTpNext = now + 4000;
        TeleportTo(dest);
    }

    // Velocita' del tempo: di serie GTA fa passare un minuto di gioco ogni
    // 2 secondi reali. Fermiamo il suo orologio e lo avanziamo noi al ritmo
    // scelto, come faceva la mod vecchia.
    void UpdateClockSpeed()
    {
        int sel = (tTimeSpeed != null) ? tTimeSpeed.Sel : 0;

        if (sel == 0)
        {
            if (clockTaken)
            {
                Function.Call(Hash.PAUSE_CLOCK, false);
                clockTaken = false;
            }
            return;
        }

        int msPerMin = 2000;
        if (sel == 1) msPerMin = 4000;
        else if (sel == 2) msPerMin = 8000;
        else if (sel == 3) msPerMin = 16000;

        if (!clockTaken)
        {
            Function.Call(Hash.PAUSE_CLOCK, true);
            clockTaken = true;
            nextGameMin = Game.GameTime + msPerMin;
            return;
        }

        // dopo una pausa lunga non si recupera il tempo perso
        if (Game.GameTime - nextGameMin > 10000)
        {
            nextGameMin = Game.GameTime + msPerMin;
            return;
        }

        while (Game.GameTime >= nextGameMin)
        {
            Function.Call(Hash.ADD_TO_CLOCK_TIME, 0, 1, 0);
            nextGameMin = nextGameMin + msPerMin;
        }
    }

    void SetWeather(int idx)
    {
        if (idx < 0 || idx >= WEATHER_ID.Length) return;
        Function.Call(Hash.SET_WEATHER_TYPE_NOW_PERSIST, WEATHER_ID[idx]);
        Function.Call(Hash.SET_WEATHER_TYPE_PERSIST, WEATHER_ID[idx]);
    }

    void SetClock(int h, int m)
    {
        if (h < 0) h = 0;
        if (h > 23) h = 23;
        if (m < 0) m = 0;
        if (m > 59) m = 59;
        Function.Call(Hash.NETWORK_OVERRIDE_CLOCK_TIME, h, m, 0);
    }

    const int MAX_COLOR = 255;   // rete di sicurezza contro valori corrotti nel file, non un limite alle tinte

    int SafeColor(int c)
    {
        if (c < 0) return 0;
        if (c > MAX_COLOR) return 0;
        return c;
    }

    void ApplyPaint(int slot, int colorIdx)
    {
        colorIdx = SafeColor(colorIdx);
        Vehicle v = TargetVehicle();
        if (v == null || !v.Exists())
        {
            Notification.PostTicker("~y~" + L("Not in a vehicle", "Non sei in un veicolo"), false);
            return;
        }

        OutputArgument a1 = new OutputArgument();
        OutputArgument a2 = new OutputArgument();
        Function.Call(Hash.GET_VEHICLE_COLOURS, v, a1, a2);
        int prim = a1.GetResult<int>();
        int sec = a2.GetResult<int>();

        OutputArgument b1 = new OutputArgument();
        OutputArgument b2 = new OutputArgument();
        Function.Call(Hash.GET_VEHICLE_EXTRA_COLOURS, v, b1, b2);
        int pearl = b1.GetResult<int>();
        int wheel = b2.GetResult<int>();

        if (slot == 0) prim = colorIdx;
        if (slot == 1) sec = colorIdx;
        if (slot == 2) pearl = colorIdx;
        if (slot == 3) wheel = colorIdx;

        Function.Call(Hash.SET_VEHICLE_MOD_KIT, v, 0);
        Function.Call(Hash.SET_VEHICLE_COLOURS, v, SafeColor(prim), SafeColor(sec));
        Function.Call(Hash.SET_VEHICLE_EXTRA_COLOURS, v, SafeColor(pearl), SafeColor(wheel));

        TouchSaved(v);   // se e' un veicolo salvato, memorizza subito la nuova vernice
    }

    string VehLabel(int hash, string fallback)
    {
        string lbl = Function.Call<string>(Hash.GET_DISPLAY_NAME_FROM_VEHICLE_MODEL, hash);
        string nice = Game.GetLocalizedString(lbl);
        if (nice == null || nice.Length == 0 || nice == "NULL")
        {
            nice = fallback;
        }
        return nice;
    }

    void BuildVehicleClasses()
    {
        vehBuilt = true;

        string file = DATA_DIR + "\\vehicles.txt";
        if (!File.Exists(file))
        {
            Notification.PostTicker("~r~vehicles.txt " + L("not found", "non trovato"), false);
            return;
        }

        int[] classMenu = new int[VCLASS.Length];
        int i;
        for (i = 0; i < classMenu.Length; i++)
        {
            classMenu[i] = -1;
        }

        // tutte le categorie stanno dentro una sola voce "Spawna veicolo"
        int mSpawn = NewMenu("SPAWN VEHICLE", "SPAWNA VEICOLO", mVehicles);

        // ---- ADD-ONS: MARCA > CATEGORIA > MODELLO ----
        List<string> addonName = new List<string>();
        List<string> addonLabel = new List<string>();
        List<int> addonClass = new List<int>();
        List<string> addonClassText = new List<string>();

        int mAddons = -1;
        List<string> brandKey = new List<string>();
        List<int> brandMenu = new List<int>();
        List<string> bcKey = new List<string>();
        List<int> bcMenu = new List<int>();
        List<string> customName = new List<string>();
        List<int> customMenu = new List<int>();

        string addFile = DATA_DIR + "\\addons.txt";
        if (File.Exists(addFile))
        {
            string[] al = File.ReadAllLines(addFile);
            int k;
            for (k = 0; k < al.Length; k++)
            {
                string row = al[k].Trim();
                if (row.Length == 0 || row.StartsWith("#")) continue;

                // formato:  modello | Marca | Nome | Categoria
                string[] f = row.Split('|');
                int fi;
                for (fi = 0; fi < f.Length; fi++)
                {
                    f[fi] = f[fi].Trim();
                }

                string an = f[0];
                if (an.Length == 0) continue;

                string brand = "";
                string mname = "";
                string ctext = "";

                if (f.Length == 2)
                {
                    mname = f[1];
                }
                else if (f.Length == 3)
                {
                    mname = f[1];
                    ctext = f[2];
                }
                else if (f.Length >= 4)
                {
                    brand = f[1];
                    mname = f[2];
                    ctext = f[3];
                }

                int ah = Function.Call<int>(Hash.GET_HASH_KEY, an);
                if (!Function.Call<bool>(Hash.IS_MODEL_IN_CDIMAGE, ah)) continue;
                if (!Function.Call<bool>(Hash.IS_MODEL_A_VEHICLE, ah)) continue;

                if (mname.Length == 0)
                {
                    mname = VehLabel(ah, an);
                }

                // etichetta completa per le classi generali
                string full = brand.Length > 0 ? brand + " " + mname : mname;

                if (mAddons < 0)
                {
                    mAddons = NewMenu("ADD-ONS", "ADD-ONS", mSpawn);
                    TItem sa = AddSub(mSpawn, "Add-ons", "Add-ons", mAddons);
                    sa.Cr = PASTEL[0, 0]; sa.Cg = PASTEL[0, 1]; sa.Cb = PASTEL[0, 2];
                    sa.Tinted = true;
                }

                // livello 1: la marca
                string bshow = brand.Length > 0 ? brand : L("Other", "Altro");
                string bk = bshow.ToLower();
                int bi = brandKey.IndexOf(bk);
                if (bi < 0)
                {
                    int bm = NewMenu(bshow.ToUpper(), bshow.ToUpper(), mAddons);
                    TItem bs = AddSub(mAddons, bshow, bshow, bm);
                    int bc = brandKey.Count % (PASTEL.Length / 3);
                    bs.Cr = PASTEL[bc, 0]; bs.Cg = PASTEL[bc, 1]; bs.Cb = PASTEL[bc, 2];
                    bs.Tinted = true;

                    brandKey.Add(bk);
                    brandMenu.Add(bm);
                    bi = brandKey.Count - 1;
                }

                // livello 2: la categoria dentro la marca
                int cidx = ClassFromText(ctext);
                string cshow = ctext.Length > 0 ? ctext : L("Other", "Altro");
                if (cidx >= 0)
                {
                    cshow = lang == 1 ? VCLASS_IT[cidx] : VCLASS[cidx];
                }

                string ck = bk + ">" + cshow.ToLower();
                int ci = bcKey.IndexOf(ck);
                if (ci < 0)
                {
                    int cm = NewMenu(cshow.ToUpper(), cshow.ToUpper(), brandMenu[bi]);
                    AddSub(brandMenu[bi], cshow, cshow, cm);
                    bcKey.Add(ck);
                    bcMenu.Add(cm);
                    ci = bcKey.Count - 1;
                }

                // livello 3: il modello
                TItem ai = AddAction(bcMenu[ci], mname, mname, 210);
                ai.Data = an;

                addonName.Add(an);
                addonLabel.Add(full);
                addonClass.Add(cidx);
                addonClassText.Add(ctext);
            }
        }

        string[] lines = File.ReadAllLines(file);

        // PASSATA 1: quali classi esistono davvero
        bool[] hasClass = new bool[VCLASS.Length];
        for (i = 0; i < lines.Length; i++)
        {
            string nm0 = lines[i].Trim();
            if (nm0.Length == 0 || nm0.StartsWith("#")) continue;

            int h0 = Function.Call<int>(Hash.GET_HASH_KEY, nm0);
            if (!Function.Call<bool>(Hash.IS_MODEL_IN_CDIMAGE, h0)) continue;
            if (!Function.Call<bool>(Hash.IS_MODEL_A_VEHICLE, h0)) continue;

            int c0 = Function.Call<int>(Hash.GET_VEHICLE_CLASS_FROM_NAME, h0);
            if (c0 < 0 || c0 >= VCLASS.Length) c0 = 0;
            hasClass[c0] = true;
        }

        // gli add-on possono aggiungere classi che i veicoli base non usano
        int ap;
        for (ap = 0; ap < addonClass.Count; ap++)
        {
            int ac0 = addonClass[ap];
            if (ac0 >= 0 && ac0 < VCLASS.Length) hasClass[ac0] = true;
        }

        // ---- ELETTRICI: una categoria propria, in cima ----
        // Lista nostra (vedi ELECTRIC): la proprieta' del gioco non funziona
        // in questa build. I modelli restano anche nella loro classe.
        int mEv = NewMenu("ELECTRIC", "ELETTRICI", mSpawn);
        TItem evSub = AddSub(mSpawn, "Electric", "Elettrici", mEv);
        evSub.Cr = PASTEL[2, 0]; evSub.Cg = PASTEL[2, 1]; evSub.Cb = PASTEL[2, 2];
        evSub.Tinted = true;

        int ev;
        int evFound = 0;
        for (ev = 0; ev < ELECTRIC.Length; ev++)
        {
            string en = ELECTRIC[ev];
            int eh = Function.Call<int>(Hash.GET_HASH_KEY, en);
            if (!Function.Call<bool>(Hash.IS_MODEL_IN_CDIMAGE, eh)) continue;
            if (!Function.Call<bool>(Hash.IS_MODEL_A_VEHICLE, eh)) continue;

            TItem eit = AddAction(mEv, VehLabel(eh, en), 210);
            eit.Data = en;
            evFound++;
        }

        if (evFound == 0)
        {
            AddHeader(mEv, "- NONE FOUND -", "- NESSUNO TROVATO -", 0);
        }

        // crea i sottomenu nell'ordine ufficiale delle classi
        for (i = 0; i < VCLASS.Length; i++)
        {
            if (!hasClass[i]) continue;

            classMenu[i] = NewMenu(VCLASS[i].ToUpper(), VCLASS_IT[i].ToUpper(), mSpawn);
            TItem cs = AddSub(mSpawn, VCLASS[i], VCLASS_IT[i], classMenu[i]);
            int cg = CCOLOR[i];
            cs.Cr = PASTEL[cg, 0]; cs.Cg = PASTEL[cg, 1]; cs.Cb = PASTEL[cg, 2];
            cs.Tinted = true;
        }

        // PASSATA 2: i veicoli dentro la loro classe
        int found = 0;
        for (i = 0; i < lines.Length; i++)
        {
            string name = lines[i].Trim();
            if (name.Length == 0 || name.StartsWith("#"))
            {
                continue;
            }

            int hash = Function.Call<int>(Hash.GET_HASH_KEY, name);
            if (!Function.Call<bool>(Hash.IS_MODEL_IN_CDIMAGE, hash))
            {
                continue;
            }
            if (!Function.Call<bool>(Hash.IS_MODEL_A_VEHICLE, hash))
            {
                continue;
            }

            int cls = Function.Call<int>(Hash.GET_VEHICLE_CLASS_FROM_NAME, hash);
            if (cls < 0 || cls >= VCLASS.Length)
            {
                cls = 0;
            }

            if (classMenu[cls] < 0) continue;

            string nice = VehLabel(hash, name);

            TItem it = AddAction(classMenu[cls], nice, 210);
            it.Data = name;
            found++;
        }

        // ---- add-on anche dentro la loro classe ----
        int ax;
        for (ax = 0; ax < addonName.Count; ax++)
        {
            int acl = addonClass[ax];

            // categoria personalizzata (es. "Audi", "BMW"): creata al volo
            if (acl < 0)
            {
                string ct = addonClassText[ax];
                if (ct.Length == 0)
                {
                    continue;
                }

                int ck = customName.IndexOf(ct.ToLower());
                if (ck < 0)
                {
                    int nm = NewMenu(ct.ToUpper(), ct.ToUpper(), mSpawn);
                    TItem sc = AddSub(mSpawn, ct, ct, nm);
                    int cc = (customName.Count + 2) % (PASTEL.Length / 3);
                    sc.Cr = PASTEL[cc, 0]; sc.Cg = PASTEL[cc, 1]; sc.Cb = PASTEL[cc, 2];
                    sc.Tinted = true;

                    customName.Add(ct.ToLower());
                    customMenu.Add(nm);
                    ck = customName.Count - 1;
                }

                TItem cit = AddAction(customMenu[ck], addonLabel[ax], addonLabel[ax], 210);
                cit.Data = addonName[ax];
                continue;
            }

            if (acl >= VCLASS.Length)
            {
                continue;
            }

            if (classMenu[acl] < 0) continue;

            TItem ci3 = AddAction(classMenu[acl], addonLabel[ax], addonLabel[ax], 210);
            ci3.Data = addonName[ax];
        }

        // ---- sezione azioni, sotto alle classi ----
        AddHeader(mVehicles, "- SPAWN -", "- SPAWN -", 0);
        TItem sv = AddSub(mVehicles, "Spawn vehicle", "Spawna veicolo", mSpawn);
        sv.Cr = PASTEL[1, 0]; sv.Cg = PASTEL[1, 1]; sv.Cb = PASTEL[1, 2];
        sv.Tinted = true;
        AddAction(mVehicles, "Spawn by name...", "Spawn per nome...", 200);
        AddSub(mVehicles, "Spawn options", "Opzioni spawn", mSpawnOpts);

        AddHeader(mVehicles, "- CURRENT VEHICLE -", "- VEICOLO ATTUALE -", 3);
        AddAction(mVehicles, "Repair", "Ripara", 205);
        AddAction(mVehicles, "Clean", "Pulisci", 206);
        AddAction(mVehicles, "Delete", "Elimina", 204);
        AddAction(mVehicles, "Clear area", "Pulisci l'area", 211);
        AddAction(mVehicles, "Flip upright", "Rimettila dritta", 212);
        AddAction(mVehicles, "Engine on/off", "Motore acceso/spento", 213);
        AddAction(mVehicles, "Open all doors", "Apri tutte le porte", 214);
        AddAction(mVehicles, "Close all doors", "Chiudi tutte le porte", 215);
        AddAction(mVehicles, "Lock / unlock", "Blocca / sblocca", 216);
        AddAction(mVehicles, "Set plate...", "Cambia targa...", 217);
        tVehGod  = AddList(mVehicles, "Invincible", "Invincibile", 207,
                           new string[] { "Off", "Engine", "Body", "Full" }, 0);
        tOnWater = AddToggle(mVehicles, "Drive on water", "Guida sull'acqua", 208, false);
        AddAction(mVehicles, "Service", "Tagliando", 268);
        AddAction(mVehicles, "Refuel / recharge", "Fai il pieno / ricarica", 270);
        tLimiter = AddToggle(mVehicles, "Speed limiter", "Limitatore di velocita'", 219, false);
        tUnits   = AddList(mVehicles, "Units", "Unita' di misura", 269,
                           new string[] { "km/h", "mph" }, 0);
        tMass    = AddList(mVehicles, "Mass multiplier", "Moltiplicatore massa", 218,
                           new string[] {
                               "x1", "x1.5", "x2", "x2.5", "x3", "x3.5", "x4", "x4.5",
                               "x5", "x5.5", "x6", "x6.5", "x7", "x7.5", "x8", "x8.5",
                               "x9", "x9.5", "x10", "x20", "x30", "x40", "x50", "x60",
                               "x70", "x80", "x90", "x100", "x200", "x300", "x400",
                               "x500", "x600", "x700", "x800", "x900", "x1000", "x2000",
                               "x3000", "x4000", "x5000", "x6000", "x7000", "x8000",
                               "x9000", "x10000", "x100000" }, 0);

        AddHeader(mVehicles, "- MY VEHICLES -", "- I MIEI VEICOLI -", 2);
        tPersist = AddToggle(mVehicles, "Persistent", "Persistenti", 209, false);
        tBlips   = AddToggle(mVehicles, "Map blips", "Blip sulla mappa", 250, true);

        mMyVeh = NewMenu("MY VEHICLES", "I MIEI VEICOLI", mVehicles);
        AddSub(mVehicles, "My vehicles", "I miei veicoli", mMyVeh);
        LoadMyVehicles();
        BuildMyVehicles();

        mModShop = NewMenu("MOD SHOP", "OFFICINA", mVehicles);
        TItem ms = AddSub(mVehicles, "Mod shop", "Officina", mModShop);
        ms.Id = 240;   // ricostruisce il menu sul veicolo attuale prima di entrare

        // i sottomenu si creano una volta sola e si svuotano a ogni riapertura
        mBody   = NewMenu("BODYWORK", "CARROZZERIA", mModShop);
        mMech   = NewMenu("MECHANICS", "MECCANICA", mModShop);
        mWheels = NewMenu("WHEELS", "RUOTE", mModShop);
        mLights = NewMenu("LIGHTS & OTHER", "LUCI E ALTRO", mModShop);
        mExtras = NewMenu("EXTRAS", "EXTRA", mModShop);

        int mPaint = NewMenu("PAINT", "VERNICE", mVehicles);
        AddSub(mVehicles, "Paint", "Vernice", mPaint);
        BuildPaintMenus(mPaint);

        menus[mVehicles].Sel = FirstSelectable(mVehicles);

        // le voci create qui (Invincibile, Guida sull'acqua, ...) esistono solo ora:
        // ricarico la config perche' prendano il loro stato salvato
        LoadConfig();

        // benzinai e market: icone fisse, create una volta sola e mai piu' toccate
        MakeGasBlips();
        MakeMarketBlips();

        LoadTanks();
        LoadOil();
        LoadOdo();
        LoadBody();
        if (tFreezeWeather != null && tFreezeWeather.On && tWeather != null)
        {
            SetWeather(tWeather.Sel);
        }

        Notification.PostTicker("~g~" + found + "~s~ " + L("vehicles loaded", "veicoli caricati"), false);
    }

    // ============================================================
    //  QUI SI SCRIVE COSA FA OGNI VOCE
    // ============================================================
    void DoAction(TItem it)
    {
        Ped p = Game.Player.Character;
        int pid = Function.Call<int>(Hash.PLAYER_ID);

        switch (it.Id)
        {
            case 100:
                p.Health = p.MaxHealth;
                Function.Call(Hash.SET_PED_ARMOUR, p, Function.Call<int>(Hash.GET_PLAYER_MAX_ARMOUR, pid));
                Notification.PostTicker("~g~" + L("Healed", "Curato"), false);
                break;

            case 101:
                Function.Call(Hash.SET_PED_ARMOUR, p, Function.Call<int>(Hash.GET_PLAYER_MAX_ARMOUR, pid));
                Notification.PostTicker("~g~" + L("Full armour", "Armatura piena"), false);
                break;

            case 110:
                {
                    int[] amounts = new int[] { -100000, -10000, -1000, -100, -10,
                                                 0,
                                                 10, 100, 1000, 10000, 100000 };
                    int amt = amounts[it.Sel];
                    if (amt == 0)
                    {
                        break;
                    }
                    int money = Game.Player.Money + amt;
                    if (money < 0) money = 0;
                    Game.Player.Money = money;

                    string sign = amt < 0 ? "~r~-$" : "~g~+$";
                    int abs = amt < 0 ? -amt : amt;
                    Notification.PostTicker(sign + abs.ToString("N0", CultureInfo.InvariantCulture), false);
                }
                break;

            case 212:
                {
                    Vehicle v = TargetVehicle();
                    if (v != null && v.Exists())
                    {
                        Function.Call(Hash.SET_VEHICLE_ON_GROUND_PROPERLY, v);
                    }
                }
                break;

            case 213:
                {
                    Vehicle v = TargetVehicle();
                    if (v != null && v.Exists())
                    {
                        bool on = Function.Call<bool>(Hash.GET_IS_VEHICLE_ENGINE_RUNNING, v);
                        Function.Call(Hash.SET_VEHICLE_ENGINE_ON, v, !on, true, true);
                    }
                }
                break;

            case 214:
            case 215:
                {
                    Vehicle v = TargetVehicle();
                    if (v != null && v.Exists())
                    {
                        int d;
                        for (d = 0; d <= 5; d++)
                        {
                            if (it.Id == 214) Function.Call(Hash.SET_VEHICLE_DOOR_OPEN, v, d, false, false);
                            else Function.Call(Hash.SET_VEHICLE_DOOR_SHUT, v, d, false);
                        }
                    }
                }
                break;

            case 216:
                {
                    Vehicle v = TargetVehicle();
                    if (v != null && v.Exists())
                    {
                        int st = Function.Call<int>(Hash.GET_VEHICLE_DOOR_LOCK_STATUS, v);
                        int newSt = (st == 2) ? 1 : 2;
                        Function.Call(Hash.SET_VEHICLE_DOORS_LOCKED, v, newSt);
                        Notification.PostTicker(newSt == 2
                            ? "~g~" + L("Locked", "Bloccato")
                            : "~g~" + L("Unlocked", "Sbloccato"), false);
                    }
                }
                break;

            case 903:
                radioNext = 0;
                ApplyRadio(Game.Player.Character.CurrentVehicle);
                break;

            case 904:
                ApplyMobileRadio();
                Notification.PostTicker((it.On ? "~g~" : "~y~")
                    + L("Radio on foot", "Radio a piedi") + "~s~ "
                    + (it.On ? L("on", "accesa") : L("off", "spenta")), false);
                break;

            case 270:
                {
                    Vehicle v = p.CurrentVehicle;
                    if (v == null || !v.Exists())
                    {
                        Notification.PostTicker("~y~" + L("Get in a vehicle first", "Sali su un veicolo"), false);
                        break;
                    }
                    if (fuel >= 99.5f)
                    {
                        Notification.PostTicker("~y~" + (evCurrent
                            ? L("Battery already full", "Batteria gia' carica")
                            : L("Tank already full", "Serbatoio gia' pieno")), false);
                        break;
                    }

                    float perPct = evCurrent ? COST_PER_PCT_EV : COST_PER_PCT;
                    int cost = (int)((100f - fuel) * perPct) + 1;

                    if (Game.Player.Money < cost)
                    {
                        Notification.PostTicker("~r~" + L("Not enough money", "Soldi insufficienti")
                            + " ($" + cost + ")", false);
                        break;
                    }

                    Game.Player.Money = Game.Player.Money - cost;
                    fuel = 100f;
                    SetTank(curTankKey, fuel);
                    SaveTanks();

                    Function.Call(Hash.PLAY_SOUND_FRONTEND, -1, "PURCHASE",
                                  "HUD_LIQUOR_STORE_SOUNDSET", true);
                    Notification.PostTicker("~g~" + (evCurrent
                        ? L("Battery full", "Batteria carica")
                        : L("Tank full", "Pieno fatto")) + "~s~ -$" + cost, false);
                }
                break;

            case 268:
                {
                    Vehicle v = p.CurrentVehicle;
                    if (v == null || !v.Exists())
                    {
                        Notification.PostTicker("~y~" + L("Get in a vehicle first", "Sali su un veicolo"), false);
                        break;
                    }
                    if (oil > 95f)
                    {
                        Notification.PostTicker("~y~" + L("Oil is still good", "L'olio e' ancora buono"), false);
                        break;
                    }
                    if (Game.Player.Money < OIL_SERVICE_COST)
                    {
                        Notification.PostTicker("~r~" + L("Not enough money", "Soldi insufficienti")
                            + " ($" + OIL_SERVICE_COST + ")", false);
                        break;
                    }

                    Game.Player.Money = Game.Player.Money - OIL_SERVICE_COST;

                    // il tagliando azzera il contachilometri del servizio
                    curOilKey = TankKeyOf(v);
                    servM = odoM;
                    oil = 100f;
                    SetOil(curOilKey, servM);
                    SaveOil();

                    // col tagliando il motore torna a posto e riprende potenza
                    Function.Call(Hash.SET_VEHICLE_ENGINE_HEALTH, v, 1000f);
                    Function.Call(Hash.MODIFY_VEHICLE_TOP_SPEED, v, 1f);
                    oilSlowVeh = 0;
                    Function.Call(Hash.PLAY_SOUND_FRONTEND, -1, "PURCHASE",
                                  "HUD_LIQUOR_STORE_SOUNDSET", true);
                    Notification.PostTicker("~g~" + L("Service done", "Tagliando fatto")
                        + "~s~ -$" + OIL_SERVICE_COST, false);
                }
                break;

            case 219:
                {
                    Vehicle v = Game.Player.Character.CurrentVehicle;
                    if (!it.On && v != null && v.Exists())
                    {
                        Function.Call(Hash.SET_ENTITY_MAX_SPEED, v, 500f);
                        limiterVeh = 0;
                    }
                    Notification.PostTicker((it.On ? "~g~" : "~y~")
                        + L("Speed limiter", "Limitatore") + "~s~ "
                        + (it.On ? L("on", "acceso") : L("off", "spento")), false);
                }
                break;

            case 218:
                {
                    Vehicle v = Game.Player.Character.CurrentVehicle;
                    if (v != null && v.Exists())
                    {
                        ApplyMass(v);
                        Notification.PostTicker("~g~" + L("Mass", "Massa") + "~s~ "
                            + Txt(it) + " " + it.Opts[it.Sel], false);
                    }
                    else
                    {
                        Notification.PostTicker("~y~" + L("Get in a vehicle first",
                            "Sali su un veicolo"), false);
                    }
                }
                break;

            case 217:
                {
                    Vehicle v = TargetVehicle();
                    if (v != null && v.Exists())
                    {
                        string txt = Game.GetUserInput("");
                        if (txt != null && txt.Trim().Length > 0)
                        {
                            Function.Call(Hash.SET_VEHICLE_NUMBER_PLATE_TEXT, v, txt.Trim().ToUpper());
                            TouchSaved(v);
                        }
                    }
                }
                break;

            case 500:
                {
                    Array vals = Enum.GetValues(typeof(WeaponHash));
                    int i;
                    int given = 0;
                    for (i = 0; i < vals.Length; i++)
                    {
                        WeaponHash w = (WeaponHash)vals.GetValue(i);
                        if (w == WeaponHash.Unarmed) continue;
                        Function.Call(Hash.GIVE_WEAPON_TO_PED, p, (int)w, 9999, false, false);
                        given++;
                    }
                    Notification.PostTicker("~g~" + given + " " + L("weapons", "armi"), false);
                }
                break;

            case 501:
                {
                    Array vals = Enum.GetValues(typeof(WeaponHash));
                    int i;
                    for (i = 0; i < vals.Length; i++)
                    {
                        WeaponHash w = (WeaponHash)vals.GetValue(i);
                        if (w == WeaponHash.Unarmed) continue;
                        if (!Function.Call<bool>(Hash.HAS_PED_GOT_WEAPON, p, (int)w, false)) continue;
                        Function.Call(Hash.SET_PED_AMMO, p, (int)w, 9999);
                    }
                    Notification.PostTicker("~g~" + L("Ammo refilled", "Munizioni ricaricate"), false);
                }
                break;

            case 505:
                {
                    int wh;
                    if (int.TryParse(it.Data, out wh))
                    {
                        Function.Call(Hash.GIVE_WEAPON_TO_PED, p, wh, 9999, false, true);
                        Function.Call(Hash.SET_CURRENT_PED_WEAPON, p, wh, true);
                        Notification.PostTicker("~g~" + Txt(it), false);
                    }
                }
                break;

            case 504:
                Function.Call(Hash.REMOVE_ALL_PED_WEAPONS, p, true);
                Notification.PostTicker("~g~" + L("Weapons removed", "Armi rimosse"), false);
                break;

            case 200:
                {
                    string typed = Game.GetUserInput("");
                    if (typed != null && typed.Trim().Length > 0)
                    {
                        SpawnVehicle(typed.Trim());
                    }
                }
                break;

            case 204:
                {
                    Vehicle v = TargetVehicle();
                    if (v == null || !v.Exists())
                    {
                        Notification.PostTicker("~y~" + L("Not in a vehicle", "Non sei in un veicolo"), false);
                    }
                    else
                    {
                        v.Delete();
                        Notification.PostTicker("~g~" + L("Vehicle deleted", "Veicolo eliminato"), false);
                    }
                }
                break;

            case 205:
                {
                    Vehicle v = TargetVehicle();
                    if (v == null || !v.Exists())
                    {
                        Notification.PostTicker("~y~" + L("Not in a vehicle", "Non sei in un veicolo"), false);
                    }
                    else
                    {
                        v.Repair();
                        Notification.PostTicker("~g~" + L("Repaired", "Riparato"), false);
                    }
                }
                break;

            case 206:
                {
                    Vehicle v = TargetVehicle();
                    if (v == null || !v.Exists())
                    {
                        Notification.PostTicker("~y~" + L("Not in a vehicle", "Non sei in un veicolo"), false);
                    }
                    else
                    {
                        Function.Call(Hash.SET_VEHICLE_DIRT_LEVEL, v, 0.0f);
                        Notification.PostTicker("~g~" + L("Cleaned", "Pulito"), false);
                    }
                }
                break;

            case 210:
                SpawnVehicle(it.Data);
                break;

            case 211:
                pendingClear = true;   // eseguita al prossimo tick, fuori dal disegno
                break;

            case 266:
            case 267:
                {
                    int cost = (it.Id == 266) ? 12 : 3;
                    int money = Game.Player.Money;
                    if (money < cost)
                    {
                        Notification.PostTicker("~r~" + L("Not enough money", "Non hai abbastanza soldi"), false);
                        break;
                    }

                    Game.Player.Money = money - cost;
                    if (it.Id == 266)
                    {
                        hunger = hunger + 60f;
                        thirst = thirst + 20f;
                    }
                    else
                    {
                        thirst = thirst + 55f;
                    }
                    if (hunger > 100f) hunger = 100f;
                    if (thirst > 100f) thirst = 100f;

                    snackNext = Game.GameTime + 8000;
                    lastMoney = Game.Player.Money;
                    SaveBody();
                    Notification.PostTicker("~g~" + Txt(it) + "~s~  -$" + cost, false);
                }
                break;

            case 300:
                {
                    int b = Function.Call<int>(Hash.GET_FIRST_BLIP_INFO_ID, 8);
                    if (!Function.Call<bool>(Hash.DOES_BLIP_EXIST, b))
                    {
                        Notification.PostTicker("~y~" + L("No waypoint set", "Nessun waypoint impostato"), false);
                    }
                    else
                    {
                        Vector3 wp = Function.Call<Vector3>(Hash.GET_BLIP_INFO_ID_COORD, b);
                        TeleportTo(wp);
                    }
                }
                break;

            case 301:
                {
                    Vector3 ob = FindObjectiveBlip();
                    if (ob.X == 0f && ob.Y == 0f)
                    {
                        Notification.PostTicker("~y~" + L("No objective found", "Nessun obiettivo trovato"), false);
                    }
                    else
                    {
                        TeleportTo(ob);
                    }
                }
                break;

            case 248:
                {
                    Vehicle v = TargetVehicle();
                    if (v != null && v.Exists())
                    {
                        MaxUpgrades(v);
                        TouchSaved(v);
                        BuildModShop();
                    }
                }
                break;

            case 249:
                {
                    Vehicle v = TargetVehicle();
                    if (v != null && v.Exists())
                    {
                        Function.Call(Hash.SET_VEHICLE_MOD_KIT, v, 0);
                        int sl;
                        for (sl = 0; sl <= 48; sl++)
                        {
                            if (IsToggleSlot(sl)) Function.Call(Hash.TOGGLE_VEHICLE_MOD, v, sl, false);
                            else Function.Call(Hash.REMOVE_VEHICLE_MOD, v, sl);
                        }
                        TouchSaved(v);
                        BuildModShop();
                        Notification.PostTicker("~g~" + L("Back to stock", "Tornato di serie"), false);
                    }
                }
                break;

            case 303:
                {
                    string nm = Game.GetUserInput("");
                    if (nm != null && nm.Trim().Length > 0)
                    {
                        Vector3 pp = p.Position;
                        placeRaw.Add(nm.Trim() + "|"
                            + pp.X.ToString("0.00", CultureInfo.InvariantCulture) + "|"
                            + pp.Y.ToString("0.00", CultureInfo.InvariantCulture) + "|"
                            + pp.Z.ToString("0.00", CultureInfo.InvariantCulture));
                        SavePlaces();
                        BuildPlaces();
                        Notification.PostTicker("~g~" + L("Spot saved", "Punto salvato"), false);
                    }
                }
                break;

            case 304:
            case 306:
                {
                    string[] f = it.Data.Split('|');
                    if (f.Length >= 3)
                    {
                        float x, y2, z;
                        if (float.TryParse(f[0], NumberStyles.Float, CultureInfo.InvariantCulture, out x)
                         && float.TryParse(f[1], NumberStyles.Float, CultureInfo.InvariantCulture, out y2)
                         && float.TryParse(f[2], NumberStyles.Float, CultureInfo.InvariantCulture, out z))
                        {
                            TeleportTo(new Vector3(x, y2, z));
                        }
                    }
                }
                break;

            case 305:
                {
                    int k;
                    if (int.TryParse(it.Data, out k) && k >= 0 && k < placeRaw.Count)
                    {
                        placeRaw.RemoveAt(k);
                        SavePlaces();
                        BuildPlaces();
                        cur = mPlaces;
                        menus[cur].Sel = FirstSelectable(cur);
                        menus[cur].Top = 0;
                    }
                }
                break;

            case 405:
            case 406:
            case 407:
            case 408:
                {
                    int h = 6;
                    if (it.Id == 406) h = 12;
                    if (it.Id == 407) h = 19;
                    if (it.Id == 408) h = 1;

                    if (tHour != null) tHour.Val = h;
                    if (tMinute != null) tMinute.Val = 0;
                    SetClock(h, 0);
                    SaveConfig();
                }
                break;

            case 230:
                {
                    int idx;
                    if (int.TryParse(it.Data, out idx))
                    {
                        Vector3 d = new Vector3(PvFloat(idx, 6), PvFloat(idx, 7), PvFloat(idx, 8));
                        TeleportTo(d);
                        if (FindWorldVehicle(idx) == null)
                        {
                            SpawnSaved(idx, false);
                        }
                    }
                }
                break;

            case 231:
                {
                    int idx;
                    if (int.TryParse(it.Data, out idx))
                    {
                        SpawnSaved(idx, true);
                    }
                }
                break;

            case 232:
                {
                    int idx;
                    if (int.TryParse(it.Data, out idx) && idx >= 0 && idx < pvRaw.Count)
                    {
                        // si esce subito dal sottomenu e la rimozione vera
                        // avviene al prossimo tick, fuori dal disegno
                        pendingRemove = idx;
                        cur = mMyVeh;
                        menus[cur].Sel = FirstSelectable(cur);
                        menus[cur].Top = 0;
                    }
                }
                break;

            case 220:
            case 221:
            case 222:
            case 223:
                {
                    int ci;
                    if (int.TryParse(it.Data, out ci))
                    {
                        ApplyPaint(it.Id - 220, ci);
                        ReadPaint();          // la tinta scelta diventa la nuova base
                        paintPreview = true;
                        Notification.PostTicker("~g~" + Txt(it), false);
                    }
                }
                break;

            default:
                Notification.PostTicker("~y~" + L("Not implemented yet", "Non ancora implementata") + "~s~ (id " + it.Id + ")", false);
                break;
        }
    }

    // toggle / list / number: chiamata a ogni cambio di valore
    void OnChanged(TItem it)
    {
        int pid = Function.Call<int>(Hash.PLAYER_ID);
        SaveConfig();

        // le mod esterne non hanno un case: si salva mods.ini e basta
        if (HandleModToggle(it.Id)) return;

        switch (it.Id)
        {
            case 102:
                Game.Player.Character.IsInvincible = it.On;
                break;

            case 103:
                Function.Call(Hash.SET_MAX_WANTED_LEVEL, it.On ? 0 : 5);
                if (!it.On) Notification.PostTicker("~y~" + L("Wanted level restored", "Ricercato riattivato"), false);
                break;

            case 104:
                Function.Call(Hash.SET_PLAYER_WANTED_LEVEL, pid, it.Val, false);
                Function.Call(Hash.SET_PLAYER_WANTED_LEVEL_NOW, pid, false);
                break;

            case 207:
                {
                    Vehicle v = TargetVehicle();
                    if (v != null && v.Exists() && !it.On)
                    {
                        v.IsInvincible = false;
                        v.CanTiresBurst = true;
                        v.IsFireProof = false;
                    }
                }
                break;

            case 241:
                {
                    Vehicle v = TargetVehicle();
                    int slot;
                    if (v != null && v.Exists() && int.TryParse(it.Data, out slot))
                    {
                        Function.Call(Hash.SET_VEHICLE_MOD_KIT, v, 0);
                        Function.Call(Hash.SET_VEHICLE_MOD, v, slot, it.Sel - 1, false);
                        TouchSaved(v);
                    }
                }
                break;

            case 242:
                {
                    Vehicle v = TargetVehicle();
                    int slot;
                    if (v != null && v.Exists() && int.TryParse(it.Data, out slot))
                    {
                        Function.Call(Hash.SET_VEHICLE_MOD_KIT, v, 0);
                        Function.Call(Hash.TOGGLE_VEHICLE_MOD, v, slot, it.On);
                        TouchSaved(v);
                    }
                }
                break;

            case 243:
                {
                    Vehicle v = TargetVehicle();
                    if (v != null && v.Exists())
                    {
                        Function.Call(Hash.SET_VEHICLE_MOD_KIT, v, 0);
                        Function.Call(Hash.SET_VEHICLE_WHEEL_TYPE, v, it.Sel);
                        TouchSaved(v);
                    }
                }
                break;

            case 244:
                {
                    Vehicle v = TargetVehicle();
                    if (v != null && v.Exists())
                    {
                        Function.Call(Hash.SET_VEHICLE_WINDOW_TINT, v, it.Sel);
                        TouchSaved(v);
                    }
                }
                break;

            case 246:
                {
                    Vehicle v = TargetVehicle();
                    if (v != null && v.Exists())
                    {
                        Function.Call(Hash.SET_VEHICLE_LIVERY, v, it.Sel - 1);
                        TouchSaved(v);
                    }
                }
                break;

            case 247:
                {
                    Vehicle v = TargetVehicle();
                    int ex;
                    if (v != null && v.Exists() && int.TryParse(it.Data, out ex))
                    {
                        Function.Call(Hash.SET_VEHICLE_EXTRA, v, ex, it.On ? 0 : 1);
                        TouchSaved(v);
                    }
                }
                break;

            case 260:
                if (!it.On) SaveTanks();
                break;

            case 261:
                if (!it.On) SaveBody();
                break;

            case 400:
                SetWeather(it.Sel);
                break;

            case 401:
                if (!it.On)
                {
                    Function.Call(Hash.CLEAR_WEATHER_TYPE_PERSIST);
                    Function.Call(Hash.CLEAR_OVERRIDE_WEATHER);
                }
                else if (tWeather != null)
                {
                    SetWeather(tWeather.Sel);
                }
                break;

            case 402:
            case 403:
                if (tHour != null && tMinute != null)
                {
                    SetClock(tHour.Val, tMinute.Val);
                }
                break;

            case 404:
                if (!it.On)
                {
                    Function.Call(Hash.NETWORK_CLEAR_CLOCK_TIME_OVERRIDE);
                }
                break;

            case 409:
                Function.Call(Hash.SET_ARTIFICIAL_LIGHTS_STATE, it.On);
                break;

            case 900:
                lang = it.Sel;
                break;

            default:
                break;
        }
    }

    void SpawnVehicle(string name)
    {
        int hash = Function.Call<int>(Hash.GET_HASH_KEY, name);
        if (!Function.Call<bool>(Hash.IS_MODEL_IN_CDIMAGE, hash) || !Function.Call<bool>(Hash.IS_MODEL_A_VEHICLE, hash))
        {
            Notification.PostTicker("~r~" + L("Invalid model", "Modello non valido") + ":~s~ " + name, false);
            return;
        }

        Model m = new Model(hash);
        m.Request();
        int waited = 0;
        while (!m.IsLoaded && waited < 4000)
        {
            Script.Wait(50);
            waited += 50;
        }
        if (!m.IsLoaded)
        {
            Notification.PostTicker("~r~" + L("Load timeout", "Timeout caricamento") + ":~s~ " + name, false);
            return;
        }

        Ped ped = Game.Player.Character;
        Vector3 pos = ped.Position + ped.ForwardVector * 5.0f;
        Vehicle v = World.CreateVehicle(m, pos, ped.Heading + 90f);
        m.MarkAsNoLongerNeeded();

        if (v == null || !v.Exists())
        {
            Notification.PostTicker("~r~" + L("Spawn failed", "Spawn fallito") + ":~s~ " + name, false);
            return;
        }

        if (tDelPrev != null && tDelPrev.On && lastSpawned != null && lastSpawned.Exists() && lastSpawned != v)
        {
            lastSpawned.Delete();
        }
        lastSpawned = v;

        v.PlaceOnGround();
        v.IsPersistent = true;
        Function.Call(Hash.SET_VEHICLE_ON_GROUND_PROPERLY, v);

        if (tMaxMods != null && tMaxMods.On)
        {
            MaxUpgrades(v);
        }

        if (tSpawnInside != null && tSpawnInside.On)
        {
            ped.SetIntoVehicle(v, VehicleSeat.Driver);
        }

        if (tPersist != null && tPersist.On)
        {
            SaveVehicleEntry(v, name);
        }

        Notification.PostTicker("~g~Spawn:~s~ " + name, false);
    }

    void MaxUpgrades(Vehicle v)
    {
        Function.Call(Hash.SET_VEHICLE_MOD_KIT, v, 0);
        int i;
        for (i = 0; i <= 16; i++)
        {
            int max = Function.Call<int>(Hash.GET_NUM_VEHICLE_MODS, v, i);
            if (max > 0)
            {
                Function.Call(Hash.SET_VEHICLE_MOD, v, i, max - 1, false);
            }
        }
        Function.Call(Hash.TOGGLE_VEHICLE_MOD, v, 18, true);   // turbo
        Function.Call(Hash.SET_VEHICLE_WINDOW_TINT, v, 1);
    }

    // ---------- config persistente: salva OGNI voce con uno stato ----------
    void SaveConfig()
    {
        try
        {
            Directory.CreateDirectory(DATA_DIR);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("# Impostazioni del trainer - salvate in automatico");
            sb.AppendLine("# formato: idvoce=valore");

            int mi;
            for (mi = 0; mi < menus.Count; mi++)
            {
                int ii;
                for (ii = 0; ii < menus[mi].Items.Count; ii++)
                {
                    TItem it = menus[mi].Items[ii];
                    if (it.Id <= 0)
                    {
                        continue;
                    }

                    if (it.Kind == TItem.TOGGLE)
                    {
                        sb.AppendLine(it.Id + "=" + (it.On ? "1" : "0"));
                    }
                    else if (it.Kind == TItem.LIST)
                    {
                        sb.AppendLine(it.Id + "=" + it.Sel);
                    }
                    else if (it.Kind == TItem.NUMBER)
                    {
                        sb.AppendLine(it.Id + "=" + it.Val);
                    }
                }
            }

            File.WriteAllText(Path.Combine(DATA_DIR, "config.ini"), sb.ToString());
        }
        catch (Exception)
        {
        }
    }

    void LoadConfig()
    {
        try
        {
            string f = Path.Combine(DATA_DIR, "config.ini");
            if (!File.Exists(f))
            {
                return;
            }

            string[] lines = File.ReadAllLines(f);
            int i;
            for (i = 0; i < lines.Length; i++)
            {
                string row = lines[i].Trim();
                if (row.Length == 0 || row.StartsWith("#")) continue;

                string[] kv = row.Split('=');
                if (kv.Length != 2) continue;

                int id;
                int val;
                if (!int.TryParse(kv[0].Trim(), out id)) continue;
                if (!int.TryParse(kv[1].Trim(), out val)) continue;

                int mi;
                for (mi = 0; mi < menus.Count; mi++)
                {
                    int ii;
                    for (ii = 0; ii < menus[mi].Items.Count; ii++)
                    {
                        TItem it = menus[mi].Items[ii];
                        if (it.Id != id) continue;

                        if (it.Kind == TItem.TOGGLE)
                        {
                            it.On = (val == 1);
                        }
                        else if (it.Kind == TItem.LIST)
                        {
                            if (it.Opts != null && val >= 0 && val < it.Opts.Length) it.Sel = val;
                        }
                        else if (it.Kind == TItem.NUMBER)
                        {
                            if (val >= it.Min && val <= it.Max) it.Val = val;
                        }
                    }
                }
            }
        }
        catch (Exception)
        {
        }
    }

    // effetti continui: girano a ogni frame, anche a menu chiuso
    // "Massa": in questa build la handling non e' scrivibile (letta 14.900.000
    // invece di ~1900 kg, l'offset di SHVDN non combacia con Enhanced).
    // Quindi l'effetto si fa con la fisica: le auto che tocchi vengono
    // spinte via con un impulso proporzionale al moltiplicatore e alla
    // tua velocita'. Il risultato a schermo e' quello di un'auto pesantissima.
    int massNext = 0;

    // 0 = off, 1 = solo motore, 2 = solo carrozzeria, 3 = tutto
    // ============================================================
    //  MOD ESTERNE
    //  scripts\Lavori\Uber\Uber.cs        -> voce "Uber" sotto Jobs
    //  scripts\Minigiochi\Drift\Drift.cs  -> voce "Drift" sotto Minigames
    //  Il trainer scrive solo Trainer\mods.ini: "lavori/uber=1".
    // ============================================================
    string ModsFile()
    {
        return Path.Combine(DATA_DIR, "mods.ini");
    }

    void BuildModsMenu(int root)
    {
        int mMods = NewMenu("MODS", "MODS", root);
        TItem sub = AddSub(root, "Mods", "Mods", mMods);
        sub.Cr = PASTEL[2, 0]; sub.Cg = PASTEL[2, 1]; sub.Cb = PASTEL[2, 2];
        sub.Tinted = true;

        int c;
        int nextId = modFirstId;
        for (c = 0; c < MOD_CAT_DIR.Length; c++)
        {
            string dir = Path.Combine(SCRIPTS_DIR, MOD_CAT_DIR[c]);
            string[] subs;
            try
            {
                if (!Directory.Exists(dir)) continue;
                subs = Directory.GetDirectories(dir);
            }
            catch { continue; }
            if (subs.Length == 0) continue;

            Array.Sort(subs);

            bool header = false;
            int i;
            for (i = 0; i < subs.Length; i++)
            {
                // dentro la cartella ci deve essere almeno un .cs, altrimenti
                // e' una cartella di dati e non un mod
                string[] cs;
                try { cs = Directory.GetFiles(subs[i], "*.cs"); }
                catch { continue; }
                if (cs.Length == 0) continue;

                string name = Path.GetFileName(subs[i]);

                if (!header)
                {
                    AddHeader(mMods, "- " + MOD_CAT_EN[c].ToUpper() + " -",
                                     "- " + MOD_CAT_IT[c].ToUpper() + " -", c % 4);
                    header = true;
                }

                TItem t = AddToggle(mMods, name, name, nextId, false);
                modId.Add(MOD_CAT_DIR[c].ToLower() + "/" + name.ToLower());
                modItem.Add(t);
                nextId++;
            }
        }

        if (modId.Count == 0)
        {
            AddHeader(mMods, "- NO MODS INSTALLED -", "- NESSUN MOD INSTALLATO -", 0);
        }

        LoadModsIni();
    }

    // stato salvato: e' mods.ini a comandare, non config.ini,
    // cosi' il mod e il trainer leggono sempre la stessa cosa
    void LoadModsIni()
    {
        try
        {
            string f = ModsFile();
            if (!File.Exists(f)) { SaveModsIni(); return; }

            string[] rows = File.ReadAllLines(f);
            int i, k;
            for (i = 0; i < rows.Length; i++)
            {
                string r = rows[i].Trim();
                if (r.Length == 0 || r[0] == '#') continue;
                int eq = r.IndexOf('=');
                if (eq < 1) continue;
                string id = r.Substring(0, eq).Trim().ToLower();
                string val = r.Substring(eq + 1).Trim();

                for (k = 0; k < modId.Count; k++)
                {
                    if (modId[k] == id) modItem[k].On = (val == "1");
                }
            }
        }
        catch { }
    }

    void SaveModsIni()
    {
        try
        {
            Directory.CreateDirectory(DATA_DIR);
            StringBuilder sb = new StringBuilder();
            sb.Append("# acceso/spento delle mod esterne - lo scrive il trainer\r\n");
            sb.Append("# formato: categoria/nome=1\r\n");
            int i;
            for (i = 0; i < modId.Count; i++)
            {
                sb.Append(modId[i] + "=" + (modItem[i].On ? "1" : "0") + "\r\n");
            }
            File.WriteAllText(ModsFile(), sb.ToString());
        }
        catch { }
    }

    // true se l'id della voce e' di un mod: allora si salva mods.ini
    bool HandleModToggle(int id)
    {
        if (id < modFirstId || id >= modFirstId + modId.Count) return false;
        SaveModsIni();
        int k = id - modFirstId;
        Notification.PostTicker((modItem[k].On ? "~g~" : "~y~") + modItem[k].Text
            + "~s~ " + (modItem[k].On ? L("on", "acceso") : L("off", "spento")), false);
        return true;
    }

    // ============================================================
    //  RADIO
    //  Le stazioni si chiedono al gioco invece di scriverle a mano:
    //  cosi' ci sono anche quelle nuove di Enhanced e quelle dei mod.
    // ============================================================
    void BuildRadioItems(int menu)
    {
        // NIENTE native qui dentro: questo codice gira mentre lo script
        // nasce, e il gioco puo' non essere ancora pronto a rispondere.
        // La lista vera si riempie al primo tick, dentro ApplyRadio.
        tRadio = AddList(menu, "Radio station", "Stazione radio", 903,
                         new string[] { "Off" }, 0);
        tRadioMobile = AddToggle(menu, "Radio on foot", "Radio a piedi", 904, false);
    }

    // rilegge dal config.ini la stazione scelta, ora che la lista e' vera
    void RestoreSavedRadio()
    {
        try
        {
            string f = Path.Combine(DATA_DIR, "config.ini");
            if (!File.Exists(f)) return;
            string[] rows = File.ReadAllLines(f);
            int i;
            for (i = 0; i < rows.Length; i++)
            {
                string r = rows[i].Trim();
                if (!r.StartsWith("903=")) continue;
                int val;
                if (int.TryParse(r.Substring(4).Trim(), out val))
                {
                    if (tRadio != null && tRadio.Opts != null
                        && val >= 0 && val < tRadio.Opts.Length)
                    {
                        tRadio.Sel = val;
                    }
                }
                return;
            }
        }
        catch { }
    }

    void FillRadioList()
    {
        radioName.Clear();
        List<string> shown = new List<string>();
        shown.Add("Off");
        shown.Add(L("Free", "Libera"));

        int n = Function.Call<int>(Hash.GET_NUM_UNLOCKED_RADIO_STATIONS);
        int i;
        for (i = 0; i < n; i++)
        {
            string id = Function.Call<string>(Hash.GET_RADIO_STATION_NAME, i);
            if (id == null || id.Length == 0 || id == "OFF") continue;
            radioName.Add(id);
            shown.Add(RadioLabel(id));
        }

        if (radioName.Count > 0 && tRadio != null)
        {
            int keep = tRadio.Sel;
            tRadio.Opts = shown.ToArray();
            if (keep >= tRadio.Opts.Length) keep = 0;
            tRadio.Sel = keep;
        }
    }

    // dal nome interno della stazione al dizionario del suo logo:
    // RADIO_01_CLASS_ROCK -> radio_01class_rock provato prima, poi radio_01class
    string RadioDict(string id)
    {
        if (id == null) return "";
        string t = id.ToLower();
        if (!t.StartsWith("radio_")) return "";

        // radio_01_class_rock -> radio_01class_rock
        int p1 = t.IndexOf('_', 6);
        if (p1 > 0) t = t.Substring(0, p1) + t.Substring(p1 + 1);

        // il dizionario vero e' la forma corta: radio_01class
        int p2 = t.IndexOf('_', 6);
        if (p2 > 0) t = t.Substring(0, p2);
        return t;
    }

    // un colore pastello fisso per ogni stazione: dipende dal nome,
    // quindi la stessa radio ha sempre lo stesso colore
    static readonly Color[] RADIO_PASTEL = new Color[] {
        Color.FromArgb(255, 150, 230, 170),   // verde
        Color.FromArgb(255, 150, 200, 245),   // azzurro
        Color.FromArgb(255, 245, 175, 195),   // rosa
        Color.FromArgb(255, 250, 215, 140),   // ambra
        Color.FromArgb(255, 200, 175, 245),   // lilla
        Color.FromArgb(255, 150, 230, 225),   // acqua
        Color.FromArgb(255, 245, 200, 150),   // pesca
        Color.FromArgb(255, 220, 235, 150)    // lime
    };

    // i colori seguono l'ordine delle stazioni: prima stazione il primo
    // colore, seconda il secondo, e dopo l'ottava si ricomincia
    Color PastelFor(string id)
    {
        if (id == null || id.Length == 0) return Color.FromArgb(255, 255, 255, 255);
        int i = radioName.IndexOf(id);
        if (i < 0) return Color.FromArgb(255, 255, 255, 255);
        return RADIO_PASTEL[i % RADIO_PASTEL.Length];
    }

    // dal nome interno al nome leggibile, se il gioco ce l'ha
    string RadioLabel(string id)
    {
        string lab = Game.GetLocalizedString(id);
        if (lab != null && lab.Length > 0 && lab != "NULL") return lab;

        // ripiego: RADIO_01_CLASS_ROCK -> CLASS ROCK
        string t = id;
        if (t.StartsWith("RADIO_") && t.Length > 9) t = t.Substring(9);
        return t.Replace("_", " ");
    }

    // stazione scelta: 0 = spenta, altrimenti indice in radioName
    void ApplyRadio(Vehicle v)
    {
        if (tRadio == null) return;

        // all'avvio dello script il gioco puo' non aver ancora pronto
        // l'elenco delle stazioni: in quel caso si riempie al primo giro utile
        if (radioName.Count == 0)
        {
            FillRadioList();
            if (radioName.Count == 0) return;

            // la config e' stata letta quando la lista aveva solo "Off":
            // il valore salvato era stato scartato, si rilegge adesso
            RestoreSavedRadio();
        }

        int now = Game.GameTime;
        int vh = (v != null && v.Exists()) ? v.Handle : 0;

        // si interviene quando cambi veicolo, e comunque ogni due secondi:
        // il gioco ogni tanto rimette la sua stazione preferita
        if (vh == radioLastVeh && now < radioNext) return;
        radioLastVeh = vh;
        radioNext = now + 2000;

        int sel = tRadio.Sel;

        if (sel <= 0)
        {
            if (v != null && v.Exists())
            {
                Function.Call(Hash.SET_VEHICLE_RADIO_ENABLED, v, false);
            }
            Function.Call(Hash.SET_RADIO_TO_STATION_NAME, "OFF");
            return;
        }

        // 'Libera': il trainer non tocca piu' niente, la cambi tu nel gioco
        if (sel == 1)
        {
            if (v != null && v.Exists())
            {
                Function.Call(Hash.SET_VEHICLE_RADIO_ENABLED, v, true);
            }
            return;
        }

        int idx = sel - 2;
        if (idx >= radioName.Count) return;

        if (v != null && v.Exists())
        {
            Function.Call(Hash.SET_VEHICLE_RADIO_ENABLED, v, true);
        }

        string want = radioName[idx];
        string cur = Function.Call<string>(Hash.GET_PLAYER_RADIO_STATION_NAME);
        if (cur != want)
        {
            Function.Call(Hash.SET_RADIO_TO_STATION_NAME, want);
        }
    }

    // radio anche a piedi
    void ApplyMobileRadio()
    {
        if (tRadioMobile == null) return;
        bool want = tRadioMobile.On;

        Function.Call(Hash.SET_MOBILE_RADIO_ENABLED_DURING_GAMEPLAY, want);
        Function.Call(Hash.SET_AUDIO_FLAG, "MobileRadioInGame", want);
        Function.Call(Hash.SET_MOBILE_PHONE_RADIO_STATE, want);
    }

    // ============================================================
    //  LIMITATORE DI VELOCITA' (come l'ISA delle auto moderne)
    //  Legge il limite della strada su cui sei e non ti lascia andare
    //  oltre: il gas resta tuo, e' la macchina che non spinge di piu'.
    // ============================================================
    void ApplyLimiter(Vehicle v)
    {
        bool want = (tLimiter != null && tLimiter.On);

        if (v == null || !v.Exists()) { limiterVeh = 0; return; }
        if (v.Driver == null || v.Driver.Handle != Game.Player.Character.Handle) return;

        if (!want)
        {
            // spento: si toglie il tetto sul veicolo su cui sei, sempre,
            // perche' se il limitatore e' stato spento fuori dall'auto il
            // tetto restava attaccato e la macchina non superava i 93 km/h
            Function.Call(Hash.SET_ENTITY_MAX_SPEED, v, 500f);
            limiterVeh = 0;
            return;
        }

        limiterVeh = v.Handle;

        // Due km/h sotto il cartello: cosi' non fa scattare la multa
        // proprio mentre ti sta trattenendo.
        float target = (float)SpeedLimitNow() - 2f;
        if (target < 5f) target = 5f;

        float kmh = Function.Call<float>(Hash.GET_ENTITY_SPEED, v) * 3.6f;

        // Il limitatore vero non frena e non mette un tetto alla fisica:
        // taglia il gas. Cosi' il cambio sale di marcia come sempre e non
        // resti in fuorigiri. Il freno e la retromarcia restano tuoi.
        if (kmh > target)
        {
            Function.Call(Hash.DISABLE_CONTROL_ACTION, 0, 71, true);   // acceleratore
        }

        // rete di sicurezza per le discese: un tetto largo, 15 km/h sopra,
        // che non entra mai in gioco in piano e non tocca le marce
        Function.Call(Hash.SET_ENTITY_MAX_SPEED, v, (target + 15f) / 3.6f);
    }

    int VehGodMode()
    {
        if (tVehGod == null) return 0;
        return tVehGod.Sel;
    }

    void ApplyMass(Vehicle v)
    {
        if (v == null || !v.Exists()) return;
        if (tMass == null) return;

        int sel = tMass.Sel;
        if (sel < 0 || sel >= MASS_MULT.Length) return;

        float mult = MASS_MULT[sel];
        if (mult <= 1f) return;              // x1 e sotto: il gioco fa da se'

        int now = Game.GameTime;
        if (now < massNext) return;
        massNext = now + 50;

        Vector3 me = v.Position;
        float mySpeed = v.Speed;
        if (mySpeed < 1f) mySpeed = 1f;

        // quanto spinge: cresce col moltiplicatore ma senza esplodere
        // il tipo di forza 1 e' gia' scalato sulla massa del bersaglio:
        // bastano numeri piccoli. x1 = zero spinta, poi si sale a mezzi passi.
        float power = (mult - 1f) * 1.2f;

        Vehicle[] near = World.GetNearbyVehicles(me, 7f);
        int i;
        for (i = 0; i < near.Length; i++)
        {
            Vehicle o = near[i];
            if (o == null || !o.Exists()) continue;
            if (o.Handle == v.Handle) continue;

            // solo quelle che stai davvero toccando
            if (!Function.Call<bool>(Hash.IS_ENTITY_TOUCHING_ENTITY, v, o)) continue;

            Vector3 d = o.Position - me;
            d.Z = 0f;
            float len = d.Length();
            if (len < 0.01f) continue;
            d = d / len;

            float force = power * (1f + mySpeed / 25f);

            Function.Call(Hash.APPLY_FORCE_TO_ENTITY, o, 1,
                          d.X * force, d.Y * force, force * 0.08f,
                          0f, 0f, 0f, 0, false, true, true, false, true);
        }
    }

    void ApplyToggles(bool busy)
    {
        Ped p = Game.Player.Character;
        if (p == null || !p.Exists())
        {
            return;
        }
        int pid = Function.Call<int>(Hash.PLAYER_ID);

        if (tGod != null && tGod.On && !p.IsInvincible)
        {
            p.IsInvincible = true;
        }

        if (tNeverWanted != null && tNeverWanted.On)
        {
            if (Function.Call<int>(Hash.GET_PLAYER_WANTED_LEVEL, pid) != 0)
            {
                Function.Call(Hash.SET_PLAYER_WANTED_LEVEL, pid, 0, false);
                Function.Call(Hash.SET_PLAYER_WANTED_LEVEL_NOW, pid, false);
            }
            Function.Call(Hash.SET_MAX_WANTED_LEVEL, 0);
        }

        if (tStamina != null && tStamina.On)
        {
            Function.Call(Hash.RESET_PLAYER_STAMINA, pid);
        }

        if (tBreath != null && tBreath.On)
        {
            Function.Call(Hash.SET_PED_MAX_TIME_UNDERWATER, p, 1000.0f);
        }

        if (tJump != null && tJump.On)
        {
            Function.Call(Hash.SET_SUPER_JUMP_THIS_FRAME, pid);
        }

        if (tInvisible != null)
        {
            Function.Call(Hash.SET_ENTITY_VISIBLE, p, !tInvisible.On, false);
        }

        if (tNoRagdoll != null)
        {
            Function.Call(Hash.SET_PED_CAN_RAGDOLL, p, !tNoRagdoll.On);
        }

        if (tSeatbelt != null)
        {
            // flag 32: non essere sbalzato dal parabrezza
            Function.Call(Hash.SET_PED_CONFIG_FLAG, p, 32, !tSeatbelt.On);
        }

        if (tExplosiveAmmo != null && tExplosiveAmmo.On)
        {
            Function.Call(Hash.SET_EXPLOSIVE_AMMO_THIS_FRAME, pid);
        }

        if (tFireAmmo != null && tFireAmmo.On)
        {
            Function.Call(Hash.SET_FIRE_AMMO_THIS_FRAME, pid);
        }

        if (tExplosiveMelee != null && tExplosiveMelee.On)
        {
            Function.Call(Hash.SET_EXPLOSIVE_MELEE_THIS_FRAME, pid);
        }

        if (tTraffic != null && tTraffic.Val < 100)
        {
            float m = tTraffic.Val / 100f;
            Function.Call(Hash.SET_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME, m);
            Function.Call(Hash.SET_RANDOM_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME, m);
            Function.Call(Hash.SET_PARKED_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME, m);
        }

        if (tPeds != null && tPeds.Val < 100)
        {
            float m = tPeds.Val / 100f;
            Function.Call(Hash.SET_PED_DENSITY_MULTIPLIER_THIS_FRAME, m);
            Function.Call(Hash.SET_SCENARIO_PED_DENSITY_MULTIPLIER_THIS_FRAME, m, m);
        }

        if (tNoReload != null)
        {
            Function.Call(Hash.SET_PED_INFINITE_AMMO_CLIP, p, tNoReload.On);
        }

        if (tInfAmmo != null && tInfAmmo.On)
        {
            OutputArgument wa = new OutputArgument();
            if (Function.Call<bool>(Hash.GET_CURRENT_PED_WEAPON, p, wa, true))
            {
                int wh = wa.GetResult<int>();
                if (wh != 0) Function.Call(Hash.SET_PED_AMMO, p, wh, 9999);
            }
        }

        if (busy) return;

        Vehicle cv = p.CurrentVehicle;

        // uscito dal veicolo -> salva dove l'hai lasciato
        if (wasInVeh && (cv == null || !cv.Exists()))
        {
            if (lastDriven != null && lastDriven.Exists())
            {
                if (trackedIdx >= 0)
                {
                    UpdateTrackedEntry(lastDriven);
                }
                else if (tPersist != null && tPersist.On)
                {
                    SaveVehicleEntry(lastDriven, "");
                    Notification.PostTicker("~g~" + L("Vehicle saved", "Veicolo salvato"), false);
                }
            }
            wasInVeh = false;
        }

        if (cv != null && cv.Exists())
        {
            lastDriven = cv;

            // salendo NON si scrive nulla: il veicolo in quel momento sta
            // ancora venendo agganciato dal gioco e interrogarlo lo fa crashare.
            // Ci si limita a capire se e' gia' nella lista.
            if (!wasInVeh)
            {
                wasInVeh = true;
                trackedIdx = FindMyVehicle(cv);
            }
        }

        ApplyRadio(cv);
        ApplyMobileRadio();
        ApplyLimiter(cv);

        if (cv != null && cv.Exists())
        {
            ApplyMass(cv);

            int gmode = VehGodMode();
            if (gmode > 0)
            {
                // 1 = solo meccanica: il motore non si rompe e non prende
                //     fuoco, ma la macchina si ammacca e puo' morire
                if (gmode == 1 || gmode == 3)
                {
                    Function.Call(Hash.SET_VEHICLE_ENGINE_CAN_DEGRADE, cv, false);
                    Function.Call(Hash.SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE, cv, true);
                    Function.Call(Hash.SET_DISABLE_VEHICLE_PETROL_TANK_FIRES, cv, true);
                    Function.Call(Hash.SET_DISABLE_VEHICLE_ENGINE_FIRES, cv, true);
                    Function.Call(Hash.SET_VEHICLE_ENGINE_HEALTH, cv, 1000f);
                    Function.Call(Hash.SET_VEHICLE_PETROL_TANK_HEALTH, cv, 1000f);
                }

                // 2 = solo carrozzeria: non si ammacca, gomme e ruote reggono,
                //     ma il motore si consuma come sempre
                if (gmode == 2 || gmode == 3)
                {
                    Function.Call(Hash.SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED, cv, false);
                    Function.Call(Hash.SET_VEHICLE_STRONG, cv, true);
                    Function.Call(Hash.SET_VEHICLE_HAS_STRONG_AXLES, cv, true);
                    Function.Call(Hash.SET_VEHICLE_TYRES_CAN_BURST, cv, false);
                    Function.Call(Hash.SET_VEHICLE_WHEELS_CAN_BREAK, cv, false);
                    Function.Call(Hash.SET_VEHICLE_BODY_HEALTH, cv, 1000f);
                    cv.CanTiresBurst = false;
                }

                // 3 = tutto: immune a qualunque danno
                if (gmode == 3)
                {
                    cv.IsInvincible = true;
                    cv.IsFireProof = true;
                    Function.Call(Hash.SET_ENTITY_INVINCIBLE, cv, true);
                    Function.Call(Hash.SET_ENTITY_CAN_BE_DAMAGED, cv, false);
                    Function.Call(Hash.SET_ENTITY_PROOFS, cv,
                                  true, true, true, true, true, true, true, true);
                    if (cv.Health < cv.MaxHealth) cv.Health = cv.MaxHealth;
                }
            }
            else if (vehGodWas)
            {
                // spento: si rimette il veicolo com'era
                cv.IsInvincible = false;
                cv.CanTiresBurst = true;
                cv.IsFireProof = false;
                Function.Call(Hash.SET_ENTITY_INVINCIBLE, cv, false);
                Function.Call(Hash.SET_ENTITY_CAN_BE_DAMAGED, cv, true);
                Function.Call(Hash.SET_ENTITY_PROOFS, cv,
                              false, false, false, false, false, false, false, false);
                Function.Call(Hash.SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED, cv, true);
                Function.Call(Hash.SET_VEHICLE_STRONG, cv, false);
                Function.Call(Hash.SET_VEHICLE_TYRES_CAN_BURST, cv, true);
                Function.Call(Hash.SET_VEHICLE_WHEELS_CAN_BREAK, cv, true);
                Function.Call(Hash.SET_VEHICLE_ENGINE_CAN_DEGRADE, cv, true);
                Function.Call(Hash.SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE, cv, false);
                Function.Call(Hash.SET_DISABLE_VEHICLE_PETROL_TANK_FIRES, cv, false);
                Function.Call(Hash.SET_DISABLE_VEHICLE_ENGINE_FIRES, cv, false);
            }
            vehGodWas = (gmode > 0);

            if (tOnWater != null && tOnWater.On)
            {
                OutputArgument oa = new OutputArgument();
                if (Function.Call<bool>(Hash.GET_WATER_HEIGHT, cv.Position.X, cv.Position.Y, cv.Position.Z, oa))
                {
                    float wz = oa.GetResult<float>();
                    if (cv.Position.Z < wz + 1.5f)
                    {
                        Vector3 pp = cv.Position;
                        cv.Position = new Vector3(pp.X, pp.Y, wz + 0.55f);
                        Vector3 vel = cv.Velocity;
                        if (vel.Z < 0f)
                        {
                            cv.Velocity = new Vector3(vel.X, vel.Y, 0f);
                        }
                    }
                }
            }
        }

        AutoTeleport();

        if (tFreezeTime != null && tFreezeTime.On && tHour != null && tMinute != null)
        {
            Function.Call(Hash.NETWORK_OVERRIDE_CLOCK_TIME, tHour.Val, tMinute.Val, 0);
        }
        else
        {
            UpdateClockSpeed();
        }

        if (tBlackout != null && tBlackout.On)
        {
            Function.Call(Hash.SET_ARTIFICIAL_LIGHTS_STATE, true);
        }

        if (tFastRun != null)
        {
            Function.Call(Hash.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER, pid, tFastRun.On ? 1.49f : 1.0f);
        }
    }

    // ============================================================
    //  helper per aggiungere voci
    // ============================================================
    TItem AddHeader(int menu, string en, string it, int ci)
    {
        TItem x = new TItem(TItem.HEADER, en, -1);
        x.TextIt = it;
        x.Cr = PASTEL[ci, 0]; x.Cg = PASTEL[ci, 1]; x.Cb = PASTEL[ci, 2];
        x.Tinted = true;
        menus[menu].Items.Add(x);
        return x;
    }

    // versioni bilingui: (inglese, italiano)
    TItem AddAction(int menu, string en, string it, int id)
    {
        TItem x = AddAction(menu, en, id); x.TextIt = it; return x;
    }

    TItem AddToggle(int menu, string en, string it, int id, bool on)
    {
        TItem x = AddToggle(menu, en, id, on); x.TextIt = it; return x;
    }

    TItem AddNumber(int menu, string en, string it, int id, int val, int min, int max, int step)
    {
        TItem x = AddNumber(menu, en, id, val, min, max, step); x.TextIt = it; return x;
    }

    TItem AddList(int menu, string en, string it, int id, string[] opts, int sel)
    {
        TItem x = AddList(menu, en, id, opts, sel); x.TextIt = it; return x;
    }

    TItem AddSub(int menu, string en, string it, int sub)
    {
        TItem x = AddSub(menu, en, sub); x.TextIt = it; return x;
    }

    int NewMenu(string en, string it, int parent)
    {
        int k = NewMenu(en, parent); menus[k].TitleIt = it; return k;
    }

    TItem AddAction(int menu, string text, int id)
    {
        TItem it = new TItem(TItem.ACTION, text, id);
        menus[menu].Items.Add(it);
        return it;
    }

    TItem AddToggle(int menu, string text, int id, bool on)
    {
        TItem it = new TItem(TItem.TOGGLE, text, id);
        it.On = on;
        menus[menu].Items.Add(it);
        return it;
    }

    TItem AddList(int menu, string text, int id, string[] opts, int sel)
    {
        TItem it = new TItem(TItem.LIST, text, id);
        it.Opts = opts;
        it.Sel = sel;
        menus[menu].Items.Add(it);
        return it;
    }

    TItem AddNumber(int menu, string text, int id, int val, int min, int max, int step)
    {
        TItem it = new TItem(TItem.NUMBER, text, id);
        it.Val = val;
        it.Min = min;
        it.Max = max;
        it.Step = step;
        menus[menu].Items.Add(it);
        return it;
    }

    TItem AddSub(int menu, string text, int sub)
    {
        TItem it = new TItem(TItem.SUB, text, -1);
        it.Sub = sub;
        menus[menu].Items.Add(it);
        return it;
    }

    // ============================================================
    //  loop
    // ============================================================
    // vero mentre il personaggio sta entrando o uscendo da un veicolo,
    // o mentre il gioco sta caricando: in quella finestra non tocchiamo
    // nulla che riguardi i veicoli, e' li' che il gioco crashava
    bool VehicleBusy()
    {
        if (Function.Call<bool>(Hash.GET_IS_LOADING_SCREEN_ACTIVE)) return true;

        Ped p = Game.Player.Character;
        if (p == null || !p.Exists()) return true;

        if (Function.Call<bool>(Hash.IS_PED_GETTING_INTO_A_VEHICLE, p)) return true;
        if (Function.Call<bool>(Hash.IS_PED_IN_ANY_VEHICLE, p, true)
            && !Function.Call<bool>(Hash.IS_PED_SITTING_IN_ANY_VEHICLE, p)) return true;

        return false;
    }

    void OnTick(object sender, EventArgs e)
    {
        ProcessPending();
        PumpGasBlips();
        PumpMarketBlips();

        bool busy = VehicleBusy();

        if (!vehBuilt)
        {
            if (!busy) BuildVehicleClasses();
        }
        else if (!busy)
        {
            LazyVehicles();
        }

        ApplyToggles(busy);
        if (!busy) UpdateFuel(Game.Player.Character);
        if (!busy) UpdateSpeedLimit(Game.Player.Character);
        UpdateBody(Game.Player.Character);
        DrawStatusPanel();
        DrawSpeedo();
        HandleOpenClose();

        if (tTopBar == null || tTopBar.On)
        {
            DrawHeader(MX, MY, MW);
        }


        if (!open)
        {
            return;
        }

        BlockGameControls();
        HandleNavigation();
        UpdatePaintPreview();
        DrawMenu();
    }

    // Allo scarico del dominio NON si usa REMOVE_BLIP: nasconde e basta,
    // come fa Grocery. Rimuovere blip qui fa crashare il gioco.
    void HideBlip(int b)
    {
        if (b == 0) return;
        Function.Call(Hash.SET_BLIP_ALPHA, b, 0);
        Function.Call(Hash.SET_BLIP_DISPLAY, b, 0);   // fuori da minimappa e mappa
    }

    void ShowBlip(int b)
    {
        if (b == 0) return;
        Function.Call(Hash.SET_BLIP_ALPHA, b, 255);
        Function.Call(Hash.SET_BLIP_DISPLAY, b, 2);
    }

    void OnAborted(object sender, EventArgs e)
    {
        try
        {
            SaveTanks();
            SaveOil();
            SaveOdo();
            SaveBody();
        }
        catch (Exception)
        {
        }

        int i;
        for (i = 0; i < pvBlip.Count; i++)
        {
            HideBlip(pvBlip[i]);
        }
        if (gasBlips != null)
        {
            for (i = 0; i < gasBlips.Length; i++)
            {
                HideBlip(gasBlips[i]);
            }
        }
        if (mkBlips != null)
        {
            for (i = 0; i < mkBlips.Length; i++)
            {
                HideBlip(mkBlips[i]);
            }
        }

        if (clockTaken)
        {
            Function.Call(Hash.PAUSE_CLOCK, false);
        }

    }

    void OnKeyDown(object sender, KeyEventArgs e)
    {
        // niente qui: F4 gestito a tick per funzionare anche col pad collegato
    }

    void HandleOpenClose()
    {
        // --- tastiera: F4 ---
        bool f5 = Game.IsKeyPressed(Keys.F4);
        if (f5 && !f5Last)
        {
            Toggle();
        }
        f5Last = f5;

        // --- pad: RB tenuto + DPAD-GIU ---
        rbHeld = Function.Call<bool>(Hash.IS_CONTROL_PRESSED, 2, C_PAD_RB)
              || Function.Call<bool>(Hash.IS_DISABLED_CONTROL_PRESSED, 2, C_PAD_RB);
        bool dpadDown = Function.Call<bool>(Hash.IS_CONTROL_PRESSED, 2, C_DOWN)
                     || Function.Call<bool>(Hash.IS_DISABLED_CONTROL_PRESSED, 2, C_DOWN);
        bool combo = rbHeld && dpadDown;

        if (combo && !comboLast)
        {
            Toggle();
        }
        comboLast = combo;
    }

    void Toggle()
    {
        open = !open;
        if (open)
        {
            cur = 0;
            menus[0].Sel = FirstSelectable(0);
            menus[0].Top = 0;
        }
        Function.Call(Hash.PLAY_SOUND_FRONTEND, -1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", true);
    }

    void BlockGameControls()
    {
        int[] blocked = new int[] {
            24, 25, 47, 257, 263, 264, 140, 141, 142,   // attacco / mira / armi / mischia
            22, 23, 75, 27, 37, 44, 45, 80, 199, 200,   // salto, entra/esci, telefono, armi, pausa
            172, 173, 174, 175, 176, 177                // frecce: le usiamo noi
        };
        int i;
        for (i = 0; i < blocked.Length; i++)
        {
            Function.Call(Hash.DISABLE_CONTROL_ACTION, 0, blocked[i], true);
        }
    }

    bool Pressed(int control)
    {
        return Function.Call<bool>(Hash.IS_DISABLED_CONTROL_JUST_PRESSED, 2, control)
            || Function.Call<bool>(Hash.IS_CONTROL_JUST_PRESSED, 2, control);
    }

    bool Held(int control)
    {
        return Function.Call<bool>(Hash.IS_DISABLED_CONTROL_PRESSED, 2, control)
            || Function.Call<bool>(Hash.IS_CONTROL_PRESSED, 2, control);
    }

    bool IsSelectable(int menu, int idx)
    {
        return menus[menu].Items[idx].Kind != TItem.HEADER;
    }

    int FirstSelectable(int menu)
    {
        int i;
        for (i = 0; i < menus[menu].Items.Count; i++)
        {
            if (IsSelectable(menu, i)) return i;
        }
        return 0;
    }

    void MoveSel(TMenu m, int dir)
    {
        int n = m.Items.Count;
        if (n == 0) return;
        int guard = 0;
        do
        {
            m.Sel = (m.Sel + dir + n) % n;
            guard++;
        }
        while (m.Items[m.Sel].Kind == TItem.HEADER && guard <= n);
    }

    void HandleNavigation()
    {
        if (rbHeld)
        {
            return;
        }

        TMenu m = menus[cur];
        int n = m.Items.Count;
        int now = Game.GameTime;

        // --- su / giu (con auto-ripetizione se tenuto premuto) ---
        bool up   = Pressed(C_UP)   || Game.IsKeyPressed(Keys.NumPad8);
        bool down = Pressed(C_DOWN) || Game.IsKeyPressed(Keys.NumPad2);
        bool upHeld   = Held(C_UP);
        bool downHeld = Held(C_DOWN);

        if (n > 0)
        {
            if (up || down)
            {
                if (now >= navNext)
                {
                    MoveSel(m, up ? -1 : 1);
                    navNext = now + 160;
                    Beep();
                }
            }
            else if (upHeld || downHeld)
            {
                if (now >= navNext)
                {
                    MoveSel(m, upHeld ? -1 : 1);
                    navNext = now + 110;
                    Beep();
                }
            }
            else
            {
                navNext = 0;
            }

            // scroll
            if (m.Sel < m.Top) m.Top = m.Sel;
            if (m.Sel >= m.Top + MAX_VIS) m.Top = m.Sel - MAX_VIS + 1;
        }

        // --- indietro ---
        if (Pressed(C_CANCEL) || Game.IsKeyPressed(Keys.NumPad0))
        {
            if (paintPreview)
            {
                RestorePaint();
                paintPreview = false;
                lastPreviewMenu = -1;
                lastPreviewSel = -1;
            }

            if (menus[cur].Parent >= 0)
            {
                cur = menus[cur].Parent;
            }
            else
            {
                open = false;
            }
            Beep();
            return;
        }

        if (n == 0)
        {
            return;
        }

        TItem it = m.Items[m.Sel];

        // --- sinistra / destra ---
        bool left  = Pressed(C_LEFT)  || Game.IsKeyPressed(Keys.NumPad4);
        bool right = Pressed(C_RIGHT) || Game.IsKeyPressed(Keys.NumPad6);

        if (left || right)
        {
            if (it.Kind == TItem.LIST && it.Opts != null && it.Opts.Length > 0)
            {
                int k = it.Opts.Length;
                it.Sel = left ? (it.Sel + k - 1) % k : (it.Sel + 1) % k;
                OnChanged(it);
                Beep();
            }
            else if (it.Kind == TItem.NUMBER)
            {
                it.Val = left ? it.Val - it.Step : it.Val + it.Step;
                if (it.Val < it.Min) it.Val = it.Min;
                if (it.Val > it.Max) it.Val = it.Max;
                OnChanged(it);
                Beep();
            }
        }

        // --- conferma ---
        if (Pressed(C_ACCEPT) || Game.IsKeyPressed(Keys.NumPad5))
        {
            if (it.Kind == TItem.SUB && it.Sub >= 0)
            {
                if (it.Id == 240)
                {
                    BuildModShop();
                }
                cur = it.Sub;
                menus[cur].Sel = FirstSelectable(cur);
                menus[cur].Top = 0;
            }
            else if (it.Kind == TItem.TOGGLE)
            {
                it.On = !it.On;
                OnChanged(it);
            }
            else if (it.Kind == TItem.ACTION || it.Kind == TItem.LIST)
            {
                DoAction(it);
            }
            Beep();
        }
    }

    void Beep()
    {
        Function.Call(Hash.PLAY_SOUND_FRONTEND, -1, "NAV_UP_DOWN", "HUD_FRONTEND_DEFAULT_SOUNDSET", true);
    }

    // ============================================================
    //  disegno
    // ============================================================
    // barra di stato: sempre a schermo, anche a menu chiuso
    void DrawHeader(float x, float y, float w)
    {
        DrawRect(x, y, w, HEAD_H, 0, 0, 0, 185);

        int hh = Function.Call<int>(Hash.GET_CLOCK_HOURS);
        int mm = Function.Call<int>(Hash.GET_CLOCK_MINUTES);
        int dw = Function.Call<int>(Hash.GET_CLOCK_DAY_OF_WEEK);
        if (dw < 0 || dw > 6) dw = 0;

        string left = hh.ToString("00") + ":" + mm.ToString("00") + "  " + (lang == 1 ? DAYS_IT[dw] : DAYS_EN[dw]);
        DrawText(left, x + 9f, y + 3f, 0.25f, Color.FromArgb(255, 235, 235, 240));

        DrawTextRight("$" + Game.Player.Money.ToString("N0", CultureInfo.InvariantCulture),
                      x + w - 9f, y + 3f, 0.25f, Color.FromArgb(255, 130, 225, 180));
    }

    void DrawBar(float px, float pw, float y, float lH, string label, float pct,
                 int gr, int gg, int gb)
    {
        DrawBar(px, pw, y, lH, label, pct, gr, gg, gb, Color.FromArgb(255, 205, 205, 220));
    }

    void DrawBar(float px, float pw, float y, float lH, string label, float pct,
                 int gr, int gg, int gb, Color labCol)
    {
        DrawRect(px, y, pw, lH, 0, 0, 0, 150);

        float f01 = pct / 100f;
        if (f01 < 0f) f01 = 0f;
        if (f01 > 1f) f01 = 1f;

        int br = gr, bg = gg, bb = gb;
        if (f01 < 0.2f) { br = 245; bg = 145; bb = 165; }  // rosa tenue di allarme

        float barX = px + 56f;
        float barW = pw - 90f;
        float barY = y + (lH - 4f) * 0.5f;

        DrawRect(barX, barY, barW, 4f, 255, 255, 255, 30);              // binario
        DrawRect(barX, barY, barW * f01, 4f, br, bg, bb, 245);          // riempimento
        DrawRect(barX, barY + 4f, barW * f01, 1f, br, bg, bb, 90);      // riflesso sotto

        DrawText(label, px + 6f, y + 0.5f, 0.20f, labCol);
        DrawTextRight(((int)pct) + "%", px + pw - 5f, y + 0.5f, 0.20f, Color.FromArgb(255, br, bg, bb));
    }

    void DrawSpeedo()
    {
        if (open) return;

        Ped p = Game.Player.Character;
        if (p == null || !p.Exists()) return;

        Vehicle v = p.CurrentVehicle;
        if (v == null || !v.Exists()) return;

        int kmh = (int)(Function.Call<float>(Hash.GET_ENTITY_SPEED, v) * 3.6f);

        Color c = Color.FromArgb(255, 255, 255, 255);   // il numero resta sempre bianco

        // e' lo sfondo a diventare rosso quando corri troppo
        int bgR = 0, bgG = 0, bgB = 0, bgA = 115;
        {
            int limit = SpeedLimitNow();
            if (kmh > limit + SPEED_MARGIN)
            {
                bgR = 175; bgG = 25; bgB = 25; bgA = 210;
            }
            else if (kmh > limit)
            {
                bgR = 140; bgG = 40; bgB = 40; bgA = 180;
            }
        }
        // il cruscotto c'e' sempre: gli interruttori decidono solo se
        // la benzina cala davvero e se scatta la multa
        bool limitOn = true;

        float ry = 646f;
        float bw = 44f;
        float gap = 6f;

        float groupW = limitOn ? (bw * 2f + gap) : bw;
        float gx0 = 640f - groupW * 0.5f;

        // ============================================================
        //  CRUSCOTTO: lo sfondo e' il tuo PNG, disegnato come sprite.
        //  Proporzioni originali 1517x663, cioe' 2.288 a 1: si mantiene
        //  quel rapporto per non deformarlo.
        // ============================================================
        float cH = 150f;          // altezza voluta
        float cW = cH * 2.288f;   // larghezza di conseguenza (1517x663)
        float cX = 640f;                     // centro schermo
        float cY = 720f - cH * 0.5f - 4f;    // appoggiato al bordo basso

        // PROVA 2: si chiede la texture ma NON si disegna. Se non crasha,
        // il problema e' il disegno; se crasha, e' il caricamento.
        // Sfondo del cruscotto: texture installata nel gioco (cruscotto.ytd).
        // La disegna il gioco, quindi tutto quello che viene dopo ci va SOPRA.
        // Sfondo del cruscotto dal .ytd installato nel gioco
        // Sfondo del cruscotto: texture dentro cruscotto.ytd, installata nel
        // gioco. La disegna il gioco, quindi navigatore e numeri ci vanno
        // SOPRA. Il .ytd va creato in formato Enhanced (Resource Version 5):
        // OpenIV e CodeWalker 46 scrivono la 13 e il gioco crasha.
        Function.Call(Hash.REQUEST_STREAMED_TEXTURE_DICT, "cruscotto", false);
        if (Function.Call<bool>(Hash.HAS_STREAMED_TEXTURE_DICT_LOADED, "cruscotto"))
        {
            string tex = v.AreLightsOn ? "cruscotto_night" : "cruscotto2";

            Function.Call(Hash.DRAW_SPRITE, "cruscotto", tex,
                          cX / 1280f, cY / 720f, cW / 1280f, cH / 720f,
                          0f, 255, 255, 255, 255, false);
        }

        // riferimenti della scocca, per posizionare tutto il resto:
        //   bordo sinistro  cX - cW/2       bordo destro  cX + cW/2
        //   bordo alto      cY - cH/2       bordo basso   cY + cH/2
        float cTop = cY - cH * 0.5f;
        float cLeft = cX - cW * 0.5f;

        // ---- spie, dalle texture dentro cruscotto.ytd ----
        // Disegnate dal gioco come lo sfondo, quindi restano sullo stesso
        // piano e l'ordine lo decide il codice.
        {
            int now2 = Game.GameTime;
            if (now2 > lightsNext)
            {
                lightsNext = now2 + 250;
                lightsLatched = v.AreLightsOn;
                beamsLatched = v.AreHighBeamsOn;
            }

            float isz = 16f;          // lato di ogni spia
            float iszP = 13f;         // benzina
            float iszF = 11f;         // fari e abbaglianti
            float iszL = 11f;         // limitatore
            float iszM = 11f;         // spia motore
            float igap = 16f;         // distanza fra una spia e l'altra
            float iy = cTop + 17f;    // quanto sotto il bordo alto
            float ix = cX - igap * 2f + 3f;   // cinque spie, equidistanti

            DrawTex(lightsLatched ? "fari_on" : "fari_off", ix, iy, iszF);
            ix = ix + igap;

            DrawTex(beamsLatched ? "abb_on" : "abb_off", ix, iy, iszF);
            ix = ix + igap;

            float engH = Function.Call<float>(Hash.GET_VEHICLE_ENGINE_HEALTH, v);
            float bodH = Function.Call<float>(Hash.GET_VEHICLE_BODY_HEALTH, v);
            bool mortaH = (engH <= 0f || bodH <= 0f || v.IsDead);
            bool acceso = Function.Call<bool>(Hash.GET_IS_VEHICLE_ENGINE_RUNNING, v);

            if (evCurrent)
            {
                // elettrica: accesa quando e' in funzione
                DrawTex((acceso && !mortaH) ? "elettric_on" : "elettric_off", ix, iy, isz);
            }
            else if (IsHybrid(v))
            {
                // ibrida: fino a 60 km/h va il solo elettrico (ECO verde);
                // sopra i 60 entra il termico e ci resta finche' non ti fermi
                float hyKmh = Function.Call<float>(Hash.GET_ENTITY_SPEED, v) * 3.6f;
                if (hyKmh > 60f) hyHot = true;
                else if (hyKmh <= 20f) hyHot = false;

                if (!acceso || mortaH)
                    DrawTex("eco_off", ix, iy, isz);
                else if (hyHot)
                    DrawTex("eco_off", ix, iy, isz);
                else
                    DrawTex("eco_on", ix, iy, isz);
            }
            else
            {
                // benzina: spia motore accesa a motore FERMO, guasto,
                // oppure con la salute del motore sotto il 70%
                DrawTex((!acceso || engH < 700f || mortaH) ? "motore_on" : "motore_off",
                        ix, iy, iszM);
            }
            ix = ix + igap;

            // batteria: accesa a motore spento, spenta a motore acceso
            DrawTex((!acceso || mortaH) ? "batteria_on" : "batteria_off", ix, iy, iszM);
            ix = ix + igap;

            // carburante: si accende in riserva
            bool riserva = (fuel < 15f);
            if (evCurrent)
            {
                DrawTex(riserva ? "energia_on" : "energia_off", ix, iy, iszP);
            }
            else
            {
                DrawTex(riserva ? "benzina_on" : "benzina_off", ix, iy, iszP - 4f);
            }

        }


        // ------------------------------------------------------------
        // Il vecchio contenuto (quadrati, colonnine, spie, odometro) resta
        // nelle sue funzioni ma non viene piu' disegnato: la scocca va
        // riempita da capo, elemento per elemento. Per riaccenderlo basta
        // rimettere le tre chiamate qui sotto.
        //   DrawFuelStrip(v, gx0, groupW, ry);
        //   DrawLightsIndicator(v, gx0, groupW, ry);
        // ------------------------------------------------------------

        // ---- numero velocita' a sinistra, percentuale a destra ----
        {
            Color cNum = Color.FromArgb(255, 255, 255, 255);
            int spd = UseMiles() ? (int)(kmh * 0.621371f) : kmh;
            DrawTextCenter(spd.ToString(), cX - cW * 0.28f - 3f, cY - 14f, 0.50f, cNum);

            int pct = (int)fuel;
            if (pct < 0) pct = 0;
            if (pct > 100) pct = 100;
            DrawTextCenter(pct.ToString(), cX + cW * 0.28f + 6f, cY - 14f, 0.50f, cNum);

            // chiave inglese: tagliando da fare o carrozzeria sotto l'80%,
            // a destra del numero della velocita'
            float bodyPct = Function.Call<float>(Hash.GET_VEHICLE_BODY_HEALTH, v) / 10f;
            float engPct = Function.Call<float>(Hash.GET_VEHICLE_ENGINE_HEALTH, v) / 10f;
            float tankPct = Function.Call<float>(Hash.GET_VEHICLE_PETROL_TANK_HEALTH, v) / 10f;
            bool serve = (oil < 15f) || (bodyPct < 85f)
                         || (engPct < 85f) || (tankPct < 85f);
            {
                float wX = cX + cW * 0.28f + 6f + 26f;
                float wY = cY + 0f;
                float wS = 10f;
                // quando serve il tagliando respira: si accende e si spegne
                int wA = 255;
                if (serve)
                {
                    float t = (Game.GameTime % 1600) / 1600f;
                    float k = 0.5f - 0.5f * (float)Math.Cos(t * 6.28318f);
                    wA = (int)(80f + 175f * k);
                }

                Function.Call(Hash.DRAW_SPRITE, "cruscotto",
                              serve ? "wrench" : "wrench_off",
                              wX / 1280f, wY / 720f, wS / 1280f, wS / 720f,
                              -20f, 255, 255, 255, wA, false);
            }

            // gomme: a sinistra del numero della benzina
            bool gommaKo = false;
            int[] wIdx = new int[] { 0, 1, 4, 5 };
            int wI;
            for (wI = 0; wI < wIdx.Length; wI++)
            {
                if (Function.Call<bool>(Hash.IS_VEHICLE_TYRE_BURST, v, wIdx[wI], false)
                    || Function.Call<bool>(Hash.IS_VEHICLE_TYRE_BURST, v, wIdx[wI], true))
                {
                    gommaKo = true;
                    break;
                }
            }
            DrawTex(gommaKo ? "tyres_on" : "tyres_off",
                    cX + cW * 0.28f + 6f - 26f, cY + 0f, 11f);

            // frecce, ai margini della fila delle spie
            float frW = 10f;
            float frY = cTop + 16f;          // stessa altezza delle spie
            float frDx = 45f;                // quanto lontano dal centro

            // quattro frecce: in retromarcia, oppure da fermo con il motore
            // acceso da piu' di 30 secondi
            {
                int nowF = Game.GameTime;
                bool motoreOn = Function.Call<bool>(Hash.GET_IS_VEHICLE_ENGINE_RUNNING, v);
                float spdF = Function.Call<float>(Hash.GET_ENTITY_SPEED, v);
                bool retro = (v.CurrentGear <= 0);

                if (spdF > 0.5f || !motoreOn) fermoDa = nowF;

                // sirena accesa (polizia, ambulanza, pompieri): quattro frecce
                bool sirena = Function.Call<bool>(Hash.IS_VEHICLE_SIREN_ON, v);

                bool haz = motoreOn &&
                           (retro || sirena || (nowF - fermoDa > 30000));

                bool fase = haz && ((nowF % 1000) < 500);

                if (haz)
                {
                    Function.Call(Hash.SET_VEHICLE_INDICATOR_LIGHTS, v, 0, fase);
                    Function.Call(Hash.SET_VEHICLE_INDICATOR_LIGHTS, v, 1, fase);
                }
                else
                {
                    // freccia automatica: si accende quando sterzi abbastanza
                    float sterzo = v.SteeringAngle;   // gradi, + a sinistra
                    bool blink = ((nowF % 1000) < 500);

                    // resta accesa altri due secondi dopo che hai raddrizzato
                    // sterzando dall'altra parte, quella opposta si spegne subito
                    if (sterzo > 22f) { frecciaSxFino = nowF + 2000; frecciaDxFino = 0; }
                    if (sterzo < -22f) { frecciaDxFino = nowF + 2000; frecciaSxFino = 0; }

                    bool sx = (nowF < frecciaSxFino);
                    bool dx = (nowF < frecciaDxFino);

                    Function.Call(Hash.SET_VEHICLE_INDICATOR_LIGHTS, v, 1, sx && blink);
                    Function.Call(Hash.SET_VEHICLE_INDICATOR_LIGHTS, v, 0, dx && blink);
                }
            }

            DrawTex(v.IsLeftIndicatorLightOn ? "freccia_sx" : "freccia_sx_off",
                    cX - frDx, frY, frW);
            DrawTex(v.IsRightIndicatorLightOn ? "freccia_dx" : "freccia_dx_off",
                    cX + frDx + 5f, frY, frW);

            // porte: sopra il numero della benzina
            bool aperta = false;
            int dI;
            for (dI = 0; dI < 6; dI++)
            {
                if (Function.Call<float>(Hash.GET_VEHICLE_DOOR_ANGLE_RATIO, v, dI) > 0.02f)
                {
                    aperta = true;
                    break;
                }
            }
            DrawTex(aperta ? "doors_open" : "doors_closed",
                    cX + cW * 0.28f + 6f, cY - 22f, 16f);

            // limitatore di velocita', sopra il numero della velocita'
            bool limAcceso = (tLimiter != null && tLimiter.On);
            DrawTex(limAcceso ? "limiter_on" : "limiter_off",
                    cX - cW * 0.28f - 3f, cY - 22f, 13f);

            // etichette piccole sotto i due numeri
            DrawTextCenter(UseMiles() ? "mph" : "km/h",
                           cX - cW * 0.28f - 3f, cY + 10f, 0.15f, cNum);
            DrawTextCenter(evCurrent ? L("energy", "energia") : L("fuel", "benzina"),
                           cX + cW * 0.28f + 6f, cY + 10f, 0.15f, cNum);

            // autonomia residua, sotto la scritta: arancione a benzina,
            // verde in elettrico
            float autKm;
            Color autCol;
            if (evCurrent)
            {
                autKm = fuel / 100f * 120f;
                autCol = Color.FromArgb(255, 90, 220, 120);
            }
            else if (IsHybrid(v))
            {
                autKm = fuel / 100f * 95f;
                autCol = Color.FromArgb(255, 255, 160, 60);
            }
            else
            {
                autKm = fuel / 100f * 70f;
                autCol = Color.FromArgb(255, 255, 160, 60);
            }

            // GUIDA DI POSIZIONAMENTO: gli archi su cui gireranno le lancette.
            // raggio e angoli si cambiano qui.
            // archi di riferimento spenti: per rivederli togli le //
            // DrawArc(cX - cW * 0.28f - 3f, cY + 2f, 40f, -130f, 130f, 100f, 2f,
            //         Color.FromArgb(255, 0, 255, 255), Color.FromArgb(90, 255, 255, 255));
            // DrawArc(cX + cW * 0.28f + 6f, cY + 2f, 40f, -130f, 130f, 100f, 2f,
            //         Color.FromArgb(255, 0, 255, 255), Color.FromArgb(90, 255, 255, 255));

            // lancette: girano da -130 a +130 gradi (0 = ore 12)
            // col cruscotto night (fari accesi) verde pastello, altrimenti bianca
            Color ndW = v.AreLightsOn
                        ? Color.FromArgb(255, 150, 230, 170)
                        : Color.FromArgb(255, 255, 255, 255);
            Color ndF = autCol;
            DrawNeedle(cX - cW * 0.28f - 3f, cY + 2f, 36f, 46f,
                       -130f + 260f * Clamp01(kmh / 285f), 1.2f, ndW);
            DrawNeedle(cX + cW * 0.28f + 6f, cY + 2f, 36f, 46f,
                       -130f + 260f * Clamp01(fuel / 100f), 1.2f, ndF);

            string autTxt = UseMiles()
                            ? (((int)(autKm * 0.621371f)) + " mi")
                            : (((int)autKm) + " km");
            DrawTextCenter(autTxt, cX + cW * 0.28f + 6f, cY + 18f, 0.17f, autCol);
        }

        // ---- odometro: sempre visibile, non dipende dal navigatore ----
        {
            int odoN = UseMiles() ? (int)(odoM / 1609.344f) : (int)(odoM / 1000f);
            if (odoN < 0) odoN = 0;
            if (odoN > 999999) odoN = 999999;
            // decimo di km (o di miglio): la cifra rossa dell'odometro
            float odoUnit = UseMiles() ? (odoM / 1609.344f) : (odoM / 1000f);
            int odoDec = (int)((odoUnit - (float)odoN) * 10f);
            if (odoDec < 0) odoDec = 0;
            if (odoDec > 9) odoDec = 9;

            string odoInt = odoN.ToString("000000", CultureInfo.InvariantCulture);
            string odoSuf = UseMiles() ? " mi" : " km";
            float odoY = cTop + 45.5f;
            float odoX = cX + 38f;
            float odoS = 0.17f;

            Color odoW = Color.FromArgb(255, 255, 255, 255);
            Color odoR = Color.FromArgb(255, 255, 90, 90);

            float wSuf = TextWidth(odoSuf, odoS);

            // sfondo scuro semitrasparente, stretto attorno al testo
            float wTot = TextWidth(odoInt + odoDec.ToString() + odoSuf, odoS);
            DrawRect(odoX - wTot - 2f, odoY + 1f, wTot + 4f, 7f, 0, 0, 0, 89);

            // le sette cifre sono un unico testo, cosi' restano attaccate;
            // l'ultima si ridisegna sopra in rosso, nello stesso punto
            // giorno della settimana in tre lettere e orario, sopra l'odometro
            int gDow = Function.Call<int>(Hash.GET_CLOCK_DAY_OF_WEEK);
            int gH = Function.Call<int>(Hash.GET_CLOCK_HOURS);
            int gM = Function.Call<int>(Hash.GET_CLOCK_MINUTES);
            if (gDow < 0) gDow = 0;
            if (gDow > 6) gDow = 6;

            // 0 = domenica
            string[] gg = L("SUN MON TUE WED THU FRI SAT",
                            "DOM LUN MAR MER GIO VEN SAB").Split(' ');

            string dtTxt = gg[gDow] + "   "
                           + gH.ToString("00", CultureInfo.InvariantCulture) + ":"
                           + gM.ToString("00", CultureInfo.InvariantCulture);
            // sotto il cerchio della benzina, in fondo al quadrante destro
            DrawTextCenter(dtTxt, cX + cW * 0.28f + 6f, cY + 41f, odoS,
                           Color.FromArgb(204, 255, 255, 255));

            DrawTextRight(odoSuf, odoX, odoY, odoS, odoW);
            DrawTextRight(odoInt + odoDec.ToString(), odoX - wSuf, odoY, odoS, odoW);
            DrawTextRight(odoDec.ToString(), odoX - wSuf, odoY, odoS, odoR);
        }

        // ---- nome della strada, 4 px sotto il navigatore ----
        {
            Vector3 mp = p.Position;
            OutputArgument sh = new OutputArgument();
            OutputArgument ch = new OutputArgument();
            Function.Call(Hash.GET_STREET_NAME_AT_COORD, mp.X, mp.Y, mp.Z, sh, ch);
            string via = Function.Call<string>(Hash.GET_STREET_NAME_FROM_HASH_KEY,
                                               sh.GetResult<int>());
            if (via != null && via.Length > 0)
            {
                DrawTextCenter(via, cX, cTop + 90f, 0.17f,
                               Color.FromArgb(230, 255, 255, 255));
            }
        }

        // ---- radio: nome della stazione, sotto il navigatore ----
        {
            string rid = Function.Call<string>(Hash.GET_PLAYER_RADIO_STATION_NAME);
            bool rOn = (rid != null && rid.Length > 0 && rid != "OFF");

            float rdX = cX;
            float rdY = cTop + 126f;

            string rdTxt;
            Color rdCol;
            if (rOn)
            {
                rdTxt = RadioLabel(rid);
                rdCol = PastelFor(rid);
            }
            else
            {
                rdTxt = L("radio off", "radio spenta");
                rdCol = Color.FromArgb(128, 255, 255, 255);
            }
            DrawTextCenter(rdTxt, rdX, rdY, 0.20f, rdCol);
        }

        // ---- marcia ----
        {
            int gr = v.CurrentGear;
            int hi = v.HighGear;

            // un rapporto solo = presa diretta: si mostrano le lettere P R N D
            bool grAuto = (hi <= 1);

            string grTxt;
            if (grAuto)
            {
                if (gr <= 0) grTxt = "R";
                else if (Function.Call<bool>(Hash.GET_IS_VEHICLE_ENGINE_RUNNING, v)) grTxt = "D";
                else grTxt = "P";
            }
            else
            {
                if (gr <= 0) grTxt = "R";
                else grTxt = gr.ToString();
            }

            float grX = cX - cW * 0.28f - 3f;
            float grY = cY + 38f;

            // ai lati la marcia sotto e quella sopra, piu' piccole
            Color grSide = Color.FromArgb(128, 255, 255, 255);

            string grL = "";
            string grR = "";
            if (grAuto)
            {
                // con la presa diretta a sinistra c'e' sempre la folle
                grL = "N";
                if (grTxt == "D") grR = "P";
                else grR = "D";
            }
            else
            {
                // sinistra: la marcia sotto; sotto la prima e in retro la folle
                if (gr <= 1) grL = "N";
                else grL = (gr - 1).ToString();

                // destra: la marcia sopra; in retro a destra c'e' la prima
                if (gr <= 0) grR = "1";
                else if (gr + 1 <= hi) grR = (gr + 1).ToString();
            }

            // la folle e' rossa, la retro giallo ocra, le marce bianche
            Color grRed = Color.FromArgb(grSide.A, 255, 90, 90);

            if (grL.Length > 0)
                DrawTextCenter(grL, grX - 11f, grY + 3f, 0.23f,
                               grL == "N" ? grRed : grSide);
            if (grR.Length > 0)
                DrawTextCenter(grR, grX + 11f, grY + 3f, 0.23f, grSide);

            // sotto la scritta km/h, nell'apertura del semicerchio
            Color grCur;
            if (grTxt == "R") grCur = Color.FromArgb(255, 220, 170, 60);
            else grCur = Color.FromArgb(255, 255, 255, 255);
            DrawTextCenter(grTxt, grX, grY, 0.35f, grCur);
        }

        // ---- limite della strada, cartello bianco ----
        {
            int lim = SpeedLimitNow();
            if (UseMiles()) lim = (int)(lim * 0.621371f);

            float sgX = cX - 24f;           // centro X del cartello
            float sgY = cTop + 45f;         // centro Y del cartello
            float sgR = 11f;                // raggio

            // da quando parte il bip (meta' del tempo prima della multa)
            // il cartello lampeggia
            bool sgBip = (overSince >= 0f &&
                          Game.GameTime - overSince >= (OVER_SECONDS * 1000) / 2);
            // lampeggio: si scambiano sfondo e testo, rosso con scritte bianche
            bool sgInv = (sgBip && (Game.GameTime % 600) < 300);

            if (sgInv)
            {
                DrawRect(sgX - sgR, sgY - sgR, sgR * 2f, sgR * 2f, 200, 30, 30, 255);
                DrawTextCenter(lim.ToString(), sgX, sgY - 11f, 0.29f,
                               Color.FromArgb(255, 255, 255, 255));
                DrawTextCenter(L("LIMIT", "LIMITE"), sgX, sgY + 2f, 0.15f,
                               Color.FromArgb(255, 255, 255, 255));
            }
            else
            {
                // sfondo trasparente, testo bianco
                DrawTextCenter(lim.ToString(), sgX, sgY - 11f, 0.29f,
                               Color.FromArgb(255, 255, 255, 255));
                DrawTextCenter(L("LIMIT", "LIMITE"), sgX, sgY + 2f, 0.15f,
                               Color.FromArgb(255, 255, 255, 255));
            }
        }

        DrawNavPanel(cX, cW, cTop);
    }

    // spia dei fari: un quadratino sotto la barra, a sinistra.
    // Lo stato viene tenuto fermo per qualche decimo di secondo perche'
    // la native lampeggia da sola e faceva sfarfallare la spia.
    bool lightsLatched = false;
    bool beamsLatched = false;
    int lightsNext = 0;

    // Fila delle spie, in alto dentro il pannello:
    //   anabbaglianti | abbaglianti | motore (o ECO) ...... olio/tagliando
    // Le icone hanno gia' la loro versione accesa e spenta: si sceglie il
    // file, non si colora niente.
    void DrawLightsIndicator(Vehicle v, float gx0, float groupW, float ry)
    {
        int now = Game.GameTime;
        if (now > lightsNext)
        {
            lightsNext = now + 250;
            lightsLatched = v.AreLightsOn;
            beamsLatched = v.AreHighBeamsOn;
        }

        float sz = 16f;
        float icy = ry - 15f;
        Color pieno = Color.FromArgb(255, 255, 255, 255);

        DrawIcon(lightsLatched ? "fari_on.png" : "fari_off.png", gx0 + 10f, icy, sz, pieno);
        DrawIcon(beamsLatched ? "abb_on.png" : "abb_off.png", gx0 + 31f, icy, sz, pieno);

        float eng = Function.Call<float>(Hash.GET_VEHICLE_ENGINE_HEALTH, v);
        float bod = Function.Call<float>(Hash.GET_VEHICLE_BODY_HEALTH, v);
        bool morta = (eng <= 0f || bod <= 0f || v.IsDead);

        if (evCurrent)
        {
            // elettrica: la spia ECO e' verde finche' il mezzo e' vivo
            DrawIcon(morta ? "eco_off.png" : "eco_on.png", gx0 + 52f, icy, sz, pieno);
        }
        else
        {
            // benzina: la spia motore si accende quando il motore soffre
            bool warn = (eng < 400f || morta);
            DrawIcon(warn ? "motore_on.png" : "motore_off.png", gx0 + 52f, icy, sz, pieno);
        }

        // tagliando: la spia dell'olio, in fondo a destra
        DrawIcon((oil < 15f) ? "olio_warn.png" : "olio_on.png",
                 gx0 + groupW - 10f, icy, sz, pieno);
    }

    // avviso contromano: riquadro rosso sopra il cruscotto, con i secondi


    // Direzione del punto rispetto al muso del veicolo.
    // Niente bussole: si confronta il vettore "avanti" con quello verso la meta.
    // Punto lungo la ROTTA vera del navigatore, a tot metri da te.
    // Firma trovata a tentativi: (uscita, true, metri, false)
    bool RoutePoint(float meters, out Vector3 result)
    {
        // il primo argomento sceglie il tipo di rotta: waypoint tuo oppure
        // rotta di un blip (come quella dell'Uber). Si provano entrambi.
        OutputArgument o = new OutputArgument();
        bool ok = Function.Call<bool>(Hash.GET_POS_ALONG_GPS_TYPE_ROUTE, o, true, meters, false);
        result = ok ? o.GetResult<Vector3>() : Vector3.Zero;
        if (ok && (result.X != 0f || result.Y != 0f)) return true;

        OutputArgument o2 = new OutputArgument();
        ok = Function.Call<bool>(Hash.GET_POS_ALONG_GPS_TYPE_ROUTE, o2, false, meters, false);
        result = ok ? o2.GetResult<Vector3>() : Vector3.Zero;
        return ok && (result.X != 0f || result.Y != 0f);
    }

    // La prossima svolta lungo la rotta: si campiona la strada in avanti
    // ogni 20 metri fino a 500 e si cerca il primo punto dove piega.
    // Il calcolo e' pesante, quindi si aggiorna 3 volte al secondo.
    string turnCache = "";
    float turnDistCache = 0f;
    float turnClearDist = 0f;   // dritto davanti a te, in metri

    // Curva agganciata: una volta vista, resta quella finche' non l'hai
    // davvero passata. Senza questo, arrivando a ridosso dell'incrocio il
    // navigatore saltava gia' alla svolta successiva e ti mandava fuori.
    bool turnLatched = false;
    Vector3 turnPos = Vector3.Zero;
    string turnDir = "";
    float turnMinDist = 99999f;
    int turnNext = 0;

    string turnPending = "";
    float turnPendingDist = 0f;
    Vector3 turnPendingPos = Vector3.Zero;
    int turnAgree = 0;

    // il nome della via in un punto, come numero: serve solo a confrontare
    int StreetAt(Vector3 pos)
    {
        OutputArgument sh = new OutputArgument();
        OutputArgument ch = new OutputArgument();
        Function.Call(Hash.GET_STREET_NAME_AT_COORD, pos.X, pos.Y, pos.Z, sh, ch);
        return sh.GetResult<int>();
    }

    void ScanTurn()
    {
        int now = Game.GameTime;
        if (now < turnNext) return;
        turnNext = now + 300;

        Ped meP = Game.Player.Character;
        Vector3 mePos = (meP != null && meP.Exists()) ? meP.Position : Vector3.Zero;

        // ---- curva gia' agganciata: si tiene finche' non la passi ----
        if (turnLatched)
        {
            Vector3 dv = turnPos - mePos;
            dv.Z = 0f;
            float dcur = dv.Length();

            if (dcur < turnMinDist) turnMinDist = dcur;

            // l'hai passata quando ti sei avvicinato e poi ti allontani
            bool passata = (turnMinDist < 28f && dcur > turnMinDist + 10f);

            // oppure la rotta e' cambiata del tutto
            if (dcur > 400f) passata = true;

            if (!passata)
            {
                turnCache = turnDir;
                turnDistCache = dcur;
                return;
            }

            turnLatched = false;
            turnCache = "";
            turnDir = "";
        }

        const float STEP = 10f;
        const int STEPS = 70;          // 700 metri

        Vector3[] pts = new Vector3[STEPS + 1];
        int n = 0;
        int i;
        for (i = 0; i <= STEPS; i++)
        {
            Vector3 q;
            if (!RoutePoint(i * STEP + 3f, out q)) break;
            pts[n] = q;
            n++;
        }

        // ---- sei girato dall'altra parte? ----
        // Prima di cercare le svolte: se la rotta parte alle tue spalle,
        // qualunque svolta piu' avanti non conta niente. Devi invertire.
        if (n >= 3 && meP != null && meP.Exists())
        {
            Entity ent = (meP.CurrentVehicle != null && meP.CurrentVehicle.Exists())
                         ? (Entity)meP.CurrentVehicle : (Entity)meP;

            Vector3 fw = ent.ForwardVector;
            Vector3 rt = pts[2] - mePos;
            fw.Z = 0f; rt.Z = 0f;

            float fl2 = fw.Length();
            float rl2 = rt.Length();

            if (fl2 > 0.01f && rl2 > 3f)
            {
                float dotf = (fw.X / fl2) * (rt.X / rl2) + (fw.Y / fl2) * (rt.Y / rl2);
                if (dotf < -0.5f)          // rotta oltre 120 gradi dal muso
                {
                    turnLatched = false;
                    turnCache = L("U-turn", "inversione");
                    turnDistCache = 0f;
                    turnPending = "";
                    turnAgree = 0;
                    return;
                }
            }
        }

        string found = "";
        float foundDist = 0f;
        Vector3 foundPos = Vector3.Zero;

        // quanto in la' si e' riusciti a guardare: se non c'e' nessuna
        // svolta, e' la lunghezza del dritto che hai davanti
        turnClearDist = (n > 0) ? ((n - 1) * STEP) : 0f;

        // si confrontano due tratti LUNGHI 40 metri, distanti fra loro:
        // le sterzate dentro la corsia non li muovono, una svolta si'
        if (n >= 12)
        {
            for (i = 4; i < n - 8; i++)
            {
                float ax = pts[i].X - pts[i - 4].X;
                float ay = pts[i].Y - pts[i - 4].Y;
                float bx = pts[i + 8].X - pts[i + 4].X;
                float by = pts[i + 8].Y - pts[i + 4].Y;

                float al = (float)Math.Sqrt(ax * ax + ay * ay);
                float bl = (float)Math.Sqrt(bx * bx + by * by);
                if (al < 5f || bl < 5f) continue;

                ax /= al; ay /= al;
                bx /= bl; by /= bl;

                float dot = ax * bx + ay * by;
                float cross = ax * by - ay * bx;
                float ang = (float)(Math.Atan2(cross, dot) * 180.0 / Math.PI);

                // L'angolo da solo non basta: una strada tutta curve piega
                // di brutto senza che tu debba svoltare da nessuna parte.
                // Un navigatore vero annuncia una svolta solo quando CAMBI
                // STRADA. Quindi si guarda il nome della via prima e dopo:
                // se e' lo stesso, e' solo una curva della stessa strada.
                if (ang < 150f && ang > -150f)
                {
                    if (StreetAt(pts[i - 3]) == StreetAt(pts[i + 3])) continue;
                }

                if (ang > 150f || ang < -150f) found = L("U-turn", "inversione");
                else if (ang > 45f) found = L("left", "sinistra");
                else if (ang < -45f) found = L("right", "destra");
                else continue;

                foundDist = i * STEP;
                foundPos = pts[i];
                break;
            }
        }

        // stabilita': una svolta nuova deve confermarsi due volte di fila
        // prima di comparire, cosi' non lampeggia a ogni sterzata
        if (found == turnCache)
        {
            turnAgree = 0;
            if (found.Length > 0)
            {
                turnDistCache = foundDist;
                if (!turnLatched && foundPos.X != 0f)
                {
                    turnLatched = true;
                    turnPos = foundPos;
                    turnDir = found;
                    turnMinDist = 99999f;
                }
            }
            return;
        }

        if (found == turnPending)
        {
            turnAgree++;
        }
        else
        {
            turnPending = found;
            turnPendingDist = foundDist;
            turnPendingPos = foundPos;
            turnAgree = 1;
            return;
        }

        if (turnAgree >= 2)
        {
            turnCache = turnPending;
            turnDistCache = foundDist;
            turnAgree = 0;

            // da qui in poi quella curva e' "sua": la si segue col punto
            // sulla mappa, non ricalcolandola a ogni giro
            if (turnCache.Length > 0 && turnPendingPos.X != 0f)
            {
                turnLatched = true;
                turnPos = turnPendingPos;
                turnDir = turnCache;
                turnMinDist = 99999f;
            }
        }
    }

    string DirectionTo(Vector3 target)
    {
        Ped p = Game.Player.Character;
        Entity e = (p.CurrentVehicle != null && p.CurrentVehicle.Exists())
                   ? (Entity)p.CurrentVehicle : (Entity)p;

        Vector3 f = e.ForwardVector;
        Vector3 d = target - e.Position;

        float fl = (float)Math.Sqrt(f.X * f.X + f.Y * f.Y);
        float dl = (float)Math.Sqrt(d.X * d.X + d.Y * d.Y);
        if (fl < 0.001f || dl < 0.001f) return L("ahead", "dritto");

        float fx = f.X / fl, fy = f.Y / fl;
        float dx = d.X / dl, dy = d.Y / dl;

        float dot = fx * dx + fy * dy;            // 1 = davanti, -1 = dietro
        float cross = fx * dy - fy * dx;          // segno = da che lato

        float ang = (float)(Math.Atan2(cross, dot) * 180.0 / Math.PI);

        if (ang > 135f || ang < -135f) return L("U-turn", "inversione");
        if (ang > 30f) return L("left", "sinistra");
        if (ang < -30f) return L("right", "destra");
        return L("ahead", "dritto");
    }

    float navDist = 0f;
    int navDistNext = 0;

    // colore del blip -> colore del testo, come lo vedi sulla mappa
    Color BlipColour(int c)
    {
        if (c == 1) return Color.FromArgb(255, 224, 80, 80);      // rosso
        if (c == 2) return Color.FromArgb(255, 120, 215, 130);    // verde
        if (c == 3) return Color.FromArgb(255, 110, 185, 235);    // blu
        if (c == 5) return Color.FromArgb(255, 245, 215, 100);    // giallo
        if (c == 17) return Color.FromArgb(255, 245, 175, 110);   // arancio
        if (c == 27 || c == 48) return Color.FromArgb(255, 245, 130, 205); // rosa
        if (c == 83 || c == 84) return Color.FromArgb(255, 245, 130, 205);
        return Color.FromArgb(255, 235, 235, 240);
    }

    // cerca un blip vero su quel punto e ne prende il colore
    Color ColourAtPoint(Vector3 p)
    {
        int[] sprites = new int[] { 280, 1, 225, 358, 361 };
        int si;
        for (si = 0; si < sprites.Length; si++)
        {
            int b = Function.Call<int>(Hash.GET_FIRST_BLIP_INFO_ID, sprites[si]);
            int guard = 0;
            while (Function.Call<bool>(Hash.DOES_BLIP_EXIST, b) && guard < 40)
            {
                guard++;
                Vector3 c = Function.Call<Vector3>(Hash.GET_BLIP_INFO_ID_COORD, b);
                Vector3 d = c - p;
                d.Z = 0f;
                if (d.Length() < 40f)
                {
                    return BlipColour(Function.Call<int>(Hash.GET_BLIP_COLOUR, b));
                }
                b = Function.Call<int>(Hash.GET_NEXT_BLIP_INFO_ID, sprites[si]);
            }
        }

        // nessun blip li': e' un waypoint tuo, rosa come lo disegna il gioco
        return Color.FromArgb(255, 245, 130, 205);
    }

    // Navigatore: segue il waypoint che metti tu sulla mappa.
    void DrawNavPanel(float gx0, float groupW, float ry)
    {
        Ped p = Game.Player.Character;

        bool have = false;
        Vector3 tgt = Vector3.Zero;
        Color col = Color.FromArgb(255, 235, 235, 240);

        // 2. il waypoint: l'unica rotta di cui il gioco ci dice anche le svolte
        if (!have)
        {
            int b = Function.Call<int>(Hash.GET_FIRST_BLIP_INFO_ID, 8);
            if (Function.Call<bool>(Hash.DOES_BLIP_EXIST, b))
            {
                have = true;
                tgt = Function.Call<Vector3>(Hash.GET_BLIP_INFO_ID_COORD, b);

                // il colore non e' fisso: e' quello del blip che sta su quel
                // punto. Giallo mentre vai a prendere, verde verso la meta,
                // rosa se e' solo un waypoint tuo.
                col = ColourAtPoint(tgt);
            }
        }

        if (!have) return;

        // testo del navigatore sempre bianco
        col = Color.FromArgb(255, 255, 255, 255);

        int now = Game.GameTime;
        if (now > navDistNext)
        {
            navDistNext = now + 500;
            Vector3 me2 = p.Position;
            navDist = Function.Call<float>(Hash.CALCULATE_TRAVEL_DISTANCE_BETWEEN_POINTS,
                                           me2.X, me2.Y, me2.Z, tgt.X, tgt.Y, tgt.Z);
        }

        float dm = navDist;
        if (dm <= 0f) dm = (tgt - p.Position).Length();

        string dtxt;
        if (UseMiles())
        {
            float mi = dm / 1609.344f;
            if (mi >= 1f) dtxt = mi.ToString("0.00", CultureInfo.InvariantCulture) + " mi";
            else dtxt = ((int)(dm * 1.09361f)) + " yd";
        }
        else
        {
            if (dm >= 1000f) dtxt = (dm / 1000f).ToString("0.00", CultureInfo.InvariantCulture) + " km";
            else dtxt = ((int)dm) + " m";
        }

        // Navigatore: comanda la prossima svolta. La freccia grande e i
        // metri grandi dicono quando gira; la distanza alla meta' resta
        // piccola nella riga di intestazione, che serve solo a inquadrare.
        // dentro la scocca, al centro: 'gx0' qui e' il centro X del cruscotto
        // e 'groupW' la sua larghezza (vedi la chiamata in DrawHud)
        float w = 82f;
        float x = gx0 - w * 0.5f;
        float hHead = 16f;
        float hBig = 34f;
        float y = ry + 66f;              // sotto la fila delle spie

        ScanTurn();

        // ---- riga di intestazione: la meta' ----
        DrawTextRight(dtxt, x + w - 3f, y - 6.5f, 0.21f, col);
        y = y + hHead;

        // ---- riga grande: freccia e metri alla svolta ----
        string arrow = "dritto.png";
        if (turnCache.Length > 0)
        {
            string lc = turnCache.ToLower();
            if (lc == "sinistra" || lc == "left") arrow = "sinistra.png";
            else if (lc == "destra" || lc == "right") arrow = "destra.png";
            else arrow = "inversione.png";
        }

        // (il disegno vero avviene sotto, dopo aver deciso quale freccia)

        // quanto manca alla svolta: e' questo il numero che guardi guidando
        // La svolta si annuncia solo quando sei vicino: oltre gli 80 metri
        // resta la freccia dritta, come fa il navigatore del gioco.
        // I metri sono sempre quelli della prossima svolta e scendono mentre
        // ti avvicini. La freccia della direzione compare invece solo negli
        // ultimi 80 metri: prima resta dritta, come fa il navigatore del gioco.
        bool svoltaVicina = (turnCache.Length > 0 && turnDistCache <= 80f);
        string arrow2 = svoltaVicina ? arrow : "dritto.png";

        float td = (turnCache.Length > 0) ? turnDistCache : turnClearDist;
        string tt = UseMiles()
                    ? (((int)(td * 1.09361f)) + " yd")
                    : (((int)td) + " m");
        DrawIcon(arrow2, x + 20f, y + hBig * 0.5f - 21f, 22f,
                 Color.FromArgb(255, 245, 245, 250));

        DrawTextRight(tt, x + w - 4f, y - 10f, 0.32f, col);

    }



    // Due colonnine verticali ai lati dei quadrati, alte quanto loro:
    // a sinistra il carburante (arancione) o la batteria (verde pastello),
    // a destra l'olio motore. Si riempiono dal basso come i livelli veri.
    // disegna un PNG della cartella icone, colorato come vogliamo noi.
    // Al primo errore si spengono tutte: meglio senza icone che senza gioco.
    // disegna una texture del nostro dizionario cruscotto.ytd,
    // quadrata, centrata sul punto dato (coordinate 1280x720)
    // true quando nel menu veicolo e' scelto mph
    bool UseMiles()
    {
        return (tUnits != null && tUnits.Sel == 1);
    }

    void DrawTex(string name, float cx, float cy, float size)
    {
        Function.Call(Hash.DRAW_SPRITE, "cruscotto", name,
                      cx / 1280f, cy / 720f, size / 1280f, size / 720f,
                      0f, 255, 255, 255, 255, false);
    }

    void DrawIcon(string file, float cx, float cy, float size, Color col)
    {
        DrawIcon(file, cx, cy, size, col, size, size);
    }

    void DrawIcon(string file, float cx, float cy, float size, Color col, float w, float h)
    {
        if (!iconsOk) return;

        try
        {
            string path = Path.Combine(DATA_DIR, "icone\\" + file);
            if (!File.Exists(path))
            {
                if (!iconsTried)
                {
                    iconsTried = true;
                    Notification.PostTicker("~y~" + L("Icon not found", "Icona non trovata")
                        + ":~s~ " + file, false);
                }
                return;
            }

            CustomSprite sp = new CustomSprite(path,
                new SizeF(w, h),
                new PointF(cx - w * 0.5f, cy - h * 0.5f),
                col);
            sp.Draw();
        }
        catch (Exception)
        {
            iconsOk = false;
        }
    }

    void DrawFuelStrip(Vehicle v, float gx0, float groupW, float ry)
    {
        float bh = 40f;         // stessa altezza dei quadrati
        float bwv = 6f;         // spessore della colonnina
        float top = ry - 4f;

        float f01 = fuel / 100f;
        if (f01 < 0f) f01 = 0f;
        if (f01 > 1f) f01 = 1f;

        // ---- sinistra: carburante o batteria ----
        float lxv = gx0 - bwv - 4f;

        DrawRect(lxv, top, bwv, bh, 0, 0, 0, 150);

        // icona ai piedi della colonnina: si accende quando sei in riserva
        Color pieno2 = Color.FromArgb(255, 255, 255, 255);
        if (evCurrent)
        {
            DrawIcon((f01 < 0.15f) ? "batteria_on.png" : "batteria_off.png",
                     lxv + bwv * 0.5f, top + bh + 10f, 14f, pieno2);
        }
        else
        {
            DrawIcon((f01 < 0.15f) ? "benzina_on.png" : "benzina_off.png",
                     lxv + bwv * 0.5f, top + bh + 10f, 14f, pieno2);
        }
        if (evCurrent)
        {
            DrawRect(lxv, top + bh * (1f - f01), bwv, bh * f01, 165, 225, 185, 245);
        }
        else
        {
            int r = 235, g = 165, b = 60;                        // arancione: benzina
            if (f01 < 0.12f) { r = 245; g = 120; b = 120; }      // riserva: rosso
            DrawRect(lxv, top + bh * (1f - f01), bwv, bh * f01, r, g, b, 245);
        }

        // ---- destra: olio motore ----
        // ---- odometro, sotto i quadrati ----
        // Solo i chilometri di questo veicolo, centrati. Il tagliando lo
        // ricordano le notifiche, non una scritta fissa sul cruscotto.
        // niente fondo: solo i chilometri, con il contorno per leggerli
        // anche sull'asfalto chiaro
        float oy = ry + 40f;
        int km = (int)(odoM / 1000f);
        DrawTextCenterOutline(km.ToString() + " km", gx0 + groupW * 0.5f, oy, 0.26f,
                              Color.FromArgb(255, 240, 240, 245));

        float rxv = gx0 + groupW + 4f;

        // ---- destra: la vita del veicolo ----
        // Non piu' l'olio (il tagliando lo dicono la chiave e le notifiche):
        // qui c'e' quanto e' malmesso il mezzo, carrozzeria e motore insieme.
        float eng = Function.Call<float>(Hash.GET_VEHICLE_ENGINE_HEALTH, v) / 1000f;
        float bod = Function.Call<float>(Hash.GET_VEHICLE_BODY_HEALTH, v) / 1000f;
        float h01 = (eng < bod) ? eng : bod;
        if (h01 < 0f) h01 = 0f;
        if (h01 > 1f) h01 = 1f;

        DrawRect(rxv, top, bwv, bh, 0, 0, 0, 150);

        DrawIcon("cuore.png", rxv + bwv * 0.5f, top + bh + 10f, 13f,
                 (h01 < 0.2f) ? Color.FromArgb(255, 245, 120, 120)
                              : Color.FromArgb(255, 120, 190, 245));

        int hr = 90, hg = 175, hb = 245;                     // blu
        if (h01 < 0.2f) { hr = 245; hg = 120; hb = 120; }
        else if (h01 < 0.45f) { hr = 250; hg = 210; hb = 130; }
        DrawRect(rxv, top + bh * (1f - h01), bwv, bh * h01, hr, hg, hb, 245);
    }

    void DrawStatusPanel()
    {
        if (open) return;   // a menu aperto sparisce, riappare alla chiusura

        bool bodyOn = (tBody != null && tBody.On);
        if (!bodyOn) return;

        Ped p = Game.Player.Character;
        if (p == null || !p.Exists()) return;

        // agganciata sotto l'header, larga quanto il menu
        float px = MX, pw = MW;
        float lH = 12f;

        bool showHead = (tTopBar == null || tTopBar.On);
        float y = MY + (showHead ? HEAD_H : 0f);

        if (bodyOn)
        {
            DrawBar(px, pw, y, lH, L("Hunger", "Fame"), hunger, 255, 190, 150);     // pesca pastello
            y = y + lH;
            DrawBar(px, pw, y, lH, L("Thirst", "Sete"), thirst, 155, 215, 240);     // azzurro pastello
            y = y + lH;
        }

    }

    void DrawMenu()
    {
        TMenu m = menus[cur];
        int n = m.Items.Count;

        bool showHead = (tTopBar == null || tTopBar.On);
        float y = MY + (showHead ? HEAD_H : 0f);

        if (n == 0)
        {
            DrawRect(MX, y, MW, ITEM_H, 0, 0, 0, 150);
            DrawText(L("(empty)", "(vuoto)"), MX + 9f, y + 3f, 0.24f, Color.FromArgb(255, 170, 170, 180));
            y = y + ITEM_H;
        }

        int shown = 0;
        int i;
        for (i = m.Top; i < n && shown < MAX_VIS; i++)
        {
            TItem it = m.Items[i];
            bool sel = (i == m.Sel);

            if (it.Kind == TItem.HEADER)
            {
                DrawRect(MX, y, MW, ITEM_H, 0, 0, 0, 195);
                DrawRect(MX, y, 3f, ITEM_H, it.Cr, it.Cg, it.Cb, 235);
                DrawText(Txt(it), MX + 9f, y + 3f, 0.22f, Color.FromArgb(255, it.Cr, it.Cg, it.Cb));
                y = y + ITEM_H;
                shown++;
                continue;
            }

            if (sel)
            {
                DrawRect(MX, y, MW, ITEM_H, 245, 245, 245, 235);
            }
            else
            {
                DrawRect(MX, y, MW, ITEM_H, 0, 0, 0, 150);
            }

            Color fg;
            if (sel)
            {
                fg = Color.FromArgb(255, 15, 15, 18);
            }
            else if (it.Tinted)
            {
                fg = Color.FromArgb(255, it.Cr, it.Cg, it.Cb);
            }
            else
            {
                fg = Color.FromArgb(255, 235, 235, 240);
            }

            if (it.Tinted)
            {
                DrawRect(MX, y, 3f, ITEM_H, it.Cr, it.Cg, it.Cb, sel ? 255 : 220);
            }

            DrawText(Txt(it), MX + 9f, y + 3f, 0.24f, fg);

            string right = "";
            if (it.Kind == TItem.SUB) right = ">";
            else if (it.Kind == TItem.TOGGLE) right = it.On ? "[ ON ]" : "[ OFF ]";
            else if (it.Kind == TItem.LIST && it.Opts != null && it.Opts.Length > 0) right = "< " + it.Opts[it.Sel] + " >";
            else if (it.Kind == TItem.NUMBER) right = "< " + it.Val + " >";

            if (right.Length > 0)
            {
                Color vc = fg;
                if (it.SignedValue && it.Opts != null && it.Opts.Length > 0)
                {
                    string ov = it.Opts[it.Sel];
                    if (ov.StartsWith("-")) vc = sel ? Color.FromArgb(255, 165, 25, 25) : Color.FromArgb(255, 255, 110, 110);
                    else if (ov.StartsWith("+")) vc = sel ? Color.FromArgb(255, 20, 120, 45) : Color.FromArgb(255, 120, 230, 130);
                    else vc = sel ? Color.FromArgb(255, 15, 15, 18) : Color.FromArgb(255, 245, 245, 245);
                }
                DrawTextRight(right, MX + MW - 9f, y + 3f, 0.23f, vc);
            }

            y = y + ITEM_H;
            shown++;
        }

        // footer
        DrawRect(MX, y, MW, FOOT_H, 0, 0, 0, 185);
        string pos = n > 0 ? ((m.Sel + 1) + "/" + n) : "0/0";
        DrawText(TitleOf(m).ToUpper() + "   " + pos, MX + 9f, y + 2f, 0.19f, Color.FromArgb(255, 200, 200, 210));
        DrawTextRight(L("F4 / RB+DOWN", "F4 / RB+GIU"), MX + MW - 9f, y + 2f, 0.18f, Color.FromArgb(255, 170, 170, 185));
    }

    // Rettangolo con gli angoli smussati. Il gioco sa disegnare solo
    // rettangoli, quindi la curva si fa a gradini: quattro righe sottili
    // che rientrano sopra e sotto. A questa dimensione l'occhio legge un
    // angolo tondo. (Un PNG darebbe la curva vera ma finirebbe sopra a
    // tutto: le texture di ScriptHookV si disegnano dopo i rettangoli.)
    void DrawRoundRect(float px, float py, float pw, float ph, int r, int g, int b, int a)
    {
        DrawRoundRect(px, py, pw, ph, r, g, b, a, 1f);
    }

    // 'k' allarga o stringe lo smusso: 1 = angolo discreto, 3 = quasi ovale
    void DrawRoundRect(float px, float py, float pw, float ph, int r, int g, int b, int a, float k)
    {
        float[] inset = new float[] { 5f * k, 3f * k, 2f * k, 1f * k };
        int n = inset.Length;

        // corpo centrale, pieno
        DrawRect(px, py + n, pw, ph - n * 2f, r, g, b, a);

        int i;
        for (i = 0; i < n; i++)
        {
            float d = inset[i];
            DrawRect(px + d, py + i, pw - d * 2f, 1f, r, g, b, a);                    // sopra
            DrawRect(px + d, py + ph - 1f - i, pw - d * 2f, 1f, r, g, b, a);          // sotto
        }
    }

    void DrawRect(float px, float py, float pw, float ph, int r, int g, int b, int a)
    {
        float ccx = (px + pw * 0.5f) / 1280f;
        float ccy = (py + ph * 0.5f) / 720f;
        Function.Call(Hash.DRAW_RECT, ccx, ccy, pw / 1280f, ph / 720f, r, g, b, a);
    }

    // Arco a segmenti: non esiste una primitiva per gli archi, quindi si
    // disegnano tanti quadratini lungo la circonferenza. 'a0' e 'a1' sono
    // i gradi (0 = ore 12, si gira in senso orario), 'pct' e' 0..100.
    void DrawArc(float cx, float cy, float rad, float a0, float a1,
                 float pct, float th, Color colOn, Color colOff)
    {
        int n = 48;
        int i;
        for (i = 0; i <= n; i++)
        {
            float t = (float)i / (float)n;
            float deg = a0 + (a1 - a0) * t;
            float rd = (deg - 90f) * 0.0174533f;

            float px = cx + (float)Math.Cos(rd) * rad;
            float py = cy + (float)Math.Sin(rd) * rad;

            Color c = (t * 100f <= pct) ? colOn : colOff;
            DrawRect(px - th * 0.5f, py - th * 0.5f, th, th, c.R, c.G, c.B, c.A);
        }
    }

    float Clamp01(float x)
    {
        if (x < 0f) return 0f;
        if (x > 1f) return 1f;
        return x;
    }

    // Lancetta: un segmento dal raggio 'rIn' al raggio 'rOut', disegnato
    // con quadratini perche' non c'e' una primitiva per le linee.
    void DrawNeedle(float cx, float cy, float rIn, float rOut,
                    float deg, float th, Color col)
    {
        float rd = (deg - 90f) * 0.0174533f;
        float dx = (float)Math.Cos(rd);
        float dy = (float)Math.Sin(rd);

        int n = 12;
        int i;
        for (i = 0; i <= n; i++)
        {
            float r = rIn + (rOut - rIn) * ((float)i / (float)n);
            float px = cx + dx * r;
            float py = cy + dy * r;
            DrawRect(px - th * 0.5f, py - th * 0.5f, th, th, col.R, col.G, col.B, col.A);
        }
    }

    // larghezza del testo in pixel sulla griglia 1280x720
    float TextWidth(string txt, float scale)
    {
        TextElement el = new TextElement(txt, new PointF(0f, 0f), scale);
        el.Font = GTA.UI.Font.ChaletLondon;
        return el.Width;
    }

    void DrawText(string txt, float x, float y, float scale, Color col)
    {
        TextElement el = new TextElement(txt, new PointF(x, y), scale);
        el.Color = col;
        el.Font = GTA.UI.Font.ChaletLondon;
        el.Outline = false;
        el.Draw();
    }

    void DrawTextCenter(string txt, float x, float y, float scale, Color col)
    {
        TextElement el = new TextElement(txt, new PointF(x, y), scale);
        el.Color = col;
        el.Font = GTA.UI.Font.ChaletLondon;
        el.Alignment = Alignment.Center;
        el.Outline = false;
        el.Draw();
    }

    void DrawTextCenterOutline(string txt, float x, float y, float scale, Color col)
    {
        TextElement el = new TextElement(txt, new PointF(x, y), scale);
        el.Color = col;
        el.Font = GTA.UI.Font.ChaletLondon;
        el.Alignment = Alignment.Center;
        el.Outline = true;
        el.Draw();
    }

    void DrawTextOutline(string txt, float x, float y, float scale, Color col)
    {
        TextElement el = new TextElement(txt, new PointF(x, y), scale);
        el.Color = col;
        el.Font = GTA.UI.Font.ChaletLondon;
        el.Alignment = Alignment.Right;
        el.Outline = true;
        el.Draw();
    }

    void DrawTextRight(string txt, float x, float y, float scale, Color col)
    {
        TextElement el = new TextElement(txt, new PointF(x, y), scale);
        el.Color = col;
        el.Font = GTA.UI.Font.ChaletLondon;
        el.Alignment = Alignment.Right;
        el.Outline = false;
        el.Draw();
    }
}
